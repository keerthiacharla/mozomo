<?php 
	session_start();
	if(!isset($_SESSION["name"])){
		header ("Location:http://localhost/mozo/login.php");
		
	}
	?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<title>MOZOMO SHOPPING</title>
	
	<link rel="stylesheet" href="infile/bootstrap/bootstrap4.css">
	
	<script src="js/jquery.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		 <!-- <script src="https://code.jquery.com/jquery-3.6.0.js"></script> -->
  		<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
   		<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
   			<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>  
   		<link rel="stylesheet" href="css/first.css?v=111">
   		<link rel="stylesheet" href="css/status.css?v=1">
  


<style>

</style>

</head>
<body>
	
	<div class="container-fluid ">
		<div class="row pt-3" id="menu-bar">
			
					<div class=" col-12 col-md-3 col-sm-12 m-auto">
						<div class="menu-title">
							<h1 class="text-white"><img src="admin/infile/logo.gif" alt=""></h1>
						</div>
					</div>
					<div class="col-12 col-md-6 col-sm-12  m-auto">
						<div class="form-group">
							<input type="text" id="item-seaarch" class="form-control" placeholder="Search Bar">
						</div>
					</div>

					<div class="col-12 justify-content-center ml-lg-auto col-md-3 col-lg-3 col-sm-12 m-auto flex-sm-row cos-menu">
						<li class="nav-item dropdown d-block m-auto ">
						<a href="" class="nav-link dropdown-toggle justify-content-center " id="name_sec" data-toggle="dropdown"><img src="php/setting/photo/<?php echo $_SESSION['img']; ?>" alt="" id="cos-pic"><?php echo $_SESSION['name']; ?></a>
						<div class="dropdown-menu m-auto" id="first_drop">
							<a href="" class="dropdown-item">
								<button class="d-block w-100  set-btn" id="ord-opp"> Orders</button>
							</a>
							
							<a href="" class="dropdown-item">
								<button class="d-block w-100 set-btn" id="set-opp"> Setting</button>
							</a>
							<a href="" class="dropdown-item">
								<button class="d-block w-100 set-btn" id="sign-out"> Sign Out</button>
							</a>
						</div>
					</li>
					</div>

			
		</div>


	



			
	</div>



	<div class="container-fluid act_container" id="act_container">
		<div class="row">
			<div class="col-md-3 m-0" id="menu-slide">
			
				<nav class="navbar">
					<button class="btn text-white d-block ml-auto " id="reloade">Clear All</button>

					 <ul class="d-block w-100" id="mobile-box">
						 	<li><button class="btn text-white" id="all-pro">All</button></li>
						 </ul>
						 	

					 	<ul class="d-block w-100" id="mobile-box">
						 	<li><button class="btn text-white" data-toggle="collapse" data-target="#mob-con">Moble</button></li>
						 	<ul class="collapse  ml-3 " id="mob-con">
						 		
						 		<ul class="d-block w-100 m-2" id="mobile-box">
											 <li><button class="btn text-white " data-toggle="collapse" data-target="#mob-br" id="mob-label">All Brands </span></button></li>
											 		<ul class="collapse  ml-3 " id="mob-br">

											 			<?php include "php/menu/mobmenu.php" ?>
											 		</ul>
										 </ul>
						 			
						 				<ul class="d-block w-100 m-2" id="mobile-box">
											 <li><button class="btn text-white " data-toggle="collapse" data-target="#mob-ram" id="ram-label">RAM </span></button></li>
											 		<ul class="collapse  ml-3 " id="mob-ram">

											 			<?php include "php/menu/mobram.php" ?>	
											 		</ul>
										 </ul>
										 <ul class="d-block w-100 m-2" id="mobile-box">
											 <li><button class="btn text-white " data-toggle="collapse" data-target="#mob-sto" id="mob-sto-label">Starage </span></button></li>
											 		<ul class="collapse  ml-3 " id="mob-sto">

											 			<?php include "php/menu/mob-storage.php" ?>	
											 		</ul>
										 </ul>
						 			</ul>
								 </ul>






							 	<ul class="d-block w-100">
							 		<li><button class="btn text-white" data-toggle="collapse" data-target="#tv-con">Telvision</button></li>
								 	<ul class="collapse  ml-3 " id="tv-con">
								 		
								 		<ul class="d-block w-100 m-2" id="tv-box">
											 <li><button class="btn text-white " data-toggle="collapse" data-target="#tv-br" id="tv-label">All Brands </span></button></li>
													 <ul class="collapse  ml-3 " id="tv-br">

											 			<?php include "php/menu/tvmenu.php" ?>
											 		</ul>
										 </ul>
						 			
						 				<ul class="d-block w-100 m-2" id="tv-box">
											 <li><button class="btn text-white " data-toggle="collapse" data-target="#tv-display" id="tvdisplay">Display Type </span></button></li>
											 		<ul class="collapse  ml-3 " id="tv-display">

											 			<?php include "php/menu/tvdis.php" ?>
											 		</ul>
										 </ul>
										 <ul class="d-block w-100 m-2" id="mobile-box">
											 <li><button class="btn text-white " data-toggle="collapse" data-target="#tv-res" id="tv-res-label">Resoluton </span></button></li>
											 		<ul class="collapse  ml-3 " id="tv-res">

											 			<?php include "php/menu/tvres.php" ?>
											 		</ul>
										 </ul>
						 			</ul>
								 	

							 	</ul>
							 	<UL class="range w-100">
									 
									<li class="mb-3"> <b> Amount Range : </b>
										<span id="amt" class="text-white  p-2 mt-2 text-bold"></span> 
									</li>
									<li id="slider-range"></li>

							</UL>
							</nav>

						

							

					



			</div>





			<div class="col-md-9 flex-wrap justify-content-center home " id="home_sec"></div>

			<div class="col-md-9  flex-wrap justify-content-center " id="fea_sec"></div>

		</div>
	</div>

	<div class=" container-fluid setting_container ">
		
		<?php include "php/setting/setting.php" ?>


	</div>

	<div class=" container-fluid order_container ">
		
		<?php include "php/order/order_con.php" ?>
	<!-- = -->
		


	</div>
		
		
		<script src="js/slider.js"></script>
		
		<script src="js/menu-opp.js?v=111"></script>
		<!-- <script src="js/check.js?v=111"></script> -->
		<script src="js/checkdu.js?v=111"></script>
		<script src="js/setting.js"></script>
		<script src="js/order.js"></script>
		<script src="js/return.js"></script>
		<script src="js/search.js"></script>
		

</body>
</html>
