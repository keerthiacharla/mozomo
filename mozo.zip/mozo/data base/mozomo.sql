-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2023 at 09:03 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mozomo`
--

-- --------------------------------------------------------

--
-- Table structure for table `carosol`
--

CREATE TABLE `carosol` (
  `sno` int(10) NOT NULL,
  `img` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `dis` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `carosol`
--

INSERT INTO `carosol` (`sno`, `img`, `title`, `dis`) VALUES
(1, '1.jpg', 'Lorem ipsum dolor sit amet consectetur', 'Lorem ipsum dolor sit amet consectetur'),
(2, '2.jpg', 'Lorem ipsum dolor sit amet consectetur', 'Lorem ipsum dolor sit amet consectetur'),
(3, '3.jpg', 'Lorem ipsum dolor sit amet consectetur', 'Lorem ipsum dolor sit amet consectetur'),
(4, '4.jpg', 'Lorem ipsum dolor sit amet consectetur', 'Lorem ipsum dolor sit amet consectetur'),
(5, '5.jpg', 'Lorem ipsum dolor sit amet consectetur', 'Lorem ipsum dolor sit amet consectetur'),
(6, 'backlog copy.jpg', 'Lorem ipsum dolor sit amet consectetur', 'Lorem ipsum dolor sit amet consectetur');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `sno` int(10) NOT NULL,
  `c_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`sno`, `c_name`) VALUES
(1, 'Mobile'),
(2, 'Television');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE `city` (
  `sno` int(10) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state_val` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`sno`, `city`, `state_val`) VALUES
(1, 'Vizag', 2),
(3, 'Mahabubnager', 1),
(4, 'Hyderabad', 1),
(6, 'Bangalore', 4);

-- --------------------------------------------------------

--
-- Table structure for table `cos_mass`
--

CREATE TABLE `cos_mass` (
  `sno` int(10) NOT NULL,
  `cname` int(10) NOT NULL,
  `ord_id` varchar(100) NOT NULL,
  `mass_opp` varchar(1000) NOT NULL,
  `massage` varchar(10000) NOT NULL,
  `mass_type` varchar(1000) NOT NULL,
  `mass_date` varchar(100) NOT NULL,
  `mass_status` varchar(100) NOT NULL,
  `mas_rly` varchar(1000) NOT NULL,
  `rly_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cos_mass`
--

INSERT INTO `cos_mass` (`sno`, `cname`, `ord_id`, `mass_opp`, `massage`, `mass_type`, `mass_date`, `mass_status`, `mas_rly`, `rly_date`) VALUES
(12, 2, 'tv949615', 'Order by mistake', 'mistake', 'Product Returned', '30-07-2023', 'Replayed', 'hai', '30-07-2023'),
(13, 2, 'tv723834', 'Item is not satisfied', 'sorry', 'Product Returned', '30-07-2023', 'Unread', '', ''),
(16, 2, 'mob348720', 'Order by mistake', 'sorry', 'Product Returned', '30-07-2023', 'Unread', '', ''),
(17, 2, 'mob894998', 'Wrong item was Sended', 'Color is wrong ', 'Product Returned', '02-08-2023', 'Replayed', 'sorry we are mistake ', '02-08-2023'),
(18, 2, 'mob396334', 'Order by mistake', 'Returned', 'Product Returned', '04-08-2023', 'Unread', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `cos_users`
--

CREATE TABLE `cos_users` (
  `sno` int(11) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `gen` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` int(10) NOT NULL,
  `dis` int(10) NOT NULL,
  `zip` int(10) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cos_users`
--

INSERT INTO `cos_users` (`sno`, `user_id`, `fname`, `lname`, `pass`, `gen`, `phone`, `email`, `address`, `city`, `dis`, `zip`, `image`) VALUES
(2, 'Mzo774599', 'ACHARLA', 'KEERTHI', 'f30a5282e0b595683ee1ddeb6d18faff', 'Female', '9866900000', 'aragamallini@gmail.com', '10-2-40/2, Bayamatoitha ', 1, 3, 509001, ''),
(3, 'Mzo591973', 'T', 'Keshav', 'f30a5282e0b595683ee1ddeb6d18faff', 'Male', '9806900000', 'keshav@gmail.com', 'nallakinta', 1, 4, 5000044, ''),
(4, 'Mzo879874', 'mukesh', 'khanna', 'f30a5282e0b595683ee1ddeb6d18faff', 'Male', '2658741147', 'mukesh@gmail.com', 'ssgfgffh', 1, 3, 12364, ''),
(6, 'Mzo873384', 'AK', 'SRINIVAS', 'f30a5282e0b595683ee1ddeb6d18faff', 'Male', '2658741115', 'aragamallinaai@gmail.com', 'vizaganager', 2, 1, 4555, '');

-- --------------------------------------------------------

--
-- Table structure for table `deli_agent`
--

CREATE TABLE `deli_agent` (
  `sno` int(10) NOT NULL,
  `deli_id` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `gen` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` int(10) NOT NULL,
  `dis` int(10) NOT NULL,
  `zone` int(10) NOT NULL,
  `zip` int(10) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deli_agent`
--

INSERT INTO `deli_agent` (`sno`, `deli_id`, `fname`, `lname`, `pass`, `gen`, `phone`, `email`, `address`, `city`, `dis`, `zone`, `zip`, `image`) VALUES
(3, 'mozodeli544599', 'R', 'Keshav', 'c79077fb2a0b06ae6ccf62ddc7269026', 'Male', '9106859000', 'keshav@gmail.com', '45-7/2,hali', 1, 3, 1, 503001, ''),
(4, 'mozodeli4628', 'K', 'kishan', 'c79077fb2a0b06ae6ccf62ddc7269026', 'Male', '9553635509', 'kishan@gmail.com', 'nallakunta hyderabad', 1, 4, 2, 503001, ''),
(5, 'mozodeli724942', 'JayRaj', 'M', '', 'Male', '9106859123', 'jayraj@gmail.com', 'Yelahanka Bangalore ', 4, 6, 3, 503001, '');

-- --------------------------------------------------------

--
-- Table structure for table `deli_statussn`
--

CREATE TABLE `deli_statussn` (
  `sno` int(10) NOT NULL,
  `ord_id` int(10) NOT NULL,
  `s_area` varchar(100) NOT NULL,
  `d_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `deli_zone`
--

CREATE TABLE `deli_zone` (
  `sno` int(10) NOT NULL,
  `state` int(10) NOT NULL,
  `city` int(10) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deli_zone`
--

INSERT INTO `deli_zone` (`sno`, `state`, `city`, `address`) VALUES
(1, 1, 3, ' bayamathotha, marlu'),
(3, 4, 6, 'Yelahanka');

-- --------------------------------------------------------

--
-- Table structure for table `display`
--

CREATE TABLE `display` (
  `sno` int(10) NOT NULL,
  `dis_mode` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `display`
--

INSERT INTO `display` (`sno`, `dis_mode`) VALUES
(1, 'Display'),
(2, 'No');

-- --------------------------------------------------------

--
-- Table structure for table `emp_details`
--

CREATE TABLE `emp_details` (
  `sno` int(10) NOT NULL,
  `emp_id` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `gen` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `state` int(10) NOT NULL,
  `city` int(10) NOT NULL,
  `zip_code` int(10) NOT NULL,
  `dign` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `join_date` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `emp_details`
--

INSERT INTO `emp_details` (`sno`, `emp_id`, `first_name`, `last_name`, `gen`, `phone`, `email`, `address`, `state`, `city`, `zip_code`, `dign`, `status`, `image`, `join_date`) VALUES
(5, 'mozoemp169513', 'Acharla', 'Srinivas', 'Male', '9866906621', 'keerthiacharla@gmail.com', '10-40, marlu', 1, 3, 509001, 'Manager', 'Employee', 'mozoemp169513.jpg', '2023-06-28'),
(12, 'mozoemp245976', 'Achala', 'raga malini', 'Female', '2333333333', 'raga@gmailcon', '21547 H.no 233/12', 2, 1, 530694, 'Clert', 'Employee', 'mozoemp245976.jpg', '2023-06-15'),
(13, 'mozoemp498760', 'MD', 'Rafi', 'Male', '9587412362', 'rafi@gmail.com', 'New Nallakunta, Hyderabad', 1, 4, 500044, 'Manager', 'RESIGN', '', '2023-08-07'),
(14, 'mozoemp630042', 'HR', 'Harika', 'Female', '9568741233', 'harika@gmail.com', 'Nalgonda RR Dist', 1, 4, 5062347, 'Hr', 'Employee', '', '2023-08-07');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `sno` int(10) NOT NULL,
  `img_id` int(10) NOT NULL,
  `img_name` varchar(100) NOT NULL,
  `pro_no` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`sno`, `img_id`, `img_name`, `pro_no`) VALUES
(63, 1, 'mobile_ 1114269944 -lenovo-k8-note-64-gb-black-4-gb-ram- (2).jpg', 1),
(64, 1, 'mobile_ 35159523 -lenovo-k8-note-64-gb-black-4-gb-ram- (1).jpg', 1),
(65, 1, 'mobile_ 403819834 -lenovo-k8-note-64-gb-black-4-gb-ram-.jpg', 1),
(66, 2, 'mobile_ 619730759 -7046cdf34418ec1a481782c7463ce95467f07a2b826d70b0281838_01.jpg', 1),
(67, 2, 'mobile_ 397542433 -7046cdf34418ec1a481782c7463ce95467f07a2b826d70b0281838_02.jpg', 1),
(68, 2, 'mobile_ 1372413481 -7046cdf34418ec1a481782c7463ce95467f07a2b826d70b0281838_00.jpg', 1),
(69, 25, 'tv_ 1839551759 -CSEXwuB9.jpg', 2),
(76, 1, 'mobile_ 313797896 -images (1).jpg', 1),
(77, 1, 'mobile_ 1925494801 -images.jpg', 1),
(83, 25, 'tv_ 1882235926 -images (3).jpg', 2),
(84, 25, 'tv_ 267497533 -images (2).jpg', 2),
(85, 5, 'mobile_ 1688604746 -61nta86CROL._SX679_.jpg', 1),
(89, 5, 'mobile_ 760241852 -817WWpaFo1L._SX679_.jpg', 1),
(90, 5, 'mobile_ 161742410 -81KkF-GngHL._SX679_.jpg', 1),
(91, 4, 'mobile_ 226288559 -7046cdf34418ec1a481782c7463ce95467f07a2b826d70b0281838_01.jpg', 1),
(92, 4, 'mobile_ 1148638315 -7046cdf34418ec1a481782c7463ce95467f07a2b826d70b0281838_00.jpg', 1),
(104, 28, 'tv_ 1735792186 -81W4Q2kENEL._SX679_.jpg', 2),
(105, 28, 'tv_ 1232897766 -51pWEsotRaL._SX679_.jpg', 2);

-- --------------------------------------------------------

--
-- Table structure for table `input`
--

CREATE TABLE `input` (
  `sno` int(11) NOT NULL,
  `in_type` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `input`
--

INSERT INTO `input` (`sno`, `in_type`) VALUES
(1, 'checkbox'),
(2, 'radio');

-- --------------------------------------------------------

--
-- Table structure for table `main_logo`
--

CREATE TABLE `main_logo` (
  `sno` int(10) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `main_logo`
--

INSERT INTO `main_logo` (`sno`, `image`) VALUES
(1, 'logo.gif');

-- --------------------------------------------------------

--
-- Table structure for table `mobile`
--

CREATE TABLE `mobile` (
  `sno` int(10) NOT NULL,
  `empl_name` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  `br_name` int(10) NOT NULL,
  `ml_name` varchar(100) NOT NULL,
  `ml_num` varchar(100) NOT NULL,
  `tec` varchar(100) NOT NULL,
  `color` varchar(100) NOT NULL,
  `pr_cam` varchar(100) NOT NULL,
  `se_cam` varchar(100) NOT NULL,
  `ram` varchar(100) NOT NULL,
  `dis_type` varchar(100) NOT NULL,
  `resol` varchar(100) NOT NULL,
  `os` varchar(100) NOT NULL,
  `fea` varchar(100) NOT NULL,
  `manu` varchar(100) NOT NULL,
  `sto` varchar(100) NOT NULL,
  `made` varchar(100) NOT NULL,
  `disc` varchar(1000) NOT NULL,
  `amt` varchar(100) NOT NULL,
  `off_rate` varchar(100) NOT NULL,
  `off_per` varchar(100) NOT NULL,
  `dis_mode` int(10) NOT NULL,
  `pro_name` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mobile`
--

INSERT INTO `mobile` (`sno`, `empl_name`, `file`, `br_name`, `ml_name`, `ml_num`, `tec`, `color`, `pr_cam`, `se_cam`, `ram`, `dis_type`, `resol`, `os`, `fea`, `manu`, `sto`, `made`, `disc`, `amt`, `off_rate`, `off_per`, `dis_mode`, `pro_name`, `date`) VALUES
(1, 'Acharla Keerthi Srinivas', 'mobile_ 691822085 -lenovo-k8-note-64-gb-black-4-gb-ram- (3).jpg', 9, 'Lenovo 420', '12351551MX', '4G', 'White, Blue, Gold', '18 MEGA PIXCEL', '4 MEGA PIXCEL', '6 GB', 'LED', '1080px', 'Android', 'GPS, Hotspot, Flash Light, Radio', '9', '32 GB', 'India', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eligendi perspiciatis facilis recusandae molestiae. Reiciendis nobis repellendus ab libero culpa. Dignissimos laboriosam aspernatur, veniam excepturi ut quos dolorem odit. Ea officia, mollitia necessitatibus quas itaque deserunt harum earum exercitationem facilis pariatur labore obcaecati amet dolorem, modi consequatur tenetur, sint officiis error, excepturi commodi quisquam saepe nulla quaerat a molestias! Numquam quas magnam saepe a architecto sapiente reprehenderit eligendi, ipsa harum tenetur quam voluptas aliquam fuga laborum eius sit cupiditate hic incidunt aut facilis minima impedit unde. Accusantium facere neque pariatur tempora perspiciatis aut, earum inventore, nostrum blanditiis ea quas optio maxime ratione saepe quasi dicta iusto, praesentium officia magnam ducimus. Quia odio, explicabo. Quaerat magnam, excepturi. Ab ex, accusamus eum ut!', '18000', '15840', '12', 1, 1, '2023-06-01 08:02:01'),
(5, 'Acharla Srinivas', 'mobile_ 732371435 -817WWpaFo1L._SX679_.jpg', 8, 'Samsung X13', '6641354MI', '5G', 'White, Blue, Gold', '18 MEGA PIXCEL', '8 MEGA PIXCEL', '6 GB', 'LED', '1080px', 'Android', 'Wi-Fi, GPS, Hotspot, Flash Light, Radio', '8', '64 GB', 'U.S.A', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eligendi perspiciatis facilis recusandae molestiae. Reiciendis nobis repellendus ab libero culpa. Dignissimos laboriosam aspernatur, veniam excepturi ut quos dolorem odit. Ea officia, mollitia necessitatibus quas itaque deserunt harum earum exercitationem facilis pariatur labore obcaecati amet dolorem, modi consequatur tenetur, sint officiis error, excepturi commodi quisquam saepe nulla quaerat a molestias! Numquam quas magnam saepe a architecto sapiente reprehenderit eligendi, ipsa harum tenetur quam voluptas aliquam fuga laborum eius sit cupiditate hic incidunt aut facilis minima impedit unde. Accusantium facere neque pariatur tempora perspiciatis aut, earum inventore, nostrum blanditiis ea quas optio maxime ratione saepe quasi dicta iusto, praesentium officia magnam ducimus. Quia odio, explicabo. Quaerat magnam, excepturi. Ab ex, accusamus eum ut!', '20000', '17600', '12', 1, 1, '2023-08-05 05:58:01'),
(9, 'Acharla Srinivas', 'mobile_ 950766679 -lenovo-k8-note-64-gb-black-4-gb-ram- (3).jpg', 9, 'Lenovo 420', '666+56656Lenovo', '5G', 'White, Grey, Blue', '35 MEGA PIXCEL', '18 MEGA PIXCEL', '6 GB', 'LCD', '1080px', 'Android', 'Wi-Fi, GPS, Hotspot, Flash Light, Radio', '9', '128 GB', 'China', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eligendi perspiciatis facilis recusandae molestiae. Reiciendis nobis repellendus ab libero culpa. Dignissimos laboriosam aspernatur, veniam excepturi ut quos dolorem odit. Ea officia, mollitia necessitatibus quas itaque deserunt harum earum exercitationem facilis pariatur labore obcaecati amet dolorem, modi consequatur tenetur, sint officiis error, excepturi commodi quisquam saepe nulla quaerat a molestias! Numquam quas magnam saepe a architecto sapiente reprehenderit eligendi, ipsa harum tenetur quam voluptas aliquam fuga laborum eius sit cupiditate hic incidunt aut facilis minima impedit unde. Accusantium facere neque pariatur tempora perspiciatis aut, earum inventore, nostrum blanditiis ea quas optio maxime ratione saepe quasi dicta iusto, praesentium officia magnam ducimus. Quia odio, explicabo. Quaerat magnam, excepturi. Ab ex, accusamus eum ut!', '20000', '17600', '12', 1, 1, '2023-08-06 04:27:07');

-- --------------------------------------------------------

--
-- Table structure for table `otp_exp`
--

CREATE TABLE `otp_exp` (
  `sno` int(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `otp` int(10) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `otp_exp`
--

INSERT INTO `otp_exp` (`sno`, `email`, `otp`, `time`) VALUES
(103, 'keerthiach@gmail.com', 3275, '2023-05-25 14:21:19'),
(107, 'keerthi@gmail.com', 3423, '2023-05-26 15:44:33'),
(108, 'keerthiacharla@gmail.com', 7940, '2023-05-31 13:23:35'),
(109, 'keerthiacharla@gmail.com', 3641, '2023-06-02 06:39:07'),
(110, 'raga@gmailcon', 6021, '2023-06-03 05:34:14'),
(125, '9866906621', 8569, '2023-06-29 09:12:35'),
(126, '9866906621', 8569, '2023-06-29 09:12:35'),
(127, 'rafi@gmail.com', 9528, '2023-08-06 04:49:44');

-- --------------------------------------------------------

--
-- Table structure for table `pay`
--

CREATE TABLE `pay` (
  `sno` int(10) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `o_id` varchar(100) NOT NULL,
  `pid` varchar(100) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `amt` int(10) NOT NULL,
  `bank` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pay`
--

INSERT INTO `pay` (`sno`, `cname`, `o_id`, `pid`, `pname`, `amt`, `bank`, `date`, `status`) VALUES
(1, '', 'ORDS81043986', '5698745', 'REDMI V6', 20000, 'HDFC Bank', '2023-02-06 18:21:42.0', ' successful'),
(2, '', 'ORDS92760674', '6754332', 'Sumsung GT-654', 10000, '', '', 'processing...'),
(3, '', 'ORDS75002437', '6754332', 'Sumsung GT-654', 10000, 'ICICI Bank', '2023-02-14 14:24:09.0', ' successful');

-- --------------------------------------------------------

--
-- Table structure for table `pro`
--

CREATE TABLE `pro` (
  `sno` int(10) NOT NULL,
  `pname` varchar(100) NOT NULL,
  `cid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pro`
--

INSERT INTO `pro` (`sno`, `pname`, `cid`) VALUES
(5, 'Micromax', 1),
(6, 'Samsung', 2),
(7, 'Micromax', 2),
(8, 'Samsung', 1),
(9, 'Lenovo', 1),
(11, 'Lloyd', 2),
(12, 'OPPO', 1),
(14, 'Honnor', 1),
(18, 'Onida', 2),
(19, 'Apple', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pro_logo`
--

CREATE TABLE `pro_logo` (
  `sno` int(10) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `br_name` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pro_logo`
--

INSERT INTO `pro_logo` (`sno`, `logo`, `br_name`) VALUES
(4, 'samsung.png', 6),
(7, 'Micromax_logo_orange_background.png', 7),
(8, 'download.png', 12),
(9, 'lenovo-logo-0.png', 9),
(10, 'download (1).png', 11);

-- --------------------------------------------------------

--
-- Table structure for table `roz`
--

CREATE TABLE `roz` (
  `sno` int(10) NOT NULL,
  `cos_no` int(10) NOT NULL,
  `itm_sno` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `ord` varchar(100) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `amt` int(10) NOT NULL,
  `pay_id` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `ord_status` varchar(100) NOT NULL,
  `dat` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `procss` int(10) NOT NULL,
  `cos_otp` int(10) NOT NULL,
  `deli_name` varchar(100) NOT NULL,
  `deli_ph` varchar(100) NOT NULL,
  `deli_otp` int(10) NOT NULL,
  `deli_date` varchar(100) NOT NULL,
  `deli_ret` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roz`
--

INSERT INTO `roz` (`sno`, `cos_no`, `itm_sno`, `p_id`, `ord`, `p_name`, `address`, `amt`, `pay_id`, `status`, `invoice`, `ord_status`, `dat`, `procss`, `cos_otp`, `deli_name`, `deli_ph`, `deli_otp`, `deli_date`, `deli_ret`) VALUES
(7, 2, 3, 1, 'mob133122', 'Micro31XD', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 8000, 'pay_M2zLk4Q5cGXaot', 'Returned', 'invoice_mob37383', 'Payment Sattled Successfully', '2023-07-26 12:39:07', 3, 0, 'R Keshav', '9106859000', 0, '26-07-2023', ''),
(8, 3, 3, 1, 'mob472178', 'Micro31XD', 'nallakinta , ,Telangana -5000044', 8000, 'pay_M33MtpN6rmBOTe', 'Returned', 'invoice_mob97662', 'Payment Sattled Successfully', '2023-07-25 05:00:12', 3, 0, 'K kishan', '9553635509', 0, '25-07-2023', ''),
(32, 3, 25, 2, 'tv52634', 'Samsung FHD TV', 'nallakinta , ,Telangana -5000044', 40000, 'pay_MEVUKeUPXp649N', 'Suceess', 'invoice_mob38549', 'Delivared Sucessfully', '2023-07-17 06:04:18', 3, 0, 'K kishan', '9553635509', 0, '17-07-2023', ''),
(33, 2, 3, 1, 'mob301451', 'Micro31XD', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 8000, 'pay_MEVVaIjbvr2e1p', 'Returned', 'invoice_mob30955', 'Payment Sattled Successfully', '2023-07-26 12:41:06', 3, 0, 'R Keshav', '9106859000', 0, '26-07-2023', ''),
(34, 2, 26, 2, 'tv251566', 'MI full HD Tv', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 10000, 'pay_MEVWM8gB6Cg86F', 'Returned', 'invoice_mob35080', 'Payment Sattled Successfully', '2023-07-26 12:47:21', 3, 0, 'R Keshav', '9106859000', 0, '26-07-2023', ''),
(36, 2, 26, 2, 'tv7678', 'MI full HD Tv', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 10000, 'pay_MF8jtKBc9xt9mP', 'Returned', 'invoice_mob49882', 'Payment Sattled Successfully', '2023-07-26 12:49:36', 3, 0, 'R Keshav', '9106859000', 0, '26-07-2023', ''),
(37, 4, 3, 1, 'mob919443', 'Micro31XD', 'ssgfgffh , ,Telangana -12364', 8000, 'pay_MF8n6K4Po0ekix', 'Suceess', 'invoice_mob67441', 'Delivared Sucessfully', '2023-07-18 05:32:00', 3, 0, 'R Keshav', '9106859000', 0, '18-07-2023', '1'),
(38, 2, 3, 1, 'mob917953', 'Micro31XD', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 8000, 'pay_MFD4GK3aBXzeQZ', 'Returned', 'invoice_mob18216', 'Payment Sattled Successfully', '2023-07-26 12:51:18', 3, 0, 'R Keshav', '9106859000', 0, '26-07-2023', ''),
(40, 2, 3, 1, 'mob780296', 'Micro31XD', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 8000, 'pay_MHvnPJ8maWtM87', 'Returned', 'invoice_mob64719', 'Payment Sattled Successfully', '2023-07-26 12:53:29', 3, 0, 'R Keshav', '9106859000', 0, '26-07-2023', ''),
(41, 2, 3, 1, 'mob853815', 'Micro31XD', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 8000, 'pay_MIRB8VaLOqPMXo', 'Returned', 'invoice_mob69205', 'Payment Sattled Successfully', '2023-07-30 07:32:57', 3, 0, 'R Keshav', '9106859000', 0, '30-07-2023', ''),
(42, 2, 25, 2, 'tv949615', 'Samsung FHD TV', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 32000, 'pay_MJeGJKF1xAiKki', 'Returned', 'invoice_mob69907', 'Payment Sattled Successfully', '2023-07-30 15:28:51', 3, 0, 'R Keshav', '9106859000', 0, '30-07-2023', ''),
(43, 2, 26, 2, 'tv723834', 'MI full HD Tv', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 10000, 'pay_MJulbW3e9yWMAh', 'Returned', 'invoice_mob44654', 'Payment Sattled Successfully', '2023-07-30 11:38:07', 3, 0, 'R Keshav', '9106859000', 0, '30-07-2023', ''),
(44, 2, 1, 1, 'mob348720', 'Lenovo 420', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 15840, 'pay_MJzePgFHtHG3ZD', 'Returned', 'invoice_mob58190', 'Payment Sattled Successfully', '2023-07-30 15:56:07', 3, 0, 'R Keshav', '9106859000', 0, '30-07-2023', ''),
(45, 2, 1, 1, 'mob894998', 'Lenovo 420', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 15840, 'pay_ML49EnJ2nIrJaL', 'Returned', 'invoice_mob32230', 'Payment Sattled Successfully', '2023-08-02 04:41:31', 3, 0, 'R Keshav', '9106859000', 0, '02-08-2023', ''),
(46, 2, 3, 1, 'mob396334', 'Micro31XD', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 8000, 'pay_MLDgnxWoJL5JDz', 'Returned', 'invoice_mob14772', 'Payment Sattled Successfully', '2023-08-04 13:13:21', 3, 0, 'R Keshav', '9106859000', 0, '04-08-2023', ''),
(47, 2, 1, 1, 'mob639999', 'Lenovo 420', '10-2-40/2, Bayamatoitha  , ,Telangana -509001', 15840, 'pay_MLzqydx4f9zEiu', 'Returned', 'invoice_mob48748', 'Payment Sattled Successfully', '2023-08-04 13:24:05', 3, 0, 'R Keshav', '9106859000', 0, '04-08-2023', '');

-- --------------------------------------------------------

--
-- Table structure for table `speci`
--

CREATE TABLE `speci` (
  `sno` int(10) NOT NULL,
  `spec_title` varchar(100) NOT NULL,
  `p_name` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `speci`
--

INSERT INTO `speci` (`sno`, `spec_title`, `p_name`) VALUES
(4, 'Network', 1),
(6, 'Camera', 1),
(8, 'Inch', 2),
(10, 'Color', 1),
(11, 'Operating System', 1),
(12, 'Display Type', 1),
(13, 'Resolution', 1),
(14, 'RAM', 1),
(15, 'Features', 1),
(16, 'Made In', 1),
(17, 'Storage upto', 1),
(18, 'Color', 2),
(19, 'Display', 2),
(20, 'Resolution', 2),
(21, 'Features', 2);

-- --------------------------------------------------------

--
-- Table structure for table `specival`
--

CREATE TABLE `specival` (
  `sno` int(10) NOT NULL,
  `pname` int(10) NOT NULL,
  `under` int(10) NOT NULL,
  `s_val` text NOT NULL,
  `in_type` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `specival`
--

INSERT INTO `specival` (`sno`, `pname`, `under`, `s_val`, `in_type`) VALUES
(9, 1, 10, 'White', 1),
(11, 1, 11, 'Android', 2),
(12, 1, 11, 'IOS', 1),
(18, 1, 14, 'Below 512 MB', 1),
(19, 1, 14, '2 GB', 1),
(20, 1, 14, '4 GB', 1),
(21, 1, 14, '6 GB', 1),
(22, 1, 13, '720px', 1),
(23, 1, 13, '1080px', 1),
(24, 1, 12, 'LCD', 1),
(25, 1, 12, 'LED', 1),
(26, 1, 15, 'Wi-Fi', 1),
(27, 1, 15, 'GPS', 1),
(28, 1, 15, 'Hotspot', 1),
(30, 1, 15, 'Flash Light', 1),
(31, 1, 15, 'Radio', 1),
(32, 1, 16, 'India', 1),
(33, 1, 16, 'China', 1),
(34, 1, 16, 'U.S.A', 1),
(35, 1, 16, 'Japan', 1),
(36, 1, 17, '512 MB', 1),
(39, 1, 12, 'Keypad', 1),
(40, 2, 18, 'White ', 1),
(41, 2, 18, 'Black', 1),
(42, 2, 18, 'Grey', 1),
(43, 2, 8, '12 inch', 1),
(44, 2, 8, '18 inch', 1),
(45, 2, 8, '32 inch', 1),
(46, 2, 19, 'LCD', 1),
(47, 2, 19, 'LED', 1),
(48, 2, 20, 'SD', 1),
(49, 2, 20, 'HD', 1),
(50, 2, 20, 'HD ++', 1),
(51, 2, 20, '4K', 1),
(52, 2, 20, '8K', 1),
(53, 2, 21, 'Wi-Fi', 1),
(54, 2, 21, 'Bluetooth ', 1),
(55, 2, 21, 'Internet Connectivity ', 1),
(58, 1, 4, '2G', 1),
(60, 1, 4, '4G', 1),
(61, 1, 4, '5G', 1),
(62, 1, 17, '32 GB', 1),
(63, 1, 17, '64 GB', 1),
(64, 1, 17, '128 GB', 1),
(65, 1, 10, 'Grey', 0),
(66, 1, 10, 'Blue', 0);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `sno` int(10) NOT NULL,
  `state` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`sno`, `state`) VALUES
(1, 'Telangana'),
(2, 'Andhra Pradesh'),
(4, 'Karnataka');

-- --------------------------------------------------------

--
-- Table structure for table `television`
--

CREATE TABLE `television` (
  `sno` int(10) NOT NULL,
  `emp_name` varchar(100) NOT NULL,
  `file` varchar(100) NOT NULL,
  `br_name` int(10) NOT NULL,
  `ml_name` varchar(100) NOT NULL,
  `ml_no` varchar(100) NOT NULL,
  `color` varchar(100) NOT NULL,
  `inch` varchar(100) NOT NULL,
  `dis` varchar(100) NOT NULL,
  `resol` varchar(100) NOT NULL,
  `fea` varchar(100) NOT NULL,
  `hdmi` varchar(100) NOT NULL,
  `usb` varchar(100) NOT NULL,
  `manu` varchar(100) NOT NULL,
  `made` varchar(100) NOT NULL,
  `disc` varchar(1000) NOT NULL,
  `amt` varchar(100) NOT NULL,
  `off_rate` varchar(100) NOT NULL,
  `off_per` varchar(100) NOT NULL,
  `dis_mode` int(10) NOT NULL,
  `pro_name` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `television`
--

INSERT INTO `television` (`sno`, `emp_name`, `file`, `br_name`, `ml_name`, `ml_no`, `color`, `inch`, `dis`, `resol`, `fea`, `hdmi`, `usb`, `manu`, `made`, `disc`, `amt`, `off_rate`, `off_per`, `dis_mode`, `pro_name`, `date`) VALUES
(25, 'Acharla Keerthi Srinivas', 'tv_ 551310222 -71a4ZQNqTiL._SL1500_.jpg', 6, 'Samsung FHD TV', '515646546MI', 'Black, Grey', '18 inch', 'LCD', 'HD ++', 'Bluetooth , Internet Connectivity ', '2', '2', '6', 'U.S.A', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eligendi perspiciatis facilis recusandae molestiae. Reiciendis nobis repellendus ab libero culpa. Dignissimos laboriosam aspernatur, veniam excepturi ut quos dolorem odit. Ea officia, mollitia necessitatibus quas itaque deserunt harum earum exercitationem facilis pariatur labore obcaecati amet dolorem, modi consequatur tenetur, sint officiis error, excepturi commodi quisquam saepe nulla quaerat a molestias! Numquam quas magnam saepe a architecto sapiente reprehenderit eligendi, ipsa harum tenetur quam voluptas aliquam fuga laborum eius sit cupiditate hic incidunt aut facilis minima impedit unde. Accusantium facere neque pariatur tempora perspiciatis aut, earum inventore, nostrum blanditiis ea quas optio maxime ratione saepe quasi dicta iusto, praesentium officia magnam ducimus. Quia odio, explicabo. Quaerat magnam, excepturi. Ab ex, accusamus eum ut!', '40000', '32000', '20', 1, 2, '2023-07-30 04:26:01'),
(28, 'Acharla Srinivas', 'tv_ 1803962356 -51C+rgHIsFL._SY300_SX300_.jpg', 6, 'Samsung FHD TV 42 inch', '664664HD', 'White , Black, Grey', '32 inch', 'LED', 'HD ++', 'Wi-Fi, Bluetooth ', '1', '2', '6', 'U.S.A', 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eligendi perspiciatis facilis recusandae molestiae. Reiciendis nobis repellendus ab libero culpa. Dignissimos laboriosam aspernatur, veniam excepturi ut quos dolorem odit. Ea officia, mollitia necessitatibus quas itaque deserunt harum earum exercitationem facilis pariatur labore obcaecati amet dolorem, modi consequatur tenetur, sint officiis error, excepturi commodi quisquam saepe nulla quaerat a molestias! Numquam quas magnam saepe a architecto sapiente reprehenderit eligendi, ipsa harum tenetur quam voluptas aliquam fuga laborum eius sit cupiditate hic incidunt aut facilis minima impedit unde. Accusantium facere neque pariatur tempora perspiciatis aut, earum inventore, nostrum blanditiis ea quas optio maxime ratione saepe quasi dicta iusto, praesentium officia magnam ducimus. Quia odio, explicabo. Quaerat magnam, excepturi. Ab ex, accusamus eum ut!', '18000', '15840', '12', 1, 2, '2023-08-05 06:22:39');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `sno` int(10) NOT NULL,
  `emp_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`sno`, `emp_id`, `name`, `user_id`, `pass`, `email`, `role`) VALUES
(12, 5, 'Achala Srinu', 'Adm581071', '21232f297a57a5a743894a0e4a801fc3', 'keerthiach@gmail.com', 1),
(17, 12, 'A.Srinivas', 'Nor374310', 'f30a5282e0b595683ee1ddeb6d18faff', 'raga@gmailcon', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carosol`
--
ALTER TABLE `carosol`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `city`
--
ALTER TABLE `city`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `cos_mass`
--
ALTER TABLE `cos_mass`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `cos_users`
--
ALTER TABLE `cos_users`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `deli_agent`
--
ALTER TABLE `deli_agent`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `deli_statussn`
--
ALTER TABLE `deli_statussn`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `deli_zone`
--
ALTER TABLE `deli_zone`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `display`
--
ALTER TABLE `display`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `emp_details`
--
ALTER TABLE `emp_details`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `input`
--
ALTER TABLE `input`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `main_logo`
--
ALTER TABLE `main_logo`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `mobile`
--
ALTER TABLE `mobile`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `otp_exp`
--
ALTER TABLE `otp_exp`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `pay`
--
ALTER TABLE `pay`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `pro`
--
ALTER TABLE `pro`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `pro_logo`
--
ALTER TABLE `pro_logo`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `roz`
--
ALTER TABLE `roz`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `speci`
--
ALTER TABLE `speci`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `specival`
--
ALTER TABLE `specival`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `television`
--
ALTER TABLE `television`
  ADD PRIMARY KEY (`sno`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carosol`
--
ALTER TABLE `carosol`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `city`
--
ALTER TABLE `city`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `cos_mass`
--
ALTER TABLE `cos_mass`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `cos_users`
--
ALTER TABLE `cos_users`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `deli_agent`
--
ALTER TABLE `deli_agent`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `deli_statussn`
--
ALTER TABLE `deli_statussn`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `deli_zone`
--
ALTER TABLE `deli_zone`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `display`
--
ALTER TABLE `display`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `emp_details`
--
ALTER TABLE `emp_details`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=106;

--
-- AUTO_INCREMENT for table `input`
--
ALTER TABLE `input`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `main_logo`
--
ALTER TABLE `main_logo`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `mobile`
--
ALTER TABLE `mobile`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `otp_exp`
--
ALTER TABLE `otp_exp`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT for table `pay`
--
ALTER TABLE `pay`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `pro`
--
ALTER TABLE `pro`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `pro_logo`
--
ALTER TABLE `pro_logo`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `roz`
--
ALTER TABLE `roz`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `speci`
--
ALTER TABLE `speci`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `specival`
--
ALTER TABLE `specival`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `television`
--
ALTER TABLE `television`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `sno` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
