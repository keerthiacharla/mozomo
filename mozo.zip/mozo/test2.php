<?php 


	date_default_timezone_set("Asia/Kolkata");
	


		 /*echo "php";*/

		 $days = "+10 days";

		echo $today = date("d-m-Y", strtotime("now"));
		echo $ret = date("d-m-Y", strtotime($days));
		echo  "<br>";
		

		while(0==0){
			
			
			echo $today = date("d-m-Y", strtotime($today."+1 days"));
			echo  "<br>";



			if($today == $ret){
				break;
			}
		}

						
 ?>



 <?php 


	date_default_timezone_set("Asia/Kolkata");
	

		include "admin/infile/config.php";

				
				
				
			 $sql = "SELECT * FROM roz WHERE sno = 10"; 

				$res = mysqli_query($conn,$sql) or die(" query failed first");

				if(mysqli_num_rows($res)){

					
					while($row = mysqli_fetch_assoc($res)){

						echo $date = "Today Date  " .date("2023-07-03");
						echo  "<br>";
						$del_date = $row["deli_date"];
						$del_ret = "+".$row["deli_ret"];
						echo "Delivary Date  " .$today = date("d-m-Y", strtotime($del_date));
						echo  "<br>";
						echo "Return date " .$ret = date("d-m-Y", strtotime($del_date.$del_ret));
						echo $ret++;
						while(0==0){
			
								
								echo $today = date("d-m-Y", strtotime($today."+1 days"));
								echo  "<br>";
								echo  "<br>";


								

								if($today == $ret){
									
									break;
								}


							}

							if($date >= $ret){
										echo "overdate";
									}else{
										echo "indate";
									}

					}
				}

						
 ?>