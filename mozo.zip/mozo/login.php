<?php 
	session_start();
	if(isset($_SESSION["name"])){
		header ("Location:http://localhost/mozo/first.php");
		
	}
	?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="infile/bootstrap/bootstrap4.css">
	<script src="js/jquery.min.js"></script>
	
	<link rel="stylesheet" href="css/login.css?v=11111">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Smokum&display=swap" rel="stylesheet">
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-6 col-md-12 d-none align-content-center d-lg-block d-md-none d-sm-none d-xs-none  " id="back">
				<img src="admin/infile/logo.gif" id="log-image" alt="">
			
			</div>

			<div class="col-md-6 justify-content-center  col-sm-12 ml-sm-0">
				<form action="" class="form " id="login-form">
					<img src="infile/log-logo.png"  height="90px" alt="" id="log-logo">
					<h3><center>Login Here</center></h3>
					<center><div class="signup_error text-danger"> Lorem, ipsum, dolor.</div></center>
					<div class="form-group">
						<label for="">Username <span>*</span></label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text"><i class="fa-solid fa-users"></i></span>
								</div>
								<input type="text" class="form-control" id="user_name" name="user_name" placeholder="Enter User Name ">
								
								
							
						</div>
						
					</div>
					<div class="form-group">
						<label for="">Password </label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
							</div>
							<input type="password" class="form-control" id="user_pass" name="user_pass" placeholder="Enter User password ">
								<div class="input-group-append">
									<span class="input-group-text" id="luser_icon"><i class="fa-solid fa-eye" id="luser_show_icon"></i></span>
								</div>

							
						</div>
					</div>
							<button class="btn " id="join"> Join Now </button><br>
							<button class="btn " id="for-pass"> Forgoted Password </button>

							<div class="capachi">
								<label for="">Capacha</label><span class="capa-img">
									
									
								</span>
								<div class=" form-group input-group">
									<input type="text" class="" id="user_capa_hidd" name="" value="">
										<input type="text" class="form-control-sm" id="user_capa" name="" placeholder="Enter User Capacha ">
										<div class="input-group-append">
											<span class="input-group-text"><i class="fa-solid fa-rotate-right" id="re"></i></span>
										</div>

									
								</div>

							</div>
							<button class="btn btn-primary d-block p-2 w-100" > Join </button>

				</form>




			<div action="" class="col-md-12 justify-content-center" id="singup-form">

					<button class="btn " id="back-to"> BACK </button><br>
					
					<h3><center>Sign Up Here</center></h3>
					<h3><center><div class="signup_error text-danger"> Lorem, ipsum, dolor.</div></center></h3>
					
						<form action="" class="form" id="inner_singup">
							<div class="form-group">
							<label for="">First Name <span class="error-col fn-err">*</span></label>
							<div class="input-group">
								<input type="text" class="form-control" id="f_name" name="f_name" placeholder="Enter User Name ">
										
							</div>
							
						</div>
						<div class="form-group">
							<label for="">Last Name <span class="error-col ln-err">*</span></label>
							<div class="input-group">
								<input type="text" class="form-control" id="l_name" name="l_name" placeholder="Enter User Name ">
										
							</div>
							
						</div>

						<div class="form-group">
							<label for="">Password <span class="error-col pass-err">*</span></label>
							<div class="input-group">
								
								<input type="password" class="form-control" id="pass" name="pass" placeholder="Enter User password ">
									<div class="input-group-append">
										<span class="input-group-text" id="sicon"><i class="fa-solid fa-eye" id="puser_show_icon"></i></span>
									</div>
	
							</div>
						</div>
						<div class="form-group">
							<label for="">Confirm Password <span class="error-col cpass-err">*</span></label>
							<div class="input-group">
								
								<input type="password" class="form-control" id="cpass" name="cpass" placeholder="Enter User password ">
									<div class="input-group-append">
										<span class="input-group-text" id="scicon"><i class="fa-solid fa-eye" id="cpuser_show_icon"></i></span>
									</div>

								
							</div>
						</div>
						<div class="form-group">
							<label for="">Email <span class="error-col email-err">*</span></label>
							
								<input type="text" class="form-control" id="email" name="email" placeholder="Enter User Name ">
										
							
							
						</div>
						<div class="form-group form-inline">
							<label for="" class="mr-3 text-bold">Gender <span class="error-col gen-err">*</span></label>
							
								<input type="radio" id="male" value="Male" name="gender" class="form-control-sm mr-3 gender">
								<label for="male"> Male</label>
								<input type="radio" id="female" value="Female" name="gender" class="form-control-sm mr-3 ml-3 gender">
								<label for="female"> Female</label>
										
							
							
						</div>
						<div class="form-group">
							<label for="">Phone <span class="error-col ph-err">*</span></label>
							
								<input type="text" class="form-control" id="phone" name="phone" placeholder="Enter User Name ">
										
							
							
						</div>
						<div class="form-group">
							<label for="">Address <span class="error-col ad-err">*</span></label>
							
								<textarea name="add" id="add" cols="30" rows="" class="form-control"></textarea>
										
							
							
						</div>
						<div class="form-group">
							<label for="">State <span class="error-col state-err">*</span></label>
						
								<select name="state" id="state" class="form-control-sm">
									<option value="select"> Select Sata</option>
									<option value="1"> Telangana</option>
								</select>
										
							
						</div>
						<div class="form-group">
							<label for="">District <span class="error-col dis-err">*</span></label>
						
								<select name="dis" id="dis" class="form-control-sm">
									<option value="select"> Select District</option>
									<option value="1"> Telangana</option>
								</select>
										
							
						</div>
						<div class="form-group">
							<label for="">Zip Code <span class="error-col zip-err">*</span></label>
							
								<input type="text" class="form-control" id="zip" name="zip" placeholder="Enter User Name ">
										
							
							
						</div>
						<div class="capachi">
									<label for="">Capacha <span class="error-col capa-err">*</span></label>
									<input type="text" value="" id="sucapa-hidden" >
									<span class="sucapa-img">

										
									</span>
									<div class=" form-group input-group">
										
											<input type="text" class="form-control-sm" id="usup_capa" name="" placeholder="Enter User Capacha ">
											<div class="input-group-append">
												<span class="input-group-text"><i class="fa-solid fa-rotate-right" id="sure"></i></span>
												
											</div>

										
									</div>

							</div>

								<button class="btn btn-primary d-block p-2 w-100" > Join </button>

							</form>




			
					</div> <br>
				<!-- Forget form  -->
				<div  id="forgot-form">
					<button class="btn " id="for-back-to"> BACK </button><br>
					<center><h3>Retrive Password</h3></center>
					<form action="" id="forgot-otp-form" class="p-3">
						<h3><center><div class="signup_error text-danger"> Lorem, ipsum, dolor.</div>
						<div class="form-group input-group p-2">
							<label for="">Enter Your Email</label>
							<input type="text"  name=""  id="otp-email" class="form-control" placeholder="Enter Email ID">
							<div class="input-group-append">
								<div class="input-group-text">
									<button class="btn btn-primary " id="for-sub" name="for-sub" >Send OTP</button>
									
								</div>
							</div>
						</div>
					</form>

					<form action="" class="otp-box" id="otp-box">

						
							
					</form>
					
				</div>

				<form action="" class="" id="reset-pass-form">
						<center> <h3>Enter New Password</h3> </center>
						<button class="btn " id="for-back-to"> BACK </button><br>
						<h3><center><div class="for_signup_error text-danger"> Lorem, ipsum, dolor.</div>
							<input type="text" class="form-control" id="cf_pass_hidd" name="cf_pass_hidd" value="">

						<div class="form-group">
							<label for="">Password </label>
							<div class="input-group">
								
								<input type="password" class="form-control" id="f_pass" name="f_pass" placeholder="Enter User password ">
									<div class="input-group-append">
										<span class="input-group-text" id="f_con"><i class="fa-solid fa-eye" id="f_show_icon"></i></span>
									</div>
	
							</div>
						</div>
						<div class="form-group">
							<label for="">Confirm Password </label>
							<div class="input-group">
								
								<input type="password" class="form-control" id="cf_pass" name="cf_pass" placeholder="Enter User password ">
									<div class="input-group-append">
										<span class="input-group-text" id="cficon"><i class="fa-solid fa-eye" id="cf_show_icon"></i></span>
									</div>
	
							</div>
						</div>
						<button class="btn btn-primary" id="reset-pass-btn"> Reset Password </button>
					</form>

			
		</div>





		</div>
	</div>
			<script src="js/singup.js?v=1111"></script>
			<script src="js/forgot.js?V=12"></script>
			<script src="js/login.js?V=12"></script>
	<script>
		$(document).ready(function(){
			alert("a");

			function capa(){
					var text = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
					var capch = "";

					for(var i=1;i<6;i++){
						capch = capch + text.charAt(Math.floor(Math.random()*63));
					}
					$(".capa-img").html(capch);
					$("#user_capa_hidd").val(capch);
					}
			capa();


			$("#re").click(function(){
				capa();

			})

				
		})
	</script>
</body>
</html>