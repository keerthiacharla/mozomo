<?php 

	$conn = mysqli_connect("localhost","root","","mozomo") or die("connection failed");
 ?>