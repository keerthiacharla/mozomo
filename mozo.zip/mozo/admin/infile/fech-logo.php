<?php 



	$conn = mysqli_connect("localhost","root","","mozomo") or die("connection failed");

				
			$sql = "SELECT * FROM main_logo";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
						echo "<h1 class='text-white text-center'><img src='infile/{$row['image']}' alt=''></h1>";


						
					
					}

					
				}else{ 
					echo "No login";
				}

 ?>