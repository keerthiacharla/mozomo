$(document).ready(function(){
			alert("new file");
		})