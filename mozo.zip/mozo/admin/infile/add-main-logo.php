<?php 

	
		$file = $_FILES['logo-main-city']['name'];

		

if($file != ""){

		

		$file_temp = $_FILES['logo-main-city']['tmp_name'];

		$extension = pathinfo($file,PATHINFO_EXTENSION);

		$valid_extension = array("gif","jpg");
		
		
		if(in_array($extension,$valid_extension) === false){
		
			echo "File is not support.. please uploade gif";
			
		}else{
			$img = "logo.gif";
			$target =  $img;
			$image_name = $img; 
			
			
			
			if(move_uploaded_file($file_temp,$target)){
				
				$conn = mysqli_connect("localhost","root","","mozomo") or die("connection failed");

				$sql = "UPDATE main_logo SET image = '{$img}' WHERE sno = 1 ";
							
						if(mysqli_query($conn,$sql) == true){
							echo 1;
						}else{
							echo 0;
						}
			}else{
				echo "file is uploade error";
				
			}
		}
		
		
		

				
		
		
	}else{
		echo "Please upload image of product";
	}

 ?>