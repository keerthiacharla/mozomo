
<div class="allpayment_items_container p-3">
	<h1 class="bg-primary d-block text-white" id="title">All Orders  Modification</h1><span>
		
	</span>

<div class="product-items-container">
	
		
		
	<button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#recos_set_data">All Ordered Customers History</button>

	<div class="product_data collapse p-3" id="recos_set_data">
				
			<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="allcos-det-val-search-box" name="allcos-det-val-search-box" placeholder="SEARCH">
							</div>
						</div>

			        

			       <div class="col-md-12 productdata-container d-lg-flex">

			       	 <div class="col-md-6" id="allcos-det-btn">
			       	 
			       	 	
			       	 </div>
			       	 <div class="col-md-6" id="allcos-det-con">
			       	 	<table class="table" id="allcos-det-table">
			       	 		
						</table>
			       	 
			       	 
			       	 </div>
			       	 
			       </div>
			    </div>


			


			<button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#retcos_set_data">All Returned Customers History</button>

	<div class="product_data collapse p-3" id="retcos_set_data">
				
			<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="allrecos-det-val-search-box" name="allrecos-det-val-search-box" placeholder="SEARCH">
							</div>
						</div>

			        

			       <div class="col-md-12 productdata-container d-lg-flex">

			       	 <div class="col-md-6" id="allrecos-det-btn">
			       	 
			       	 	
			       	 </div>
			       	 <div class="col-md-6" id="allrecos-det-con">
			       	 	<table class="table" id="allrecos-det-table">
			       	 		
						</table>
			       	 
			       	 
			       	 </div>
			       	 
			       </div>
			    </div>    
			    
		</div>

	   
		</div>



