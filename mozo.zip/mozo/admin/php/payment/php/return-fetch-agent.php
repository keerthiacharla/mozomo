
<?php 

 
	include "../../../infile/config.php";

	$id = $_POST['id'];
	
				
		
					$sql = "SELECT * FROM deli_agent WHERE dis = $id";

								$res = mysqli_query($conn,$sql) or die(" 2nd query failed");

								if(mysqli_num_rows($res) > 0){

									echo "<option value='select'selected>Select</option>";
									
									while($row = mysqli_fetch_assoc($res)){

										echo "<option value='{$row['sno']}'>{$row['deli_id']}</option>";

											}
									
								}else{ 
									echo "No login";
								}

					

 ?>
