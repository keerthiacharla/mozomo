
	<?php


	include "../../../infile/config.php";

	$id = $_POST['id'];
				
			$sql = "SELECT roz.*,cos_users.fname,cos_users.lname,cos_users.user_id FROM roz  
					LEFT JOIN cos_users ON roz.cos_no = cos_users.sno
					LEFT JOIN category ON roz.p_id = category.sno
					 WHERE roz.sno =$id ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						


						
						if($row['deli_name'] == "" && $row['deli_ph'] == ""){
							$boy = "";
						}else{
							$boy = "<tr>
								<td><b>Delivary Agent Details </b></td>
								<td><b>Name : </b> {$row['deli_name']} <b>Phone Number  : </b> {$row['deli_ph']}
								</td>
							</tr>";

						}
					
						echo "<tr>
								<td><b>Category</b></td>
								<td><b>details</b></td>
							</tr>
							<tr>
								<td><b>Costomer Name </b></td>
								<td>{$row['user_id']}</td>
							</tr>
							<tr>
								<td><b>Costomer Name </b></td>
								<td>{$row['fname']} {$row['lname']}</td>
							</tr>
							<tr>
								<td><b>Delivary Address </b></td>
								<td>{$row['address']}</td>
							</tr>
							<tr>
								<td><b>item serial Number & Name </b></td>
								<td><b>No : </b>{$row['itm_sno']} <b>Name : </b>{$row['p_name']}</td>
							</tr>
							<tr>
								<td><b>Payment Id  </b></td>
								<td>{$row['pay_id']}</td>
							</tr>
							<tr>
								<td><b>Ammount ID </b></td>
								<td>{$row['amt']}</td>
							</tr>
							
							<tr>
								<td><b>Payment Status  </b></td>
								<td>{$row['status']}</td>
							</tr>
							
							<tr>
								<td><b>Invioice No  </b></td>
								<td>{$row['invoice']} <br><span><a href='../php/roz/recipt.php?id={$row['pay_id']}'class='btn btn-link bg-primary text-white mt-2 '>print Reciept </a></span></td>
							</tr>
							{$boy}
							
							
							<tr>
								<td><b>Delivaryed On </b></td>
								<td>{$row['deli_date']}</td>
							</tr>

							";

						
					
					}

					
				}else{ 
					echo "No login";
				}
			?>