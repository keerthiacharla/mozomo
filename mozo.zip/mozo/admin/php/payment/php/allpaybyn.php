
 

				<?php 

 
	include "../../../infile/config.php";
				
			$sql = "SELECT * FROM roz WHERE ord_status = 'Delivared Sucessfully'";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
						
					
						echo "<button class='btn btn-primary mb-1' data-allpayid='{$row['sno']}' id='allcos-del-brn'>{$row['ord']}</button> <br>";

						
					
					}

					
				}else{ 
					echo "No login";
				}

 ?>
