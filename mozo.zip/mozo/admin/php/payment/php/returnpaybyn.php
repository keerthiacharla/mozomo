
 

				<?php 

 
	include "../../../infile/config.php";
				
			$sql = "SELECT * FROM roz WHERE ord_status = 'Returned' || ord_status = 'Ready to Pickup' || ord_status = 'Receved Item Re-Payment is under Processing' ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
						
					
						echo "<button class='btn btn-primary mb-1' data-returnpayid='{$row['sno']}' id='return-cos-del-btn'>{$row['ord']}</button> <br>";

						
					
					}

					
				}else{ 
					echo "<h1> No Recent Order By Costomer </h1>";
				}

 ?>
