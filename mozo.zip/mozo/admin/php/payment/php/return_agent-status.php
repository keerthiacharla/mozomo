
<?php 

 
	include "../../../infile/config.php";


	   $id = $_POST['id'];
	  $name = $_POST['name'];
	  $ph = $_POST['ph'];
	  $otp = rand(0000,99999);
	   	   
				
			$sql = "UPDATE roz SET procss = 1, ord_status = 'Ready to Pickup', deli_name = '{$name}', deli_ph ='{$ph}', deli_otp = {$otp} WHERE sno = {$id}";

				

				if(mysqli_query($conn,$sql)){

					echo 1;

					

					
				}else{
						echo die("1st query failed");
					}

  ?>
