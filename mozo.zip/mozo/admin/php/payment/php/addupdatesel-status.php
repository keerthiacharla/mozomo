
<?php 

 
	include "../../../infile/config.php";


	
				
			$sql = "SELECT * FROM roz WHERE ord_status = 'processing...'";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					echo "<option value='select'selected>Select</option>";
					
					while($row = mysqli_fetch_assoc($res)){

						echo "<option value='{$row['sno']}'selected>{$row['ord']}</option>";

							}
					
				}else{ 
					echo "No login";
				}

 ?>
