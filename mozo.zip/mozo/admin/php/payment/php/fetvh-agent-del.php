
<?php 

 
	include "../../../infile/config.php";


	$id = $_POST['val'];
				
			$sql = "SELECT * FROM deli_agent WHERE sno = $id";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					
					while($row = mysqli_fetch_assoc($res)){

						echo "<div class='form-group'>
			       						<label for=''>Agent Name</label>
			       						<input type='text' id='agent_name' name='agent_name' class='form-control'value='{$row['fname']} {$row['lname']}' readonly>
			       					</div>
			       					<div class='form-group'>
			       						<label for=''>Agent Number</label>
			       						<input type='text' id='agent_no' name='agent_no' class='form-control' value='{$row['phone']}' readonly>
			       					</div>";

							}
					
				}else{ 
					echo "No login";
				}

 ?>
