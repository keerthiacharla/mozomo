
<?php 

 
	include "../../../infile/config.php";


	   $id = $_POST['id'];
	  $val = $_POST['val'];
	   $otp = rand(0000,99999);
	   $deli_otp = rand(0000,99999);
	  $ret = $_POST['ret'];
				
			$sql = "UPDATE roz SET deli_otp = {$deli_otp}, cos_otp = {$otp}, deli_ret ='{$ret}'  WHERE sno = {$id}";

				

				if(mysqli_query($conn,$sql)){

					echo 1;

					

					
				}else{
						echo die("1st query failed");
					}

  ?>
