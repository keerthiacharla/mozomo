
<?php 

 
	include "../../../infile/config.php";


	$id = $_POST['id'];
	$val = $_POST['val'];
				
			$sql = "UPDATE roz SET ord_status = 'processing...', procss = {$val} WHERE sno = {$id}";

				

				if(mysqli_query($conn,$sql)){

					$status = "Item delivery from MOZOMO office";

					$sql1 = "INSERT INTO deli_statussn(ord_id,s_area) VALUES({$id},'{$status}')";

					if(mysqli_query($conn,$sql1)){
						echo 1;
					}else{
						echo die("2nd query failed");
					}

					
				}else{
						echo die("1st query failed");
					}

 ?>
