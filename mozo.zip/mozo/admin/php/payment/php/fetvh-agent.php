
<?php 

 
	include "../../../infile/config.php";

	$id = $_POST['sno'];
	
				
			$sql = "SELECT * FROM cos_users WHERE user_id ='{$id}'";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					
					while($row = mysqli_fetch_assoc($res)){

						 $city_no = $row['dis'];
								$sql2 = "SELECT * FROM deli_agent WHERE dis = $city_no";

								$res2 = mysqli_query($conn,$sql2) or die(" 2nd query failed");

								if(mysqli_num_rows($res2) > 0){

									echo "<option value='select'selected>Select</option>";
									
									while($row2 = mysqli_fetch_assoc($res2)){

										echo "<option value='{$row2['sno']}'>{$row2['deli_id']}</option>";

											}
									
								}else{ 
									echo "No login";
								}

							}
					
				}else{ 
					echo "No login";
				}

 ?>
