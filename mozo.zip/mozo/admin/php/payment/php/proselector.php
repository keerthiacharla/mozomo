
<?php 

 
	include "../../../infile/config.php";


 	$id = $_POST['id'];
	
				
			$sql = "SELECT * FROM roz WHERE sno = $id";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					echo "<option value='select'selected>Select process</option>";
					
					while($row = mysqli_fetch_assoc($res)){

						if($row['procss'] == 0){
						echo	$sta = "<option value='2'>Processing</option>";
						}else if($row['procss'] == 2){
						echo	$sta = "<option value='3'>Successfull</option>";
						}

						

							}
					
				}else{ 
					echo "No login";
				}

 ?>
