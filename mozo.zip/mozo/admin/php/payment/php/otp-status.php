
<?php 

 
	include "../../../infile/config.php";


	$id = $_POST['id'];
	$val = $_POST['val'];
	
				
			$sql = "SELECT * FROM roz WHERE sno = {$id}";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						if($row['cos_otp'] == $val){
							
							
							$sql1 = "UPDATE roz SET ord_status = 'Sucessfully', cos_otp = 0, procss = 3 , deli_otp = 0  WHERE sno = {$id}";

									if(mysqli_query($conn,$sql1)){

													
										$sql2 = "DELETE FROM deli_statussn WHERE ord_id = {$id}";

												if(mysqli_query($conn,$sql2)){
													
													echo 1;
												}else{
													echo die("3nd query failed");
												}
									}else{
										echo die("2nd query failed");
									}
						}else{
							echo 0;
						}
						
						

						
						
					
					}

					
				}else{ 
					echo "No login";
				}

 ?>
