
<?php 

 
	include "../../../infile/config.php";


	$id = $_POST['id'];
	$val = $_POST['val'];
				
			$sql = "INSERT INTO deli_statussn(ord_id,s_area) VALUES({$id},'{$val}')";

				

				if(mysqli_query($conn,$sql)){

				echo 1;

					
				}else{
						echo die("1st query failed");
					}

 // ?>
