
<?php 

 


 
	include "../../../infile/config.php";


	$id = $_POST['id'];
	$date = date("d-m-Y");
	
			
							
							
							$sql1 = "UPDATE roz SET ord_status = 'Payment Sattled Successfully', procss = 3, deli_date = '{$date}' WHERE sno = {$id}";

									if(mysqli_query($conn,$sql1)){

													
										$sql2 = "DELETE FROM deli_statussn WHERE ord_id = {$id}";

												if(mysqli_query($conn,$sql2)){
													
													echo 1;
												}else{
													echo die("3nd query failed");
												}
									}else{
										echo die("2nd query failed");
									}
						
						

						
						
					
					

					
				




 ?>
