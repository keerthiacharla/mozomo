
<?php 

 
	include "../../../infile/config.php";


	   $id = $_POST['id'];
	  $otp = $_POST['otp'];
	
		$sql = "SELECT * FROM roz WHERE sno = $id ";
		$res = mysqli_query($conn,$sql) or die(" 1 st Query failed");

		if(mysqli_num_rows($res)){
			while($row = mysqli_fetch_assoc($res)){
				if($row['deli_otp'] == $otp){
					$sql2 = "UPDATE roz SET ord_status = 'Receved Item Re-Payment is under Processing', procss = 2 , deli_otp = 0 WHERE sno = {$id}";
					if(mysqli_query($conn,$sql2)){

							$status = "Item Received Re-Payment is under Processing";

							$sql1 = "INSERT INTO deli_statussn(ord_id,s_area) VALUES({$id},'{$status}')";

							if(mysqli_query($conn,$sql1)){
									echo 1;
								}else{
									echo die("Query Failed");
								}

						}else{
								echo die("Query Failed");
							}

				}else{
					echo 2;
				}
			}
		}else{
				echo die("Query Failed");
			}
	   	   
				
			

  ?>
