
	<?php


	include "../../../infile/config.php";

	$id = $_POST['id'];
				
			$sql = "SELECT roz.*,cos_users.fname,cos_users.lname,cos_users.user_id,cos_users.dis AS city FROM roz  
					LEFT JOIN cos_users ON roz.cos_no = cos_users.sno
					LEFT JOIN category ON roz.p_id = category.sno
					 WHERE roz.sno =$id ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						if($row['status'] == "Returned" && $row['procss'] == 0 ){
							$aget ="<button class='btn btn-primary mb-1'  data-toggle='modal' data-target='#agent_return_deli' data-city='{$row['city']}' 
								data-sno='{$row['sno']}' id='cos-agent'>Agent Status </button>";
						}else{
							$aget ="";
						}

						if($row['procss'] == 0){
									$now_status =  "Returned  ";
									
								}else if($row['procss'] == 2){
									$now_status =  "Processing...";
									
								}else if($row['procss'] == 3){
									$now_status = "Sucessfully Delivared ...";
								}

								if($row['procss'] == 2 || $row['procss'] == 3 ){
									$update = "<button class='btn btn-primary mb-1'   data-upsta='{$row['sno']}'  data-user='{$row['user_id']}'id='recos-upsta'>Settle Payment </button>";
									


								}else{ 
									$update = "";

								}
								if($row['procss'] == 1 ){
									$enter_otp = "<button class='btn btn-primary mb-1'   data-uotp='{$row['sno']}'  data-toggle='modal' data-target='#retotp_otp'data-user='{$row['user_id']}'id='recos-otp'>Enter OTP </button>";

								}else{
									$enter_otp = "";
								}

						if($row['procss'] == 0){
							$boy = "";
						}else{
							$boy = "<tr>
								<td><b>Delivary Agent Details </b></td>
								<td><b>Name : </b> {$row['deli_name']} <b>Phone Number  : </b> {$row['deli_ph']}
								</td>
							</tr>";

						}
					
						echo "	<tr>
								<td><b>Delivaryed On </b></td>
								<td>{$aget}</td>
							</tr>
							<tr>
								<td><b>Category</b></td>
								<td><b>details</b></td>
							</tr>
							<tr>
								<td><b>Costomer Name </b></td>
								<td>{$row['user_id']}</td>
							</tr>
							<tr>
								<td><b>Costomer Name </b></td>
								<td>{$row['fname']} {$row['lname']}</td>
							</tr>
							<tr>
								<td><b>Delivary Address </b></td>
								<td>{$row['address']}</td>
							</tr>
							<tr>
								<td><b>item serial Number & Name </b></td>
								<td><b>No : </b>{$row['itm_sno']} <b>Name : </b>{$row['p_name']}</td>
							</tr>
							<tr>
								<td><b>Payment Id  </b></td>
								<td>{$row['pay_id']}</td>
							</tr>
							<tr>
								<td><b>Ammount ID </b></td>
								<td>{$row['amt']}</td>
							</tr>
							
							<tr>
								<td><b>Payment Status  </b></td>
								<td>{$row['status']}</td>
							</tr>
							
							<tr>
								<td><b>Invioice No  </b></td>
								<td>{$row['invoice']} <br><span><a href='../php/roz/recipt.php?id={$row['pay_id']}'class='btn btn-link bg-primary text-white mt-2 '>print Reciept </a></span></td>
							</tr>
							
							<tr>
								<td><b>Current Status  </b></td>
								<td>{$row['ord_status']} 
								<span>{$update}</span>
								<span>{$enter_otp}</span>
								</td>
							</tr>
							<tr>
								<td><b>Order date </b></td>
								<td>{$row['dat']}</td>
							</tr>
							
							{$boy}
							
							

							";

						
					
					}

					
				}else{ 
					echo "No login";
				}
			?>