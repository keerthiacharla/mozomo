
<?php 

 
	include "../../../infile/config.php";


	   $id = $_POST['id'];
	  $name = $_POST['name'];
	  $ph = $_POST['ph'];
	   	   
				
			$sql = "UPDATE roz SET deli_name = '{$name}', deli_ph ='{$ph}'  WHERE sno = {$id}";

				

				if(mysqli_query($conn,$sql)){

					echo 1;

					

					
				}else{
						echo die("1st query failed");
					}

  ?>
