
	<?php


	include "../../../infile/config.php";

	
				
			$sql = "SELECT deli_statussn.*,roz.ord,roz.deli_otp FROM deli_statussn 
					LEFT JOIN roz ON deli_statussn.ord_id = roz.sno";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						
						echo "<tr>
			       	 			<td>{$row['sno']}</td>
			       	 			<td>{$row['ord']}</td>
			       	 			<td>{$row['s_area']}</td>
			       	 			<td>{$row['d_date']}</td>
			       	 			
			       	 			
			       	 		</tr>";

						
						
					
					}

					
				}else{ 
					echo "<td colspan='4'><h5><center> No Recent Order By Costomer </center></h5></td>";
				}
			?>