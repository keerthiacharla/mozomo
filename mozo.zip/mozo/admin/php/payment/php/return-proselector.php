
<?php 

 
	include "../../../infile/config.php";


 	$id = $_POST['id'];
	
				
			$sql = "SELECT * FROM roz WHERE sno = $id";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					echo $sta = "<option value='select'selected>Select </option>";
					
					while($row = mysqli_fetch_assoc($res)){

						if($row['ord_status'] == 'processing...'){
						echo	$sta = "
									<option value='3'>Payment Send </option>";
						}

						

							}
					
				}else{ 
					echo "No login";
				}

 ?>
