
<div class="payment_items_container d-block p-3">
	<h1 class="bg-primary d-block text-white" id="title">Recent Orders </h1><span>
		
	</span>

<div class="product-items-container">
	
		
		
	<button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#cos_set_data">Recent delivary status </button>

	<div class="product_data collapse p-3" id="cos_set_data">
				
			<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="cos-det-val-search-box" name="cos-det-val-search-box" placeholder="SEARCH">
							</div>
							
						</div>

			        

			       <div class="col-md-12 productdata-container d-lg-flex">

			       	 <div class="col-md-6" id="cos-det-btn">

			       	 

			       	 </div>
			       	 <div class="col-md-6" id="cos-det-con">
			       	 	<table class="table" id="cos-det-table">
			       	 		
						</table>
			       	 
			       	 <?php include "modal/cosupdate-modal.php "?>
			       	 </div>
			       	 
			       </div>
			    </div>


			    <button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#cos_st_set_data">Recent delivery processing status. </button>

	<div class="product_data collapse p-3" id="cos_st_set_data">
				
			<div class="form-group d-flex ml-auto m-3" >

				<button class='btn btn-primary mb-1' data-stup='' id='cos-cust-up-btn' data-toggle='modal' data-target='#deli_change_status'>Status</button>
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="cos-st-det-val-search-box" name="cos-st-det-val-search-box" placeholder="SEARCH">
							</div>
						</div>

			        

			       <div class="col-md-12 productdata-container d-lg-flex">

			       	 <div class="col-md-12" id="cos-det-st-con">
			       	 	<table class="table" border="1" id="">
			       	 		<thead class="bg-primary text-white">
			       	 			<tr>
			       	 				<th>Sno</th>
				       	 			<th>Order Id</th>
				       	 			<th>Status </th>
				       	 			<th>Date </th>
				       	 			
				       	 			
			       	 			</tr>
			       	 			
			       	 		</thead>
			       	 		<tbody id="cos-det-st-table">
			       	 			
			       	 		</tbody>
			       	 		
						</table>
			       	 
			       	 </div>
			       	 
			       	 <?php include "modal/cosupdate-status-modal.php "?>
			       </div>
			    </div>



		<button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#cos_reset_data">Returned costomer status</button>

	<div class="product_data collapse p-3" id="cos_reset_data">
				
			<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="cos-redet-val-search-box" name="cos-redet-val-search-box" placeholder="SEARCH">
							</div>
							
						</div>

			        

			       <div class="col-md-12 productdata-container d-lg-flex">

			       	 <div class="col-md-6" id="cos-redet-btn">

			       	 

			       	 </div>
			       	 <div class="col-md-6" id="cos-redet-con">
			       	 	<table class="table" id="cos-redet-table">
			       	 		
						</table>
			       	 
			       	 <?php include "modal/re-cosupdate-modal.php "?>
			       	 </div>
			       	 
			       </div>
			    </div>
	
			


			    
			    
		</div>

	   
		</div>
<


