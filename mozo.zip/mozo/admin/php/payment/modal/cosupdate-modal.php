<div class="modal fade " id="change_status" data-backdrop="static">
	<div class="modal-dialog e">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 d-flex">
				<h5 class="text-white p-2">Change status </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form class="form" id="up-sta-form">
							<div class="form-group">
			       				<label for="">Change status</label>
			       				<select name="change-status-sel" id="change-status-sel">
			       					
			       				</select>
			       				<!-- <button class="btn btn-primary " id='up-deli-sta'>Update Status </button> -->
			       			</div>
									
							
						</form>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
				
			</div>
			

		</div>
	</div>
</div>
</div>


<div class="modal fade " id="insert_otp" data-backdrop="static">
	<div class="modal-dialog e">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 d-flex">
				<h5 class="text-white p-2">Enter Costomer OTP </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form class="form" id="emter-otp-form">
								<input type="text" class="form-control" id="enterotp-id" name="enterotp-id" hidden>
							<div class="form-group">
			       				<label for="">Enter Costomer OTP </label>
			       				<input type="text" class="form-control" id="enterotp" name="enterotp">
			       				
			       			</div>
			       				<button class="btn btn-primary " id='enter-otp-sta'>Send </button>
									
							
						</form>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
				
			</div>
			

		</div>
	</div>
</div>
</div>


<div class="modal fade " id="return_appli" data-backdrop="static">
	<div class="modal-dialog e">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 d-flex">
				<h5 class="text-white p-2">Return Date  </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							
							

							<div class="form-group m-2">
			       				<label for="">Return Date </label>
			       				<input type="number" minlength="1" maxlength="20" id='ret-dat' name='ret-dat'> Days 
			       			</div>
			       				<button class="btn btn-primary " id='re-app-btn'>Update Status </button>
									
							
						</from>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
				
			</div>
			

		</div>
	</div>
</div>
</div>

<div class="modal fade " id="agent_deli" data-backdrop="static">
	<div class="modal-dialog e">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 d-flex">
				<h5 class="text-white p-2">Agent detals   </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							
							

							<div class="form-group m-2">
			       				<label for="">Agent </label>
			       				<select name="agent-sel" id="agent-sel">
			       					<option value="select" seletet >Select</option>
			       				</select>
			       				<div class="gent-info">
			       					
			       				</div>
			       			</div>
			       				<button class="btn btn-primary " id='agent-btn'>Submit </button>
									
							
						</from>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
				
			</div>
			

		</div>
	</div>
</div>
</div>