<div class="modal fade " id="deli_change_status" data-backdrop="static">
	<div class="modal-dialog e">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 d-flex">
				<h5 class="text-white p-2">Product Current Status  </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
								
							<select name="up-status-id" id="up-status-id" class="form-control">
								<!-- <option value="select"selected>Select</option> -->

							</select>
							</div>
							

							<div class="form-group m-2">
			       				<label for="">Change status</label>
			       				<textarea id="up-status" class="form-control" rows="10" placeholder="Enter Delivary Status "></textarea>
			       			</div>
			       				<button class="btn btn-primary " id='up-st-btn'>Update Status </button>
									
							
						</from>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
				
			</div>
			

		</div>
	</div>
</div>
</div>

