<?php


include "../../../infile/config.php";

 $id = $_POST['did'];
	$dso = $_POST['dso'];

	$sql = "DELETE FROM user WHERE sno = $id;";
	$sql .= "UPDATE emp_details SET status = 'RESIGN' WHERE sno = '{$dso}'";

	
	if(mysqli_multi_query($conn,$sql) == true){
		echo 1;
	}else{
		echo 0;
	}

?>