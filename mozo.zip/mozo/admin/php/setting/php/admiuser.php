<?php 

	 $id= $_POST['id']; 

	  $val= $_POST['val'];
	 
	 
$usname = "Adm". rand(000000,999999);
	/* echo $id . " ".$val ."" .$email;*/
	$pass = md5("admin");


	include "../../../infile/config.php";

	$sql = "UPDATE user SET user_id = '{$usname}', pass = '{$pass}' , role = {$val} WHERE sno = $id";

	if(mysqli_query($conn,$sql)){
		echo 1;
	}else{
		echo 0;
	}



 ?>

 		