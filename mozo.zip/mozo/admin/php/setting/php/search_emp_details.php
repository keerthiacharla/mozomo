<?php 


	include "../../../infile/config.php";
	$search_emp = $_POST['search_emp'];

				
			$sql = "SELECT user.sno, user.name,user.user_id,user.emp_id AS emid,user.role,user.email, emp_details.emp_id AS emp FROM user LEFT JOIN emp_details ON user.emp_id = emp_details.sno 
				WHERE user.name LIKE '%{$search_emp}%' OR emp_details.emp_id LIKE '%{$search_emp}%'  OR user.user_id LIKE '%{$search_emp}%' OR user.email LIKE '%{$search_emp}%' OR user.role LIKE '%{$search_emp}%'";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
						if($row['role'] == 1){
							$role = "Admin";
						}else if($row['role'] == 0){
							$role = "Normal";
						}
					
						echo "<tr>
			       				<td>{$row['sno']}</td>
			       				<td>{$row['emp']}</td>
			       			
			       				<td>{$row['name']}</td>
			       				<td>{$row['user_id']}</td>
			       				<td>{$row['email']}</td>
			       				<td>{$role}</td>
			       				<td><button class='btn-primary d-block m-auto' data-id='{$row['sno']}' id='change-role'  data-toggle='modal'  data-target='#change_user'>Change Role </button></td>
			       				<td><button class='btn-success d-block m-auto' data-pid='{$row['sno']}' id='rpass-user'  >Reset Password </button></td>
			       				<td><button class='btn-danger d-block m-auto' data-did='{$row['sno']}' data-dso='{$row['emid']}'  id='del-user'  >Resign</button></td>
			       				
			       			
			       			</tr>";

						
					
					}

					
				}else{ 
					echo "No login";
				}

 ?>