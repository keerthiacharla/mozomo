<?php 


	include "../../../infile/config.php";

	$id = $_POST['reset_emp'];
	$pass = mysqli_escape_string($conn,md5('admin'));

				
			$sql ="UPDATE users SET password = '{$pass}' WHERE sno = $id";
 
				 if(mysqli_query($conn,$sql) ){
				 	echo 1;
				 }else{
				 	echo 2;
				 }

		

					
				 ?>