<?php 
include "../../../infile/config.php";
		$id = $_POST['uplog_id'];
		$fname = mysqli_escape_string($conn,$_POST['uplog_fname']);
		$lname = mysqli_escape_string($conn,$_POST['uplog_lname']);
		
		$gen = $_POST['uplog_gender'];
		$email = mysqli_escape_string($conn,$_POST['uplog_email']);
		$phone = $_POST['uplog_phone'];
		$add = $_POST['uplog_add'];
		$state = $_POST['uplog_state'];
		$city = $_POST['uplog_city'];
		$zip = $_POST['uplog_zip'];
		$dig = $_POST['uplog-dig'];
		$status = "Employee";

		
		/*$arr = array(
					"userid" => $id,
					"First" => $fname,
					"Last" => $lname,
					
					"Gender" => $gen,
					"phone" => $phone,
					"Email" => $email,
					"Adress" => $add,
					"City" => $city,
					"State" => $state,
					"zip" => $zip,
					"Designation" => $dig,
					"Status" => $status

				);
				echo "<pre>";
					print_r($arr);
				echo "</pre>";*/
	
	$sql = "UPDATE emp_details SET first_name ='{$fname}',last_name ='{$lname}',gen ='{$gen}',phone ='{$phone}',email ='{$email}',address ='{$add}',state ={$state},city = {$city},zip_code = {$zip}, dign='{$dig}' WHERE sno = $id ";

	if(mysqli_query($conn,$sql) == true){
		echo 1;
	}else{
		echo 0;
	}

 ?>

	