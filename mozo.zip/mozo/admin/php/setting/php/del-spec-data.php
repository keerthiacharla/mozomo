<?php


include "../../../infile/config.php";

	$id = $_POST['delspid'];

	$sql = "DELETE FROM speci WHERE sno = $id;"; 
	$sql .= "DELETE FROM specival WHERE under = $id"; 

	
	if(mysqli_multi_query($conn,$sql) == true){
		echo 1;
	}else{
		echo 0;
	}

?>