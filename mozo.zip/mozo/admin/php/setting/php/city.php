<?php 

	

	  $state= $_POST['state'];
	  $city= $_POST['city'];
	 
	 

	 /*echo $state." " .$city;*/
	
	include "../../../infile/config.php";

		
	$sql = "SELECT * FROM city WHERE state_val = {$state} AND city ='{$city}' ";
	$res = mysqli_query($conn,$sql) or die("query failed");

	if(mysqli_num_rows($res)){
		while($row = mysqli_fetch_assoc($res)){
			echo 2;
		}
	}else{
			$sql2 = "INSERT INTO city(state_val,city) VALUES({$state},'{$city}')";
						if(mysqli_query($conn,$sql2) == true){
							echo 1;
						}else{
							echo 0;
						}
					}



 ?>

 		