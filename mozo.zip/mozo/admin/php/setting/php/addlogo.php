<?php 

	
		

		$id = $_POST['brand_name'];
		$file = $_FILES['add_pro_logo']['name'];
		



	/*$arr = array(
		"file"  => $file,
		"Brand " => $prid
			);
				echo "<pre>";
					print_r($arr);
				echo "</pre>";*/


				include "../../../infile/config.php";

				$sql = "SELECT * FROM pro_logo WHERE br_name = $id";

				$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

				/*echo "<option value='select'>Select</option>";*/

				if(mysqli_num_rows($res) > 0){
					while($row = mysqli_fetch_assoc($res)){
						echo 2;



					}
				}else{
					if($file != ""){

		

						$file_temp = $_FILES['add_pro_logo']['tmp_name'];

						$extension = pathinfo($file,PATHINFO_EXTENSION);

						$valid_extension = array("png");
						
						
						if(in_array($extension,$valid_extension) === false){
						
							echo 3;
							
						}else{
							$img =basename($file);
							$target = "logo-Pro/". $img;
							$image_name = $img; 
							
							
							
							if(move_uploaded_file($file_temp,$target)){
								
								$conn = mysqli_connect("localhost","root","","mozomo") or die("connection failed");

								$sql = "INSERT INTO pro_logo 
												(logo,br_name)
												VALUES('{$img}',{$id})";
											
										if(mysqli_query($conn,$sql) == true){
											echo 1;
										}else{
											echo 0;
										}
							}else{
								echo "file is uploade error";
								
							}
						}
						
						
						

								
						
						
					}else{
						echo "Please upload image of product";
					}
				}

				/**/

				

/**/

 ?>


