<?php


include "../../../infile/config.php";

	$offset = 0;
	$sql = "SELECT speci.sno, speci.spec_title, category.c_name FROM speci LEFT JOIN category ON speci.p_name = category.sno ORDER BY sno DESC ";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){

		$serial = $offset + 1;
		while($row = mysqli_fetch_assoc($res)){
			/*echo $row['sno']." ". $row['c_name']." ". $row['pname']."<br>";*/
			echo "<tr>
	       				<td>{$serial}</td>
	       				<td>{$row['spec_title']}</td>
	       				<td>{$row['c_name']}</td>
	       				<td>{$row['sno']}</td>
	       				<td><button class='btn btn-danger d-block m-auto ' data-spdid='{$row['sno']}' id='spec-del-btn'>Delete</button></td>
	       			</tr>";

	       			$serial++;
		}

		
	}else{
		echo "No data Found ";
	}



?>