<?php


include "../../../infile/config.php";


	
	$sql = "SELECT images.sno AS img_sno, images.img_id AS img_id, images.img_name AS img, mobile.sno AS mob_sno,mobile.ml_name AS mob_br, category.c_name AS brname  FROM images
		 LEFT JOIN mobile ON images.img_id = mobile.sno 
		 
		 LEFT JOIN  category  ON images.pro_no = category.sno WHERE pro_no = 1 ORDER BY images.sno DESC";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){

		

		while($row = mysqli_fetch_assoc($res)){
			/*echo $row['sno']." ". $row['c_name']." ". $row['pname']."<br>";*/

		

			

			echo "<tr>
			       		<td>{$row['img_sno']}</td>
			       		<td>{$row['brname']}</td>
			       		<td><img src='php/product/php/Mobile-images/{$row['img']}' alt='' id='slide-img'></td>
			       		
			       		
			       		
			       		
			       		
			       		<td><button class='btn btn-danger' data-slpid='{$row['img_sno']}' id='slprotab_delbtn'>DELETE</button></td>
			       	</tr>";

	       			
		}

		
	}else{
		echo "No data Found ";
	}



?>