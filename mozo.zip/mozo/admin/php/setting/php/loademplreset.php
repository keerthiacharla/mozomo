<?php 


	include "../../../infile/config.php";
	$id = $_POST['id'];

				
			$sql = "SELECT emp_details.*,state.state AS state_name, city.sno AS city_num ,city.city AS city_name FROM emp_details 
					LEFT JOIN state ON emp_details.state = state.sno
					LEFT JOIN city ON emp_details.city = city.sno
					 WHERE emp_details.sno = $id";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
						 
					
						echo "<tr rowspan='2'>
								<td colspan='2'>
								<button class='btn btn-primary mb-1'
								 data-emplup='{$row['sno']}'  
								 data-fname='{$row['first_name']}' 
								 data-lname='{$row['last_name']}' 
								 data-email='{$row['email']}' 
								 data-ph='{$row['phone']}' 
								 data-add='{$row['address']}' 
								 data-zip='{$row['zip_code']}' 
								 data-dign='{$row['dign']}'  
								 data-city='{$row['city_name']}' 
								 data-cno='{$row['city_num']}' 
								 data-gen='{$row['gen']}' 


								 id='empl-update' data-toggle='modal' data-target='#empl-update-modal-box'>Update Data </button>
								</td>
							 </tr>
							 <tr rowspan='2'>
								<td colspan='2'>
								<button class='btn btn-primary mb-1' data-prno='{$row['sno']}' id='empl-print' data-toggle='modal' data-target=''>Print Data </button>
								</td>
							 </tr>

							<tr>
								<td><b>Category</b></td>
								<td><b>details</b></td>
							</tr>
							<tr>
								<td><b>Employee photo </b></td>
								<td><img src='php/index/php/photos/{$row['image']}' alt='' id='empl-photo'></td>
							</tr>
							<tr>
								<td><b>Joining Date  </b></td>
								<td>{$row['join_date']}</td>
							</tr>
							<tr>
								<td><b>Employee ID </b></td>
								<td>{$row['emp_id']}</td>
							</tr>
							<tr>
								<td><b>Employee Name </b></td>
								<td>{$row['first_name']} {$row['last_name']}</td>
							</tr>
							<tr>
								<td><b>Gender </b></td>
								<td>{$row['gen']}</td>
							</tr>
							<tr>
								<td><b>Phone</b></td>
								<td>{$row['phone']}</td>
							</tr>
							<tr>
								<td><b>Email </b></td>
								<td>{$row['email']}</td>
							</tr>
							<tr>
								<td><b>Address </b></td>
								<td>{$row['address']}, {$row['city_name']}, {$row['state_name']} -{$row['zip_code']}</td>
							</tr>
							<tr>
								<td><b>Employee Designation </b></td>
								<td>{$row['dign']}</td>
							</tr>
							<tr>
								<td><b>Employee Current Status  </b></td>
								<td>{$row['status']}</td>
							</tr>
							
							";

						
					
					}

					
				}else{ 
					echo "No login";
				}

 ?>