<?php 

	include "../../../infile/config.php";

if($_POST['uptype'] == ""){
	$id = $_POST['id'];

	$sql0 = "SELECT emp_details.state AS state_val, state.state AS state_name  FROM emp_details  LEFT JOIN state  on emp_details.state = state.sno  WHERE emp_details.sno ='{$id}'";

	$res0 = mysqli_query($conn,$sql0) or die("offerheader.php query failed");

	$str = "";

	while($row0 = mysqli_fetch_assoc($res0)){
		
				$sql = "SELECT * FROM state";

				$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

				/*$str .= "<option value='{$row0['state_val']}' selected >{$row0['state_name']}</option>";*/
				while($row = mysqli_fetch_assoc($res)){

						if($row0['state_val'] == $row['sno']){
							$sel = "selected";

						}else{
							$sel = "";
						}
						$str .= "<option value='{$row['sno']}'{$sel}>{$row['state']}</option>";



					}

		}


	
	
}else if($_POST['uptype'] == "upstatedata"){

	
	
	$sql2 = "SELECT * FROM city WHERE state_val = {$_POST['upid']}";

	$res2 = mysqli_query($conn,$sql2) or die("offerheader.php query failed");
	
	$str = "";

		while($row2 = mysqli_fetch_assoc($res2)){
			$str .= "<option value='{$row2['sno']}'>{$row2['city']}</option>";


	}
}
 echo $str;

?>