<?php

$search =$_POST['search'];

include "../../../infile/config.php";

	$sql = "SELECT pro.sno, pro.pname, category.c_name FROM pro LEFT JOIN category ON pro.cid = category.sno WHERE pro.pname LIKE '%{$search}%' OR category.c_name LIKE '%{$search}%'";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){  
		while($row = mysqli_fetch_assoc($res)){
			/*echo $row['sno']." ". $row['c_name']." ". $row['pname']."<br>";*/
			echo "<tr>
	       				<td>{$row['sno']}</td>
	       				<td>{$row['pname']}</td>
	       				<td>{$row['c_name']}</td>
	       				<td><button class='btn btn-danger d-block m-auto ' data-did='{$row['sno']}' id='pro-del-btn'>Delete</button></td>
	       			</tr>";


		}
	}else{
		echo "No data Found ";
	}



?>