<?php 
		include "../../../infile/config.php";
		$emp_id = "mozoemp". rand(000000,999999);
		$fname = mysqli_escape_string($conn,$_POST['log_fname']);
		$lname = mysqli_escape_string($conn,$_POST['log_lname']);
		
		$gen = mysqli_escape_string($conn,$_POST['log_gender']);
		$email = mysqli_escape_string($conn,$_POST['log_email']);
		$phone = $_POST['log_phone'];
		$add = $_POST['log_add'];
		$state = $_POST['log_state'];
		$city = $_POST['log_city'];
		$zip = $_POST['log_zip'];
		$dig = $_POST['log-dig'];
		$date = $_POST['datepicker'];
		$status = "Employee";

		
		/*$arr = array(
					"userid" => $emp_id,
					"First" => $fname,
					"Last" => $lname,
					
					"Gender" => $gen,
					"phone" => $phone,
					"Email" => $email,
					"Adress" => $add,
					"City" => $city,
					"State" => $state,
					"State" => $zip,
					"Designation" => $dig,
					"Status" => $status,
					"date" => $date

				);
				echo "<pre>";
					print_r($arr);
				echo "</pre>";*/

		$sql = "SELECT * FROM emp_details WHERE  email ='{$email}' OR phone ='{$phone}'";
		$res = mysqli_query($conn,$sql) or die("conn failed");

			if(mysqli_num_rows($res) > 0){
			
					echo "file is already exsist";
					die();

				
			
			}else{
					$sql2 = "INSERT INTO 
					emp_details(emp_id,first_name,last_name,gen,phone,email,address,state,city,zip_code,dign,status,join_date) 
					VALUES('{$emp_id}','{$fname}','{$lname}','{$gen}','{$phone}','{$email}','{$add}',{$state},{$city},{$zip},'{$dig}','{$status}','{$date}')";
						if(mysqli_query($conn,$sql2)){
							echo 1;
						}else{
							echo "Qury Faild";
			

			}
		}
		



		

 ?>