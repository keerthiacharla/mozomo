<?php 

	 $spe_name = $_POST['add_speci'];
	 $pro_id = $_POST['product-cat-seldata'];

	/* echo $spe_name . " ".$pro_id ;*/


	include "../../../infile/config.php";

		
	$sql = "SELECT * FROM speci WHERE spec_title = '{$spe_name}' AND p_name = $pro_id";
	$res = mysqli_query($conn,$sql) or die("query failed");

	if(mysqli_num_rows($res)){
		while($row = mysqli_fetch_assoc($res)){
			echo 2;
		}
	}else{
			$sql2 = "INSERT INTO speci(spec_title,p_name) VALUES('{$spe_name }',{$pro_id})";
						if(mysqli_query($conn,$sql2) == true){
							echo 1;
						}else{
							echo 0;
						}
	}


 ?>

 		