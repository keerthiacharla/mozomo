<?php 

	  $id= $_POST['id'];
	 

	/* echo $spe_name . " ".$pro_id ;*/


	include "../../../infile/config.php";

		
	$sql = "SELECT * FROM emp_details WHERE sno = $id";
	$res = mysqli_query($conn,$sql) or die("query failed");

	if(mysqli_num_rows($res)){
		while($row = mysqli_fetch_assoc($res)){
			
			$emp_id = $row['emp_id'];

			$email = $row['email'];
		
			$otp = rand(1000,9999);

			$sql1 = "SELECT * FROM user WHERE email = '{$email}'";
				
			$res1 = mysqli_query($conn,$sql1) or die(" 2nd conn failed");

					if(mysqli_num_rows($res1)){
						while($row1 = mysqli_fetch_assoc($res1)){

							if($row1['email'] == $email){
								echo "";
								die();

							}

						}
		

					}else{
							$sql2 = "INSERT INTO otp_exp(email,otp) VALUES('{$email}',{$otp})";
				
												if(mysqli_query($conn,$sql2)){
													echo "				
														<div class='form-group'>
														<input type='text' id='add_user_emaliid' name='add_user_emaliid' value='{$email}' >
															<label for=''>Enter OTP</label>
															<input type='text' class='form-control' id='add_user_otp' name='add_user_otp' placeholder='****' maxlength='4'>
															
														</div>
														<div class='time  w-100 m-2 text-danger'><p>OTP LIMIT IS :-  <span id='sec'>60  </span> SECONDS</p>
													</div>
														<button class='btn btn-primary ' id='user_submit' data-id='{$id}'> Submit</button>
													";
												}else{
													echo "not";
												};
						} 

			

		
			

			

		}
	}else{
			echo 0;
	}


 ?>

 			<!--  -->