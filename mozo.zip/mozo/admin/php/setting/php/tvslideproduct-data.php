<?php


include "../../../infile/config.php";


	
	$sql = "SELECT images.sno AS img_sno, images.img_id AS img_id, images.img_name AS img, television.sno AS tv_sno,television.ml_name AS tv_br, category.c_name AS brname  FROM images
		 LEFT JOIN television ON images.img_id = television.sno 
		 
		 LEFT JOIN  category  ON images.pro_no = category.sno WHERE pro_no = 2 ORDER BY images.sno DESC";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){

		

		while($row = mysqli_fetch_assoc($res)){
			/*echo $row['sno']." ". $row['c_name']." ". $row['pname']."<br>";*/

			

			

			echo "<tr>
			       		<td>{$row['img_id']}</td>
			       		<td>{$row['brname']}</td>
			       		<td><img src='php/product/php/tv-images/{$row['img']}' alt='' id='slide-img'></td>
			       		<td><button class='btn btn-danger' data-tvslpid='{$row['img_sno']}' id='tvslprotab_delbtn'>DELETE</button></td>
			       	</tr>";

	       			$serial++;
		}

		
	}else{
		echo "No data Found ";
	}



?>