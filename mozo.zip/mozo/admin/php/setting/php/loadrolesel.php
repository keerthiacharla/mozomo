<?php 


	include "../../../infile/config.php";

	$id = $_POST['id'];
				
			$sql = "SELECT * FROM user WHERE sno  = $id";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
						
					
						 if($row['role'] == 1){
						 	$sel = "<option value='1' selected>Admin</option>
						 			<option value='0'>Normal</option>";
						 }else{
						 	$sel = "<option value='0' selected>Normal</option>
						 			<option value='1'>Admin</option>";
						 }
							echo $sel;

						
					
					}

					
				}else{ 
					echo "No login";
				}

 ?>