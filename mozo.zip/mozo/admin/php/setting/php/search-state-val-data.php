<?php


include "../../../infile/config.php";

	$search_state = $_POST["search_state"];
	
	$sql = "SELECT * FROM state WHERE state LIKE '%{$search_state}%'";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){

	
		while($row = mysqli_fetch_assoc($res)){
			/*echo $row['sno']." ". $row['c_name']." ". $row['pname']."<br>";*/
			echo "<tr>
	       				
	       				<td>{$row['sno']}</td>
	       				<td>{$row['state']}</td>
	       				
	       				<td><button class='btn btn-danger d-block m-auto ' data-stid='{$row['sno']}' id='state-del-btn'>Delete</button></td>
	       			</tr>";

	       			
		}

		
	}else{
		echo "No data Found ";
	}



?>