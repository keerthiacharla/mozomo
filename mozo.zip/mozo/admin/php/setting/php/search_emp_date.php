<?php 

 
	include "../../../infile/config.php";
				
			$search_key = $_POST["search_val"];
	
				$sql = "SELECT * FROM emp_details WHERE join_date LIKE '%{$search_key}%'";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
						
					
						echo "<button class='btn btn-primary mb-1' data-empl='{$row['sno']}' id='empl-brn'>{$row['emp_id']}</button> <br>";

						
					
					}

					
				}else{ 
					echo "Nobody Employee is found ";
				}

 ?>