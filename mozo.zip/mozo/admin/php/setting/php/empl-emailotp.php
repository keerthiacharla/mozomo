<?php 

	  $id= $_POST['id'];
	 

	/* echo $spe_name . " ".$pro_id ;*/


	include "../../../infile/config.php";

		
	$sql = "SELECT * FROM emp_details WHERE sno = $id";
	$res = mysqli_query($conn,$sql) or die("query failed");

	if(mysqli_num_rows($res)){
		while($row = mysqli_fetch_assoc($res)){
			
			
			echo "		<label for=''>Email</label>
									<input type='text' id='otp_email' name='otp_email' class='form-control' value='{$row['email']}'>
									<div class='input-group-append'>
										<span class='input-grounp-text'>
											<button class='btn btn-primary ' id='user_otp'> Get OTP</button>
										</span>
									</div>	
								
							";
			

			

		}
	}else{
			
	}


 ?>

 		