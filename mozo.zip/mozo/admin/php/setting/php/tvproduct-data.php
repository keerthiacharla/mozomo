<?php


include "../../../infile/config.php";

	$offset = 0;
	
	$sql = "SELECT television.ml_name,television.ml_no,television.sno,television.br_name ,pro.pname FROM television LEFT JOIN pro ON pro.cid = television.br_name ";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){

		$serial = $offset + 1;
		while($row = mysqli_fetch_assoc($res)){
			/*echo $row['sno']." ". $row['c_name']." ". $row['pname']."<br>";*/
			echo "<tr>
			       		<td>{$serial}</td>
			       		<td>{$row['pname']}</td>
			       		<td>{$row['ml_name']}</td>
			       		<td>{$row['ml_no']}</td>
			       		<td><button class='btn btn-danger' data-tvpid='{$row['sno']}' id='tvprotab_delbtn'>DELETE</button></td>
			       	</tr>";

	       			$serial++;
		}

		
	}else{
		echo "No data Found ";
	}



?>