<?php

	 $id = $_POST['id'] ;
	

	include "../../../infile/config.php";

	$sql = "SELECT * FROM emp_details WHERE sno = {$id}";
	$res = mysqli_query($conn,$sql) or die("query failed");

	if(mysqli_num_rows($res)){
		while($row = mysqli_fetch_assoc($res)){

			$email = $row['email'];
			$sql2 = "DELETE FROM otp_exp WHERE email ='{$email}'";
						if(mysqli_query($conn,$sql2)){
							echo 1;
						}else{
							echo 0;
						}
		}
	}else{
		echo 0;
			
	}




 ?>