<?php


include "../../../infile/config.php";

	$offset = 0;
	$sql = "SELECT pro_logo.sno, pro_logo.logo,pro_logo.br_name,pro.pname FROM pro_logo LEFT JOIN pro ON pro_logo.br_name = pro.sno 
		ORDER BY sno DESC ";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){

		$serial = $offset + 1;
		while($row = mysqli_fetch_assoc($res)){
			/*echo $row['sno']." ". $row['c_name']." ". $row['pname']."<br>";*/
			echo "<tr>
	       				<td>{$serial}</td>
	       				<td>{$row['pname']}</td>
	       				<td><img src='php/setting/php/logo-Pro/{$row['logo']}' alt='' height='100px' width='150px'></td>
	       				<td><button class='btn btn-danger d-block m-auto ' data-logoid='{$row['sno']}' id='del-prologo-btn'>Delete</button></td>
	       			</tr>";

	       			$serial++;
		}

		
	}else{
		echo "No data Found ";
	}



?>