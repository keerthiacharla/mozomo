<?php 

	 $id= $_POST['id']; 

	  $val= $_POST['val'];
	 
	 
$usname = "Nor". rand(000000,999999);
	/* echo $id . " ".$val ."" .$email;*/


	include "../../../infile/config.php";

	$sql = "UPDATE user SET user_id = '{$usname}', role = {$val} WHERE sno = $id";

	if(mysqli_query($conn,$sql)){
		echo 1;
	}else{
		echo 0;
	}



 ?>

 		