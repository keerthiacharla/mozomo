<?php


include "../../../infile/config.php";

	$offset = 0;
	
	$sql = "SELECT mobile.ml_name,mobile.ml_num,mobile.sno,mobile.br_name ,pro.pname FROM mobile LEFT JOIN pro ON pro.cid = mobile.br_name ";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){

		$serial = $offset + 1;
		while($row = mysqli_fetch_assoc($res)){
			/*echo $row['sno']." ". $row['c_name']." ". $row['pname']."<br>";*/
			echo "<tr>
			       		<td>{$serial}</td>
			       		<td>{$row['pname']}</td>
			       		<td>{$row['ml_name']}</td>
			       		<td>{$row['ml_num']}</td>
			       		<td><button class='btn btn-danger' data-pid='{$row['sno']}' id='protab_delbtn'>DELETE</button></td>
			       	</tr>";

	       			$serial++;
		}

		
	}else{
		echo "No data Found ";
	}



?>