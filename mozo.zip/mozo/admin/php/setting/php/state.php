<?php 

	

	  $val= $_POST['val'];
	 
	 

	/* echo $val;*/
	
	include "../../../infile/config.php";

		
	$sql = "SELECT * FROM state WHERE state = '{$val}' ";
	$res = mysqli_query($conn,$sql) or die("query failed");

	if(mysqli_num_rows($res)){
		while($row = mysqli_fetch_assoc($res)){
			echo 2;
		}
	}else{
			$sql2 = "INSERT INTO state(state) VALUES('{$val}')";
						if(mysqli_query($conn,$sql2) == true){
							echo 1;
						}else{
							echo 0;
						}
					}



 ?>

 		