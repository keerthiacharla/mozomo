<?php


include "../../../infile/config.php";

	$id = $_POST['stid'];

	$sql = "DELETE FROM state WHERE sno = $id"; 
	

	
	if(mysqli_query($conn,$sql) == true){
		echo 1;
	}else{
		echo 0;
	}

?>