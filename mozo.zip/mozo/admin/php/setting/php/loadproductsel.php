<?php 


	include "../../../infile/config.php";

	$sql = "SELECT * FROM category";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){
		while($row = mysqli_fetch_assoc($res)){
			echo "<option value='{$row['sno']}'>{$row['c_name']}</option>";



		}
	}else{
		echo "No data Found ";
	}

 ?>