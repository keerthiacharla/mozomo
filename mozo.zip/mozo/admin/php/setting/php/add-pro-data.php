<?php 

	  $pro_name = $_POST['add_pro'];
	   $sbr_name = $_POST['product-cat-seldata'];


	include "../../../infile/config.php";
	$sql = "SELECT * FROM pro WHERE pname = '{$pro_name}' AND cid = $sbr_name";
	$res = mysqli_query($conn,$sql) or die("query failed");

	if(mysqli_num_rows($res)){
		while($row = mysqli_fetch_assoc($res)){
			echo 2;
		}
	}else{
			$sql2 = "INSERT INTO pro(pname,cid) VALUES('{$pro_name }',{$sbr_name})";
						if(mysqli_query($conn,$sql2) == true){
							echo 1;
						}else{
							echo 0;
						}
	}


				

 
 ?>