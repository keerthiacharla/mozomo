<?php


include "../../../infile/config.php";

	$search_city = $_POST["search_city"];
	
	$sql = "SELECT * FROM city WHERE state_val LIKE '%{$search_city}%' OR city LIKE '%{$search_city}%'" ;

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){

	
		while($row = mysqli_fetch_assoc($res)){
			/*echo $row['sno']." ". $row['c_name']." ". $row['pname']."<br>";*/
			echo "<tr>
	       				
	       				<td>{$row['sno']}</td>
	       				<td>{$row['city']}</td>
	       				<td>{$row['state_val']}</td>
	       				
	       				<td><button class='btn btn-danger d-block m-auto ' data-cyid='{$row['sno']}' id='city-del-btn'>Delete</button></td>
	       			</tr>";

	       			
		}

		
	}else{
		echo "No data Found ";
	}



?>