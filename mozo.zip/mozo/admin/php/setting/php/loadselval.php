<?php


include "../../../infile/config.php";

	$offset = 0;
	$sql = "SELECT specival.sno, specival.s_val, speci.spec_title, category.c_name,input.in_type FROM specival 
	LEFT JOIN category ON specival.pname = category.sno
	LEFT JOIN speci ON specival.under = speci.sno
	LEFT JOIN input ON specival.in_type = input.sno
	ORDER BY specival.sno DESC ";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){

		$serial = $offset + 1;
		while($row = mysqli_fetch_assoc($res)){
			/*echo $row['sno']." ". $row['c_name']." ". $row['spec_title']." ". $row['s_val']." ". $row['in_type']."<br>";*/
			echo "<tr>
	       				<td>{$serial}</td>
	       				<td>{$row['c_name']}</td>
	       				<td>{$row['spec_title']}</td> 
	       				<td>{$row['s_val']}</td>
	       				
	       				<td><button class='btn btn-danger d-block m-auto ' data-spvaldid='{$row['sno']}' id='specval-del-btn'>Delete</button></td>
	       			</tr>";

	       			$serial++;
		}

		
	}else{
		echo "No data Found ";
	}



?>