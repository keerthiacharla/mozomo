<?php

/**/


	
	include "../../../infile/config.php";

	$sql = "SELECT * FROM input";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){
		while($row = mysqli_fetch_assoc($res)){
			echo "<option value='{$row['sno']}'>{$row['in_type']}</option>";


		}
	}else{
		echo "No data Found ";
	}



?>