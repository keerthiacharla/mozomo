<?php


include "../../../infile/config.php";

	$id = $_POST['logoid'];
	
	$sql = "SELECT *  FROM pro_logo WHERE sno = $id" ;

	$res = mysqli_query($conn,$sql) or die("Query failed");

	if(mysqli_num_rows($res) > 0){
		while($row = mysqli_fetch_assoc($res)){
			 $img = $row['logo'];

			 $sql2 = "DELETE FROM pro_logo WHERE sno = $id" ;
		

				if(mysqli_query($conn,$sql2)){
						echo 1;
					}else{
						echo 0;
					}
		}
	}
	
	unlink("../../setting/php/logo-Pro/".$img)


?>