<?php
	 $cat_name = $_POST['add_cate'];


	include "../../../infile/config.php";

				$sql = "INSERT INTO category(c_name) VALUES('{$cat_name}')";
						if(mysqli_query($conn,$sql) == true){
							echo 1;
						}else{
							echo 0;
						}
?>