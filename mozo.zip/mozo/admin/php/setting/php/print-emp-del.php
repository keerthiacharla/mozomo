<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../../../infile/bootstrap/bootstrap4.css">
	
	<link rel="stylesheet" href="css/print-emp-del.css?v=111">
	<title>Document</title>
</head>
<body>
	


	<div class="container">
		<div class="row">
			<div class=" col-md-9 header-con d-flex ">
				<h1> MOZOMO </h1>
				

			</div>

			<?php 

				date_default_timezone_set("Asia/Kolkata")



			 ?>
			<div class=" col-md-3  ">
				<h5 class="date mr-auto"> Prited on :<?php echo date("d-m-Y h:i:sa") ?></h5>
				

			</div>

		</div>
		<div class="row first-p">
			<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit voluptatem dolore, quisquam sequi maiores eius vitae. Molestias neque excepturi dolor et alias ducimus esse reiciendis dicta, aliquam minima numquam rerum architecto, ad, reprehenderit doloremque deserunt impedit voluptate quisquam quos. Suscipit ut rem magnam quos vero, quia ipsam fugiat aut perspiciatis, sed quae alias unde nisi architecto dolore perferendis, laborum recusandae accusamus officia sunt velit iste soluta quidem voluptate. Dolore saepe, obcaecati tempore aspernatur minus voluptate omnis numquam sit, reiciendis dolor, alias quam fugiat dolorem odio debitis repellendus molestias praesentium temporibus quasi facilis cum cupiditate aliquid? Eius mollitia officia fugit hic ullam, fugiat, provident temporibus totam beatae minus maiores et rerum, sequi accusantium distinctio veritatis, tempora quam autem porro adipisci eum.</p>
		</div>
		<div class="row">
		<div class="col-md-9 ">
				<table class="table "  width="100">
					<thead class="">
						<tr>				
							<th>category </th>
							<th>Details </th>
						
						</tr>
					</thead>
					<?php 

					include "../../../infile/config.php";

					$id =  $_GET['id'] ;

						$sql = "SELECT emp_details.*,state.state AS state_name, city.sno AS city_num ,city.city AS city_name FROM emp_details 
								LEFT JOIN state ON emp_details.state = state.sno
								LEFT JOIN city ON emp_details.city = city.sno
								 WHERE emp_details.sno = $id";

							$res = mysqli_query($conn,$sql) or die(" query failed");

							if(mysqli_num_rows($res) > 0){

								
								while($row = mysqli_fetch_assoc($res)){

					?>
					<tbody>
						<tr>
							<td><b>Joining Date </b></td>
							<td><?php echo $row['join_date']?></td>
						</tr>
						<tr>
							<td><b>Employee ID </b></td>
							<td><?php echo $row['emp_id']?></td>
						</tr>
						<tr>
							<td><b>Employee Name  </b></td>
							<td><?php echo $row['first_name']." ".
							$row['last_name']?></td>
						</tr>
						<tr>
							<td><b>Gender  </b></td>
							<td><?php echo $row['gen']?></td>

						</tr><tr>
							<td><b>Phone </b></td>
							<td><?php echo $row['phone']?></td>
						</tr>
						<tr>
							<td><b>Email </b></td>
							<td><?php echo $row['email']?></td>
						</tr>
						<tr>
							<td><b>Address  </b></td>
							<td><?php echo $row['address']." ". $row['city_name']." ". $row['state_name'] ." -". $row['zip_code']?></td>
						</tr>
						<tr>
							<td><b>Employee Digination  </b></td>
							<td><?php echo $row['dign']?></td>
						</tr>
						<tr>
							<td><b>Employee Status   </b></td>
							<td><?php echo $row['status']?></td>
						</tr>
					</tbody>
					

			</table>
		</div>
		<div class="col-md-3 emp-img text-center">
		
			<img src="../../index/php/photos/<?php echo $row['image']?>" alt="Photo">
		
		</div>
		<?php 

					}
				}

					?>
	</div>
	<div class="row sec-p">
		<p>	Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quas ducimus commodi quam, eveniet odit sequi hic perspiciatis fuga! Veniam sunt dolor adipisci, perspiciatis deserunt exercitationem alias sapiente beatae, praesentium quos minima culpa velit nesciunt aperiam, saepe modi eum itaque ratione deleniti cupiditate sequi quo ex excepturi odit? Totam optio et labore harum ut facilis est, vitae dolores consequuntur necessitatibus, obcaecati dicta voluptas ea aspernatur odit maiores quod reiciendis excepturi incidunt corrupti numquam quaerat aperiam dolore corporis atque! Quis error, modi perferendis omnis sed. Cupiditate aliquid veniam consequuntur nihil exercitationem possimus?</p>
	</div>
	<div class="row">
		<div class="col-md-3 d-flex sing ml-auto">
			<img src="../../../infile/eauth.jpg" alt="" class="emp-sing ml-auto"><br>
			<h2 class=" m-auto">Emploiyee Authorizier Officer </h2>
		</div>
	</div>
	<button class="btn btn-primary d-block m-auto " id="print">Print </button>
	</div>
	
	
	
</body>
</html>
<script src="../../../infile/js/jquery.js"></script>
<script type="text/javascript">


	
	$(document).ready(function(){
		alert("a");
		$("#print").click(function(e){
			e.preventDefault();
			window.print();

		})
	})
</script>