<?php

/**/
	
	/*$id = $_POST['id'];*/

	
	include "../../../infile/config.php";

	$sql = "SELECT * FROM pro ";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	echo "<option value='select'>Select</option>";

	if(mysqli_num_rows($res) > 0){
		while($row = mysqli_fetch_assoc($res)){
			echo "<option value='{$row['sno']}'>{$row['pname']}</option>";


		}
	}else{
		echo "No data Found ";
	}

	/**/


?>