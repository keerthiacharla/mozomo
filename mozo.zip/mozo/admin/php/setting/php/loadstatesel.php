<?php 


	include "../../../infile/config.php";

	$sql = "SELECT * FROM state";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){
		echo "<option value='select'>Select</option>";
		while($row = mysqli_fetch_assoc($res)){
			echo "<option value='{$row['sno']}'>{$row['state']}</option>";



		}
	}else{
		echo "No data Found ";
	}

 ?>