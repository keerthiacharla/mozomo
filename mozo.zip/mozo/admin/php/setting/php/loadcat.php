<?php

/**/


	
include "../../../infile/config.php";

	$sql = "SELECT * FROM category";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){
		while($row = mysqli_fetch_assoc($res)){
			echo "<tr>
	       				<td>{$row['sno']}</td>
	       				<td>{$row['c_name']}</td>
	       			</tr>";


		}
	}else{
		echo "No data Found ";
	}



?>