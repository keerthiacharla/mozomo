<?php


include "../../../infile/config.php";

	$id = $_POST['id'];
	
	$sql = "SELECT *  FROM mobile WHERE sno = $id" ;

	$res = mysqli_query($conn,$sql) or die("Query failed");

	if(mysqli_num_rows($res) > 0){
		while($row = mysqli_fetch_assoc($res)){
			 $img = $row['file'];

			 $sql2 = "DELETE FROM mobile WHERE sno = $id" ;
		

				if(mysqli_query($conn,$sql2)){
						echo 1;
					}else{
						echo 0;
					}
		}
	}
	
	unlink("../../product/php/Mobile-images/".$img)


?>