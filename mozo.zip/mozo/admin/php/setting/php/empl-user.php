<?php 

	  $id= $_POST['id'];
	  $email= $_POST['email'];
	  $val= $_POST['val'];
	 

	/* echo $id . " ".$val ."" .$email;*/


	include "../../../infile/config.php";

	$sql = "SELECT * FROM otp_exp WHERE otp = $val";
				
		$res = mysqli_query($conn,$sql) or die(" 2nd conn failed");

			
			if(mysqli_num_rows($res)){
				while($row = mysqli_fetch_assoc($res)){
					
					 if($row['otp'] == $val){

					 	$sql1 = "SELECT * FROM emp_details WHERE sno = $id";
						$res1 = mysqli_query($conn,$sql1) or die(" 2nd query failed");

								if(mysqli_num_rows($res1)){
									while($row1 = mysqli_fetch_assoc($res1)){
										
										$emp_id = $row1['emp_id'];
										$name = $row1['first_name']. " ".$row1['last_name'];
										$email1 = $row1['email'];
										$usname = "Nor". rand(000000,999999);
										$pass = mysqli_escape_string($conn,md5('admin'));
										$role = 0;

										$sql2 = "INSERT INTO user(emp_id,name,user_id,pass,email,role) VALUES({$id},'{$name}','{$usname}','{$pass}','{$email1}',{$role}) ";
													if(mysqli_query($conn,$sql2) == true){
														echo 1;
													}else{
														die("3nd query failed");
													}

									}
								}else{
										
								}
					 }else{
					 	echo 0;
					 }


					}
			}

		
	





	/**/


 ?>

 		