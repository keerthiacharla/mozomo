<?php 

	 $id= $_POST['pid']; 

	 /*echo $id ;*/
	
	$pass = md5("admin");

	include "../../../infile/config.php";

	$sql = "UPDATE user SET pass = '{$pass}' WHERE sno = $id";

	if(mysqli_query($conn,$sql)){
		echo 1;
	}else{
		echo 0;
	}



 ?>

 		