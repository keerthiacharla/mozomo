<?php 

	 $sp_name = $_POST['secipro-cat-seldata'];
	 $under = $_POST['speci-seldata'];
	 $val = $_POST['add_val_speci'];
	/* $intype = $_POST['add_speci-intype'];*/

	 /*echo $sp_name . " ".$under. " ".$val ;*/


	include "../../../infile/config.php";

		
	$sql = "SELECT * FROM specival WHERE pname = $sp_name AND under = $under AND s_val = '{$val}' ";
	$res = mysqli_query($conn,$sql) or die("query failed");

	if(mysqli_num_rows($res)){
		while($row = mysqli_fetch_assoc($res)){
			echo 2;
		}
	}else{
			$sql2 = "INSERT INTO specival(pname,under,s_val) VALUES({$sp_name},{$under},'{$val}')";
						if(mysqli_query($conn,$sql2) == true){
							echo 1;
						}else{
							echo 0;
						}
	}


 
