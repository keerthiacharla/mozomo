
<div class="product_items_container d-block p-3">
	<h1 class="bg-primary d-block text-white" id="title">Product Modification</h1><span>
		
	</span>

<div class="product-items-container">
	<button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#product_set_data">Mobile</button>

			<div class="product_data collapse p-3" id="product_set_data">
				<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="pro-item-search-box" name="pro-item-search-box" placeholder="SEARCH">
							</div>
						</div>
			  

			       <div class="col-md-12 productdata-container d-lg-flex">
			       	

			       	<table class="table" id="producttable">
			       		<thead class="bg-primary text-white">
			       			<tr>
			       				<th>Sno</th>
			       				<th>Brand </th>
			       				<th>Brand Name</th>
			       				<th>Brand Number</th>
			       				<th>Delete</th>
			       				
			       			</tr>
			       		</thead>
			       		<tbody id="productable_row"></tbody>

			       		
			       	</table>
			       			
			       	 
			       	  
			       </div>
			    </div>


	<button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#tvproduct_set_data">Television</button>

			<div class="product_data collapse p-3" id="tvproduct_set_data">
				<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="pro-item-search-box" name="pro-item-search-box" placeholder="SEARCH">
							</div>
						</div>
				
			
			        

			       <div class="col-md-12 tvproductdata-container d-lg-flex">

			       	<table class="table" id="tvproducttable">
			       		<thead class="bg-primary text-white">
			       			<tr>
			       				<th>Sno</th>
			       				<th>Brand </th>
			       				<th>Brand Name</th>
			       				<th>Brand Number</th>
			       				<th>Delete</th>
			       				
			       			</tr>
			       		</thead>
			       		<tbody id="tvproductable_row"></tbody>
			       	</table>
			       	 
			       	  
			       </div>
			    </div>
<button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#img_product_set_data">Mobile Slide Images </button>

			<div class="product_data collapse p-3" id="img_product_set_data">
				<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="img_pro-item-search-box" name="img_pro-item-search-box" placeholder="SEARCH">
							</div>
						</div>
				
			
			        

			       <div class="col-md-12 img_productdata-container d-lg-flex">

			       	<table class="table" id="img_producttable">
			       		<thead class="bg-primary text-white">
			       			<tr>
			       				<th>Sno</th>
			       				<th>Brand </th>
			       				<th>Mobile View/Cancelled</th>
			       				<th>Delete</th>
			       				
			       			</tr>
			       		</thead>
			       		<tbody id="img_productable_row"></tbody>
			       	</table>
			       	 
			       	  
			       </div>
			    </div>
			    <button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#tv_img_product_set_data">Television Slide Images </button>

			<div class="product_data collapse p-3" id="tv_img_product_set_data">
				<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="tv_img_pro-item-search-box" name="tv_img_pro-item-search-box" placeholder="SEARCH">
							</div>
						</div>
				
			
			        

			       <div class="col-md-12 tv_img_productdata-container d-lg-flex">

			       	<table class="table" id="tv_img_producttable">
			       		<thead class="bg-primary text-white">
			       			<tr>
			       				<th>Sno</th>
			       				<th>Brand </th>
			       				<th>Mobile View/Cancelled</th>
			       				<th>Delete</th>
			       				
			       			</tr>
			       		</thead>
			       		<tbody id="tv_img_productable_row"></tbody>
			       	</table>
			       	 
			       	  
			       </div>
			    </div>
	   
</div>
</div>
