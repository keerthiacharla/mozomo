
<div class="product_items_container d-block p-3">
	<h1 class="bg-primary d-block text-white" id="title">Employee Modification</h1><span>
		
	</span>

<div class="product-items-container">
	
		<?php include "modal/emlogin-modal.php "?>

		
	<button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#emldel_set_data">Employee Details</button>

			<div class="product_data collapse p-3" id="emldel_set_data">
				<button class="btn btn-primary d-block ml-auto " data-toggle="modal" data-target="#emlogin-add">ADD</button>

					<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="emldel-val-search-box" name="emldel-val-search-box" placeholder="SEARCH">
							</div>
							<div class="form-gouup">
									
									<div class="input-group">
									<input type="text" class="form-control" id="date-find" name="date-find" value="" placeholder="Search Joining Date">
									<div class="input-group-append">
										<button class="btn btn-primary" id="search_date">Search</button>
									</div>
									</div>
								</div>
						</div>

			        

			       <div class="col-md-12 productdata-container d-lg-flex">

			       	 <div class="col-md-6" id="show-empl-btn">
			       	 	
			       	 </div>
			       	 <div class="col-md-6" id="show-empl-con">
			       	 	<table class="table" id="show-empl-table">

			       	 		

			       	 	</table>
			       	 <?php include "modal/emlogin-update-modal.php "?>
			       	 </div>
			       	 
			       </div>
			    </div>


			    
			    <?php include "modal/emlogin-modal.php "?>
			    

			    <button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#emlogin_data">Employee Login Modification</button>

			<div class="product_data collapse p-3" id="emlogin_data">
				<button class="btn btn-primary d-block ml-auto " data-toggle="modal" data-target="#signup-form">ADD</button>
							<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="emlpmob--search-box" name="emlpmob--search-box" placeholder="SEARCH">
							</div>
						</div>

			        

			       <div class="col-md-12 productdata-container d-lg-flex">

			       	<table class="table" id="emlogin-table">
			       		<thead class="bg-primary text-white">
			       			<tr>
			       				<th>Sno</th>
			       				<th>Emploiyee Id </th>	
			       				<th>Name </th>	
			       				<th>User Id  </th>	
			       				<th>Email </th>	
			       				<th>User</th>	
			       				<th>Change User</th>	
			       				<th>Reset Password</th>	
			       				<th>Resign </th>	
			       				
			       			</tr>
			       		</thead>
			       		<tbody id="emlogin_row">
			       			
			       			
			       		</tbody>
			       	</table>
			       	 
			       	  
			       </div>

			       


			       <?php include "modal/change.php "?>


			    </div>

	   			<?php include "modal/singup.php "?>
			       
		</div>

	   
		</div>
</div>


