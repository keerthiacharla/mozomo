<div class="modal fade " id="state-add" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Add state</h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="state-add-form">
								<label for="">Add State</label>
								<input type="text" class="form-group" id="state_input" name="state_input">
								<button class="btn btn-success " name="state_input-sub" id="state_input-sub">Susmit</button>
							</form>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
			</div>

		</div>
	</div>
</div>

<div class="modal fade " id="city-add" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Add City</h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="state-add-form">
								<div class="form-group">
									<label for="">Select State </label>
										<select name="city-seldata" id="city-seldata" class="form-control-sm add-pro-val" >
											<option value="select">Select</option>
											
										</select>
								</div>
								<div class="form-group">
									<label for="">Add City</label>
									<input type="text" class="form-group" id="add_city" name="addcity">
								</div>
								<button class="btn btn-success " name="add-city-sub" id="add-city-sub">Susmit</button>
							</form>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
			</div>

		</div>
	</div>
</div>