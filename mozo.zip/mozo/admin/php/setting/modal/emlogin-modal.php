<div class="modal fade " id="emlogin-add" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Employee Details    </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action=""  class="form p-1" id="user-det-form">
								<div class="form-gouup">
									<label for="">Joining Date  </label>
									<input type="text" id="datepicker" name="datepicker">
								</div>
								<div class="form-gouup">
									<label for="">First Name </label>
									<input type="text" class="form-control" name="log_fname" id="log_fname" placeholder="Enter Your First Name ">
								</div>
								<div class="form-gouup">
									<label for="">Last Name </label>
									<input type="text" class="form-control" name="log_lname" id="log_lname" placeholder="Enter Your Last Name ">
								</div>

									
									<div class="form-group">
											<div class="form-group form-inline p-2">
												<label for="" class="d-flex">Gender <span id="" class="gen_na_error color_fild">*</span> </label>
												<input type="radio" class="form-control m-2 log_gender" id="male" name="log_gender" value="Male">
												<label for="male">Male </label>
												<input type="radio" class="form-control m-2 log_gender" id="female" name="log_gender" value="Female">
												<label for="female">Female </label>
											</div>
										</div>
								
								<div class="form-gouup">
									<label for="">Email Name </label>
									<input type="text" class="form-control" name="log_email" id="log_email" placeholder="Enter Your Email ID ">
								</div>
								<div class="form-gouup">
									<label for="">Phone </label>
									<input type="text" class="form-control" name="log_phone" id="log_phone" placeholder="Enter Your Phone Number" maxlength="10">
								</div>
								<div class="form-gouup">
									<label for="">Address </label>
									<textarea name="log_add" class="form-control"  id="log_add"  cols="30" rows="10" placeholder="Enter Your address  "></textarea>
								</div>
								<div class="form-gouup">
									<label for="">State </label>
									<select name="log_state" class="form-control custom-select" id="log_state" >				
										
									</select>
								</div>
								<div class="form-gouup ">
									<label for="">City </label>
									<select name="log_city" class="form-control custom-select" id="log_city">
									</select>
								</div>
								<div class="form-gouup">
									<label for="">Zip Code  </label>
									<input type="text" class="form-control" name="log_zip" id="log_zip" placeholder="Enter Your Pin Code ">
								</div>
								<div class="form-gouup">
									<label for="">Digination  </label>
									<input type="text" class="form-control" name="log-dig" id="log-dig" placeholder="Enter Your Digination ">
								</div>
								
								<button class="btn btn-primary mt-2 " id="user-det-btn"> Save Details </button>



							</form>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
			</div>

		</div>
	</div>
</div>
 