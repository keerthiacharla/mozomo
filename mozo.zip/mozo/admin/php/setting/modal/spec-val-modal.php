<div class="modal fade " id="spe-val-add" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Add Specifications Values </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="spec-val-add-form">
								<div class="form-group">
									<label for="">Brand </label>
										<select name="secipro-cat-seldata" id="secipro-seldata" class="form-control-sm secipro-seldata-val" >
											<option value="select">Select</option>
											
										</select>
								</div>
								<div class="form-group">
									<label for=""> Specifications Under</label>
										<select name="speci-seldata" id="speci-seldata" class="form-control-sm speci-seldata" >
											
											
										</select>
								</div>
								<div class="form-group">
									<label for=""> Specifications Value</label>
									<input type="text" class="form-group" id="add_val_speci" name="add_val_speci">
								</div>
								

								<button class="btn btn-success " name="add_speci-val-button" id="add_speci-val-button">Susmit</button>
							</form>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
			</div>

		</div>
	</div>
</div>
