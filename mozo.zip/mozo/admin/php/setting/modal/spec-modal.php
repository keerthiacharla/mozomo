<div class="modal fade " id="spe-add" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Add Specifications</h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="spec-add-form">
								<div class="form-group">
									<label for="">Brand </label>
										<select name="product-cat-seldata" id="product-cat-seldata" class="form-control-sm add_speci_val" >
											<option value="select">Select</option>
											
										</select>
								</div>
								<div class="form-group">
									<label for="">Add Specifications</label>
									<input type="text" class="form-group add_speci" id="add_speci" name="add_speci">
								</div>
								<button class="btn btn-success " name="add_speci-sub" id="add_speci-sub">Susmit</button>
							</form>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
			</div>

		</div>
	</div>
</div>
