<div class="modal fade " id="signup-form" data-backdrop="static">
	<div class="modal-dialog e">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 d-flex">
				<h5 class="text-white p-2">Add Users </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<div class="form-group">
									
							<form action="" class="form p-0" id="empsel_form">
								
								<div class="form-group">
									<label for=""> Select User</label>
									<select name="empl_id" id="empl_id" class="form-control">
										<option value=""></option>
										
									</select>
								</div>
								<div class="form-group input-group" id="otp_email">
									
									
								</div>
									

							</form>

							<form action="" class="form p-0" id="singup_otp_form">
							</form>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
				
			</div>
			

		</div>
	</div>
</div>




