
<div class="set_items_container d-block p-3">
	<h1 class="bg-primary d-block text-white" id="title">Setting</h1><span>
		
	</span>

<div class="setting-items-container">
	<button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#set_data" id="cat-view">Category</button>

			<div class="set_data collapse p-3" id="set_data">
				<button class="btn btn-primary d-block ml-auto " data-toggle="modal" data-target="#cat-add">ADD</button>
			
			         <?php include "modal/cat-modal.php "?>

			       <div class="col-md-12 set-data-container d-lg-flex">

			       	<table class="table" id="category_table">
			       		<thead class="bg-primary text-white">
			       			<tr>
			       				<th>Sno</th>
			       				<th>Category Name</th>
			       				
			       			</tr>
			       		</thead>
			       		<tbody id="category_table_row"></tbody>
			       	</table>
			       	 
			       	  
			       </div>
			    </div>
			    <!-- logo -->
	<button class="bg-primary d-block text-white p-1  m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#products-logo" id="pro-logo-view">Products Log's</button>

	<div class="set_data collapse p-3" id="products-logo">

		<button class="btn btn-primary d-block ml-auto " data-toggle="modal" data-target="#product-logo-add">ADD</button><span>
			
		</span>
				 <?php include "modal/products-logo-modal.php "?>

						<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="pro-search-logo-box" name="pro-search-logo-box" placeholder="SEARCH">
							</div>
						</div>
				
	       		<div class="col-md-12 set-data-container d-lg-flex">
				     	<table class="table" id="products_data_logo_table" border="1">
				       		<thead class="bg-primary text-white">
				       			<tr>
				       				<th>Sno</th>
				       				<th>Product</th>
				       				<th>logo</th>
				       				<th>Delete</th>
				       			</tr>
				       		</thead>
				       		<tbody id="products_data_logo_table_row">
				       			
				       		</tbody>
				       	</table>
	       	 	  </div>
	    		</div>

	    <!-- products -->

	<button class="bg-primary d-block text-white p-1  m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#products-table" id="product-view">Products</button>

	<div class="set_data collapse p-3" id="products-table">

		<button class="btn btn-primary d-block ml-auto " data-toggle="modal" data-target="#product-items-add">ADD</button><span>
			
		</span>
				 <?php include "modal/product-modal.php "?>

						<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="pro-search-box" name="pro-search-box" placeholder="SEARCH">
							</div>
						</div>
				
	       		<div class="col-md-12 set-data-container d-lg-flex">
				     	<table class="table" id="products_data_table">
				       		<thead class="bg-primary text-white">
				       			<tr>
				       				<th>Sno</th>
				       				<th>Product</th>
				       				<th>Product Name</th>
				       				<th>Delete</th>
				       			</tr>
				       		</thead>
				       		<tbody id="products_data_table_row">
				       			
				       		</tbody>
				       	</table>
	       	 	  </div>
	    		</div>



	    <!-- specification -->


	<button class="bg-primary d-block text-white p-1  m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#spec-table">Specifications</button>

	<div class="set_data collapse p-3" id="spec-table">

		<button class="btn btn-primary d-block ml-auto " data-toggle="modal" data-target="#spe-add">ADD</button>
		
	         <?php include "modal/spec-modal.php "?>

	       				<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="spe-search-box" name="spe-search-box" placeholder="SEARCH">
							</div>
						</div>


	       			<div class="spec-text m-2">
	       				<table class="table" id="speci_data_table">
					       		<thead class="bg-primary text-white">
					       			<tr>
					       				<th>Sno</th>
					       				<th>specification</th>
					       				<th>Product Name</th>
					       				<th>Insert No</th>
					       				<th>Delete</th>
					       			</tr>
					       		</thead>
					       		<tbody id="speci_data_table_row">
					       			
					       		</tbody>
					       	</table>
	       			</div>
	       	   </div>


	    <!-- speci values -->
	
	<button class="bg-primary d-block text-white p-1  m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#spec-val-table">Specifications Value </button>

	<div class="set_data collapse p-3" id="spec-val-table">
		<button class="btn btn-primary d-block ml-auto " data-toggle="modal" data-target="#spe-val-add">ADD</button>
			
	         <?php include "modal/spec-val-modal.php "?>

	       			<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="spe-val-search-box" name="spe-val-search-box" placeholder="SEARCH">
							</div>
						</div>

	       			<div class="spec-text m-2">
	       				<table class="table" id="speci_data_table">
					       		<thead class="bg-primary text-white">
					       			<tr>
					       				<th>Sno</th>
					       				<th>Product Name</th>
					       				<th>Spcification Under</th>
					       				<th>Values</th>
					       				
					       				<th>Delete</th>
					       			</tr>
					       		</thead>
					       		<tbody id="specival_data_table_row">
					       			
					       		</tbody>
					       	</table>
	       				
	       			</div>
	       			
	       	  
	       </div>
	  
	       <!-- input Setting  -->

<button class="bg-primary d-block text-white p-1  m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#input-set">input Settings  </button>
			<!-- input Group for CITY -->
	<div id="input-set" class="collapse">
		<button class="bg-primary d-block text-white dropdown-toggle w-100 p-1 m-3"  data-toggle="collapse" data-target="#city-table">City  </button>

			<div class="set_data collapse p-3" id="city-table">
				<button class="btn btn-primary d-block ml-auto " data-toggle="modal" data-target="#state-add">ADD</button>
					
			         <?php include "modal/spec-val-modal.php "?>

			       			<div class="form-group d-flex ml-auto m-3" >
									<div class="form-group m-2 serch-item d-block ml-auto">
										<input type="text" class="form-control d-block ml-auto " id="state-val-search-box" name="state-val-search-box" placeholder="SEARCH">
									</div>
								</div>

			       			<div class="spec-text m-2">
			       				<table class="table" id="state_data_table">
							       		<thead class="bg-primary text-white">
							       			<tr>
							       				<th>Sno</th>
							       				<th>State Name</th>
							       				
							       				
							       				<th>Delete</th>
							       			</tr>
							       		</thead>
							       		<tbody id="state_data_table_row">
							       			
							       		</tbody>
							       	</table>
			       				
			       			</div>
			       			
			       	  
			       </div>



			       <!-- input Group for District -->

			       <button class="bg-primary d-block text-white dropdown-toggle p-1 w-100 m-3"  data-toggle="collapse" data-target="#dis-table">Distrit  </button>

			<div class="set_data collapse p-3" id="dis-table">
				<button class="btn btn-primary d-block ml-auto " data-toggle="modal" data-target="#city-add">ADD</button>
					
			         <?php include "modal/spec-val-modal.php "?>

			       			<div class="form-group d-flex ml-auto m-3" >
									<div class="form-group m-2 serch-item d-block ml-auto">
										<input type="text" class="form-control d-block ml-auto " id="city-val-search-box" name="city-val-search-box" placeholder="SEARCH">
									</div>
								</div>

			       			<div class="spec-text m-2">
			       				<table class="table" id="city_data_table">
							       		<thead class="bg-primary text-white">
							       			<tr>
							       				<th>Sno</th>
							       				<th>City</th>
							       				<th>State</th>
							       				
							       				
							       				<th>Delete</th>
							       			</tr>
							       		</thead>
							       		<tbody id="city_data_table_row">
							       			
							       		</tbody>
							       	</table>
			       				
			       			</div>
			       			
			       	  
			       </div>
			   </div>

			   <?php include "modal/input-data.php "?>

			   <!-- Title Logo -->
	 <button class="bg-primary d-block text-white p-1  m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#tiltle-logo-tb">Website Logo </button>

	<div class="set_data collapse p-3" id="tiltle-logo-tb">
		<button class="btn btn-primary d-block ml-auto " data-toggle="modal" data-target="#logo-main-add">ADD</button>
			
	         <?php include "modal/logo-modal.php "?>

	       			

	       			<div class="spec-text m-2">
	       				<img src="infile/logo.gif" alt="" style="height: 250px; width : 100% " >
	       				
	       			</div>
	       			
	       	  
	       </div>
	 </div>
	</div>
