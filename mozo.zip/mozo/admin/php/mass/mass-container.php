
<div class="mass_items_container p-3">
	<div class="row " id="mass-opp-conatiner">
		<div class="col-4 align-self-center" id="mass-opp">
			<li class="m-5 btn-link inbox active-btn " id="inbox"><h3 class="">Inbox </h3>
				<span id="uread-status">New</span></li>
			
			<li class="m-5 btn-link send" id="send"><h3>Send </h3></li>
		</div>
		<div class="col-8" id="mass-opp-conatiner">
			<div class="mass-div">
				
					
						<table class='table' border='1' id="mass-del-table" >
							<thead>
								<tr>
									
									<td><b>Massage</b></td>
									<td><b>Date</b></td>
								</tr>
							</thead>
							<tbody class="mass-del"></tbody>
				
						</table>
				</div>
			
				
			


			<!-- all Massage  -->
			<div class="send-del">
				<div class="form-group form-inline">
						<a href="#" id="del-all" class="btn-link ml-3">Delete All</a>
					</div>
					
						<table class='table' border='1' id="mass-send-del-table" >
							<thead>
								<tr>
									<td><input type="checkbox" id="del-all-opp" class="form-control-sm ml-3">
									</td>
									<td><b>Massage</b></td>
									<td><b>Date</b></td>
								</tr>
							</thead>
							<tbody class="send-mass-del"></tbody>
				
						</table>
				
			</div>
			</div>
		<?php include "php/modal/massage-read.php"?>

	</div>




			    
			    
			  

	   
		</div>



