
<?php 

 
	include "../../../infile/config.php";


			
			$sql = "SELECT cos_mass.*, cos_users.fname,cos_users.lname FROM cos_mass
					LEFT join cos_users ON cos_mass.cname = cos_users.sno 
					WHERE cos_mass.mass_status = 'Unread' ||cos_mass.mass_status = 'Read'
					ORDER BY sno DESC
					";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					while($row = mysqli_fetch_assoc($res)){

						if($row['mass_status'] == "Unread"){
							$new_tag = "<span class='ml-auto' id='div-uread-status'><img src='../infile/new.gif' alt='no image'></span>";
						}else{
							$new_tag = "";
						}

						echo "<tr>
									

									<td>{$new_tag}<b>{$row['cname']} {$row['fname']}  {$row['lname']} -> {$row['mass_type']}</b><br> 
									<a href='#' id='mass-show-btn' data-sid ='{$row['sno']}' data-toggle='modal' data-target='#see_mass'>Show Massage </a> 
									</td>

										<td> </b><div class='mass-date ml-auto'>{$row['mass_date']}

										
									</tr>	";

							}
					
				}else{ 
					echo "<td colspan='3'><center><h3>No Massages </h3></center></td>";
				}

 ?>
