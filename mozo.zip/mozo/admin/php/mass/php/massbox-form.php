<?php 

	$id = $_POST['cosmass_id'];
	$name = $_POST['cosmass_cos'];
	$opp = $_POST['cosmass_opp'];
	$mass = $_POST['cosmass_mass'];
	$date = date("d-m-Y");

	include "../../../infile/config.php";

		$sql2 = "UPDATE cos_mass SET mass_status = 'Replayed' ,mas_rly = '{$mass}', rly_date = '{$date}' WHERE sno = $id";

								 if(mysqli_query($conn,$sql2)){
								 	echo 1;
								 }else{
								 	echo mysqli_error($conn);
								 }

	

 ?>