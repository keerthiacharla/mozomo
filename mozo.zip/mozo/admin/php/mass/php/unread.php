
<?php 

 
	include "../../../infile/config.php";


			
			$sql = "SELECT * FROM cos_mass WHERE mass_status = 'unread'";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					echo mysqli_num_rows($res) . "<b>Unread Massage</b> ";
					
				}else{ 
					echo "";
				}

 ?>
