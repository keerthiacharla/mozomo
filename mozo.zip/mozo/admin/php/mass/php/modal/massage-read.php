<div class="modal fade " id="see_mass" data-backdrop="static">
	<div class="modal-dialog e">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 d-flex">
				<h5 class="text-white p-2">Read Massage </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<div class="mass-box">
					
							</div>
						</div>
					</div>

				</div>
			<div class="modal-footer">
				
				
			</div>
			

		</div>
	</div>
</div>
</div>`


<div class="modal fade " id="see_rep_mass" data-backdrop="static">
	<div class="modal-dialog e">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 d-flex">
				<h5 class="text-white p-2">Read Massage </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<div class="mass-rep-box">
					
							</div>
						</div>
					</div>

				</div>
			<div class="modal-footer">
				
				
			</div>
			

		</div>
	</div>
</div>
</div>`



<div class="modal fade " id="rpl" data-backdrop="static">
	<div class="modal-dialog e">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 d-flex">
				<h5 class="text-white p-2">Send Massage</h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" class="form" id="mass-form">
								<input type="text" class="" value="" name="cosmass_id" id="cosmass_id" hidden>
								<input type="text" class="" value="" name="cosmass_cos" id="cosmass_cos" hidden>
								<input type="text" class="" value="" name="cosmass_opp" id="cosmass_opp" hidden>
								<div class="form-group">
									<label for="">Massage</label><br>
									<textarea name="cosmass_mass" id="cosmass_mass"  cols="30" class="form-control"></textarea>
								</div>
								<button class="btn btn-primary " id="sub-mass-btn">Send Massage</button>
							</form>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
				
			</div>
			

		</div>
	</div>
</div>
</div>








