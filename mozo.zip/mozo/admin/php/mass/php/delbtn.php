<?php 

	echo $id = $_POST['id'];


		echo "


 ?>