
<?php 

 
	include "../../../infile/config.php";

		$id = $_POST['id'];
			
			$sql = "SELECT * FROM cos_mass WHERE sno = $id";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					while($row = mysqli_fetch_assoc($res)){

						echo "<p>
							<b>Massage Option</b> {$row['mass_opp']}</p>
							<p><b>Massage </b>{$row['massage']}.</p>
					
						<a href='#' id='mass-rly-btn' data-rid ='{$row['sno']}' data-cos='{$row['cname']}'data-opp='{$row['mass_opp']}' data-toggle='modal' data-target='#rpl'>Reply </a>
					";

								$sql2 = "UPDATE cos_mass SET mass_status = 'Read' WHERE sno = $id";

								 if(mysqli_query($conn,$sql2)){
								 	echo "";
								 }else{
								 	echo 0;
								 }

							}
					
				}else{ 
					echo "No login";
				}

 ?>
