
<?php 

 
	include "../../../infile/config.php";


			
			$sql = "SELECT cos_mass.*, cos_users.fname,cos_users.lname FROM cos_mass
					LEFT join cos_users ON cos_mass.cname = cos_users.sno 
					WHERE cos_mass.mass_status = 'Replayed' 
					ORDER BY sno DESC
					";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					while($row = mysqli_fetch_assoc($res)){

						if($row['mass_status'] == "Unread"){
							$new_tag = "<span class='ml-auto' id='div-uread-status'><img src='../infile/new.gif' alt='no image'></span>";
						}else{
							$new_tag = "";
						}

						echo "<tr>
									<td><center><input type='checkbox' class='mr-3 form-control-sm mass_opp' id='{$row['sno']}' name='mass-del-opp' value='{$row['sno']}'></center></td>

									<td><b>{$row['cname']} {$row['fname']}  {$row['lname']} -> {$row['mass_type']}</b><br> 
									<a href='#' id='mass-show-btn' data-repsid ='{$row['sno']}' data-toggle='modal' data-target='#see_rep_mass'>Show Massage </a> 
									</td>

										<td> </b><div class='mass-date ml-auto'>{$row['mass_date']}

										{$new_tag}
									</tr>	";

							}
					
				}else{ 
					echo "No login";
				}

 ?>
