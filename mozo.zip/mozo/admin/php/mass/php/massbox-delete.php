<?php 
	
	include "../../../infile/config.php";
	$id = $_POST['id'];
	
	echo $convert = implode($id,",");


	

	 $sql = "DELETE FROM cos_mass WHERE sno IN ($convert)";

	 if(mysqli_query($conn,$sql)){
	 	echo 1;

	 }else{
	 	echo mysqli_error($conn);
	  }

 ?>