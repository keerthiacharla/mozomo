<div class="product_items_container">
	<h1 class="bg-primary d-block text-white" id="title">Product Section</h1>

	<div class="product_data">
		<button class="btn btn-primary d-block ml-auto" data-toggle="modal" data-target="#product-add">ADD</button>
	</div>
	         <?php include "modal/product-modal.php "?>

	         <div class="view-conatiner">
	         	<div class="title-container">
	         		<button class="btn btn-primary d-block m-3 p-1 w-100 " id="mob-view" data-toggle="collapse" data-target=".imfor-container">Mobile </button>
	         	</div>
	         	<div class="imfor-container collapse">
	         		<div class="row  m-3">
	         			<div class="col-md-3" id="mob-btn-container">
	         				
	         				
	         			</div>
	         			<div class="col-md-7" id="mob-table-con">
	         				<table class="table" border="1" id="data-table">
	         					
	         						


	         							
	         					</tbody>
	         				</table>

	         				<?php include "modal/product-imgview-modal.php" ?>


	         				
	         			</div>
	         		</div>

	         	</div>
	         	

	         		<div class="title-container">
	         		<button class="btn btn-primary d-block m-3 p-1 w-100 " id="tv-view" data-toggle="collapse" data-target=".tv-imfor-container">Television </button>
	         	</div>
	         	<div class="tv-imfor-container collapse">
	         		<div class="row  m-3">
	         			<div class="col-md-3" id="tv-btn-container">
	         				<button class="btn btn-primary" id="tv-item-btn">click me </button>
	         				
	         			</div>
	         			<div class="col-md-7" id="tv-table-con">
	         				<table class="table" border="1" id="tv-data-table">
	         					
	         				</table>
	         				<?php include "modal/tvproduct-imgview-modal.php" ?>
	         			</div>
	         		</div>
	         		
	         	</div>







	         </div>
	         </div>


	         
