<?php 

 $uprate = $_POST['tvupdatesel'];
	


	include "../../../infile/config.php";;

				
				$sql = "SELECT * FROM television WHERE  sno = $uprate";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						if($row['off_rate'] == "No Offer"){
							echo "<option value='0' selected >No Offer</option>
								 <option value='1'>Yes</option>";
						}else{
							echo "<option value='1' selected >Yes</option>
								 <option value='0'>No Offer</option>" ;
						}
					
					}


					
				}else{
					echo "No data Found ";
				}



 ?>