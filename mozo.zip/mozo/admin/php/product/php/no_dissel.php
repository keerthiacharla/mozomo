<?php 


	$id = $_POST['id'];
	 
	 

	

			$conn = mysqli_connect("localhost","root","","mozomo") or die("connection failed");

			$sql = "UPDATE mobile SET dis_mode = 2 WHERE sno = $id";

				if(mysqli_query($conn,$sql) ){
					echo 1;
				}else{
					echo 0;
				}




 ?>