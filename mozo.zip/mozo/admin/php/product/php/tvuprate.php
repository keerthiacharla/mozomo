<?php 


	 $id = $_POST['id'];
	 $newrate = $_POST['nrate'];

			include "../../../infile/config.php";

				
				$sql = "UPDATE television SET amt = '{$newrate}', off_rate = 'No Offer' WHERE sno = $id";

				if(mysqli_query($conn,$sql) ){
					echo 1;
				}else{
					echo 0;
				}




 ?>