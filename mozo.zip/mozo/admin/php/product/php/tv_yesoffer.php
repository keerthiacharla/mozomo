<?php 


	 $id = $_POST['btv_id'];
	  $rate = $_POST['tvotup'];
	  $off = $_POST['tvval'];
	 

	
include "../../../infile/config.php";

			$sql = "UPDATE television SET off_rate = '{$rate}', off_per = '{$off}' WHERE sno = $id";

				if(mysqli_query($conn,$sql) ){
					echo 1;
				}else{
					echo 0;
				}




 ?>