<?php 
session_start();
date_default_timezone_set("Asia/Kolkata");

	if(empty($_POST['mob-ot-input'])){
		$mob_others = null;
	}else{
		$mob_others = ", ".$_POST['input-color'];
	}
	if(empty($_POST['mob-cam'])){
		$mob_cam  = "No";
	}else{
		$mob_cam =$_POST['mob-cam']." ". "MEGA PIXCEL";
	}
	if(empty($_POST['mob-sec-cam'])){
		$mob_scam  = "No";
	}else{
		$mob_scam = $_POST['mob-sec-cam']." ". "MEGA PIXCEL" ;
	}
	if(empty($_POST['mob-resol'])){
		$mob_resol  = "No";
	}else{
		$mob_resol = $_POST['mob-resol'];
	}
	if(empty($_POST['mob-os'])){
		$mob_os  = "No";
	}else{
		$mob_os = $_POST['mob-os'];
	}
		$name = $_SESSION['name'];

		$prid = $_POST['pro_id'];
		$file = $_FILES['mob-img']['name'];
		$brand_name = $_POST['mob-pro-br'];
		$modal_name = $_POST['model-name'];
		$modal_number = $_POST['model-no'];
		
		$tec = $_POST['mob-tec'];
		
		$color = join($_POST['mob-color-val'],", "). $mob_others;
		$tec = $_POST['mob-tec'];
		
		$ram = $_POST['mob_ram'];
		$display = $_POST['mob-dt'];
		$resol = $mob_resol;
		$os = $mob_os;
		$fea = join($_POST['mob-fea-val'],", ");
		$manu = $_POST['mob-manu'];
		
		$battery = $_POST['mob-bat'];
		$made = $_POST['mob_made'];
		$storage = $_POST['mob-sto'];
		$disc = $_POST['mob-dis'];
		$amt = $_POST['mob-price'];
		$dmode = $_POST['dis-mode'];
		$off_rate =  $_POST['mob-off-rate'];
		$date = date("d-m-Y l",strtotime("now"));

		if($off_rate == 0 || $off_rate == ""){
			$off = "No Offer";
		}else{
			$m = $amt * $off_rate/100;
			$off = $amt - $m;
		}

		/*if($dmode == 1){
			$display = "Display";
		}else{
			$display = "No";
		}*/
			


	/*$arr = array(
		"file"  => $file,
		"Brand name" => $brand_name,
		"Modal Name" => $modal_name,
		"Modal Number" => $modal_number,
		"Technology" => $tec,
		"color" => $color,
		"Primary Camera" => $pri_camera,
		"Secondary Camera" => $sec_camera,
		"Ram" => $ram,
		"Display type" => $display ,
		"Resolution" => $resol ,
		"Operating System" => $os ,
		"Feautures" => $fea ,
		"Manufacture" => $manu ,
		"Storage" => $storage ,
		"Made in" => $made  ,
		"Discription" => $disc ,
		"Ammount" => $amt ,
		"Offer Rate" => $off_rate 
			
			);
				echo "<pre>";
					print_r($arr);
				echo "</pre>";*/

if($file != ""){

		

		$mob_file_temp = $_FILES['mob-img']['tmp_name'];

		$mob_extension = pathinfo($file,PATHINFO_EXTENSION);

		$mob_valid_extension = array("jpg","jpeg");
		
		
		if(in_array($mob_extension,$mob_valid_extension) === false){
		
			echo "File is not support.. please uploade jpg ,jpeg";
			
		}else{
			$mob_img ="mobile_"." ".rand()." -" .basename($file);
			$mob_target = "Mobile-images/". $mob_img;
			$mob_image_name = $mob_img; 
			
			
			
			if(move_uploaded_file($mob_file_temp,$mob_target)){
				
				include "../../../infile/config.php";

				$sql = "INSERT INTO mobile 
								(empl_name,file,br_name,ml_name,ml_num,tec,color,pr_cam,se_cam,ram,dis_type,resol,os,fea,manu,sto,made,disc,amt,off_rate,off_per,dis_mode,pro_name)
								VALUES('{$name}','{$mob_img}',{$brand_name},'{$modal_name}','{$modal_number}','{$tec}','{$color}','{$mob_cam}','{$mob_scam}','{$ram}','{$display}','{$resol}','{$os}','{$fea}','{$manu}','{$storage}','{$made}','{$disc}','{$amt}','{$off}','{$off_rate}',{$dmode},{$prid})";
							
						if(mysqli_query($conn,$sql) == true){
							echo 1;
						}else{
							echo 0;
						}
			}else{
				echo "file is uploade error";
				
			}
		}
		
		
		

				
		
		
	}else{
		echo "Please upload image of product";
	}

 ?>