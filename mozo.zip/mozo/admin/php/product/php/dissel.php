<?php 

 $updis = $_POST['disid'];


 					if($updis == 1){
							echo "<option value='1' selected >Display</option>
								 <option value='2'>None</option>";   
						}else{
							echo "<option value='2' selected >None</option>
								 <option value='1'>Display</option>" ;
						}
					
					
	


	



 ?>