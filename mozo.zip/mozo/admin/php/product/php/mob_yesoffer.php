<?php 


	$id = $_POST['btn_id'];
	 $rate = $_POST['totup'];
	 $per = $_POST['valueup'];
	 

	

		include "../../../infile/config.php";

			$sql = "UPDATE mobile SET off_per ='$per', off_rate =  '{$rate}' WHERE sno = $id";

				if(mysqli_query($conn,$sql) ){
					echo 1;
				}else{
					echo 0;
				}




 ?>