
<?php 

			include "../../../infile/config.php";

				
				$sql = "SELECT * FROM mobile";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						echo "<button class='btn btn-primary m-2 mob-item-btn' id='mob_item' data-vid= '{$row['sno']}' >{$row['ml_name']}' </button>  <br>

						";
					
					}

					
				}else{
					echo "No data Found ";
				}






 ?>


 