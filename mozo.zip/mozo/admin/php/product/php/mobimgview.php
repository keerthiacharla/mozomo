<?php 

	$img_id = $_POST['cid'];
	$p_id = $_POST['pnme'];
	


	include "../../../infile/config.php";

				
				$sql = "SELECT * FROM images WHERE  img_id = $img_id AND pro_no = $p_id"; 

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						echo "<div>
								<span class='text-center bg-primary d-block text-white'>{$row['sno']}</span>
								<a href='php/product/php/Mobile-images/{$row['img_name']}' title=''><img src='php/product/php/Mobile-images/{$row['img_name']}' alt=''id='mob-add-flex'></a>
							</div><br>
							

						";
					
					}


					
				}else{
					echo "No data Found ";
				}



 ?>