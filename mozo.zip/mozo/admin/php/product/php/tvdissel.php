<?php 

  $tvupdis = $_POST['tvdis'];


 					if($tvupdis == 1){
							echo "<option value='1' selected >Display</option>
								 <option value='0'>None</option>";
						}else{
							echo "<option value='0' selected >None</option>
								 <option value='1'>Display</option>" ;
						}
					
					
	


	



 ?>