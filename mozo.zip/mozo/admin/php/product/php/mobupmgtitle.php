<?php 

$uprate = $_POST['mobupdate'];
	


	include "../../../infile/config.php";;

				
				$sql = "SELECT * FROM mobile WHERE  sno = $uprate";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						echo $row['ml_name'];
					
					}


					
				}else{
					echo "No data Found ";
				}



 ?>