<?php 


	$id = $_POST['id'];
	 
	 

	

			include "../../../infile/config.php";
			$sql = "UPDATE mobile SET dis_mode = 1 WHERE sno = $id";

				if(mysqli_query($conn,$sql) ){
					echo 1;
				}else{
					echo 0;
				}




 ?>