<?php 
session_start();
date_default_timezone_set("Asia/Kolkata");

	if(empty($_POST['tv-ot-input-color'])){
		$tv_others = null;
	}else{
		$tv_others = ", ".$_POST['tv-ot-input-color'];
	}
	/*if(empty($_POST['mob-cam'])){
		$mob_cam  = "No";
	}else{
		$mob_cam =$_POST['mob-cam']." ". "MEGA PIXCEL";
	}
	if(empty($_POST['mob-sec-cam'])){
		$mob_scam  = "No";
	}else{
		$mob_scam = $_POST['mob-sec-cam']." ". "MEGA PIXCEL" ;
	}
	if(empty($_POST['mob-resol'])){
		$mob_resol  = "No";
	}else{
		$mob_resol = $_POST['mob-resol'];
	}
	if(empty($_POST['mob-os'])){
		$mob_os  = "No";
	}else{
		$mob_os = $_POST['mob-os'];
	}*/
		$name = $_SESSION['name'];
		$prid = $_POST['tvpro_id'];
		$file = $_FILES['tv-img']['name'];
		$brand_name = $_POST['tv-pro-br'];
		$modal_name = $_POST['tv-model-name'];
		$modal_number = $_POST['tv-model-no'];
		$color = join($_POST['tv-color-val'],", "). $tv_others;
		$inches = $_POST['tv-inch-val'];
		$display_type =$_POST['tv-dis-val'];
	
		$resol = $_POST['tv-res-val'];
		
		$fea = join($_POST['tv-fea-val'],", ");
		$hdmi = $_POST['tv-hdmi-no'];
		$usb = $_POST['tv-usb-no'];
		$manu = $_POST['tv-manu'];
		$made = $_POST['tv_made'];
		$disc = $_POST['tv-dis'];
		$amt = $_POST['tv-price'];
		$off_rate =  $_POST['tv-off-rate'];
		$dmode = $_POST['tv-dis-mode'];
		$date = date("d-m-Y l",strtotime("now"));	

		

		
		if($off_rate == 0 || $off_rate == ""){
			$off = "No Offer";
		}else{
			$m = $amt * $off_rate/100;
			$off = $amt - $m;
		}

		/*if($dmode == 1){
			$display = "Display";
		}else{
			$display = "No";
		}*/
			


	/*$arr = array(
		"file"  => $file,
		"Brand name" => $brand_name,
		"Modal Name" => $modal_name,
		"Modal Number" => $modal_number,
		"color" => $color,
		"inches" => $inches,
		"Display type" => $display ,
		"Resolution" => $resol ,
		"Feautures" => $fea ,
		"HDMI" => $hdmi,
		"USB" => $usb,
		"Manufacture" => $manu ,
		"Made in" => $made  ,
		"Discription" => $disc ,
		"Ammount" => $amt,
		"Offer Rate" => $off_rate,
		"date" => $date
			
			);
				echo "<pre>";
					print_r($arr);
				echo "</pre>";*/

if($file != ""){

		

		$tv_file_temp = $_FILES['tv-img']['tmp_name'];

		$tv_extension = pathinfo($file,PATHINFO_EXTENSION);

		$tv_valid_extension = array("jpg","jpeg");
		
		
		if(in_array($tv_extension,$tv_valid_extension) === false){
		
			echo "File is not support.. please uploade jpg ,jpeg";
			
		}else{
			$tv_img = "tv_"." ".rand()." -" .basename($file);
			$tv_target = "tv-images/". $tv_img;
			$tv_image_name = $tv_img; 
			
			
			
			if(move_uploaded_file($tv_file_temp,$tv_target)){
				
				include "../../../infile/config.php";

				$sql = "INSERT INTO television 
								(emp_name,file,br_name,ml_name,ml_no,color,inch,dis,resol,fea,hdmi,usb,manu,made,disc,amt,off_rate,off_per,dis_mode,pro_name)
								VALUES('{$name}','{$tv_img}',{$brand_name},'{$modal_name}','{$modal_number}','{$color}','{$inches}','{$display_type}','{$resol}','{$fea}','{$hdmi}','{$usb}','{$manu}','{$made}','{$disc}','{$amt}','{$off}','{$off_rate}',{$dmode},{$prid})";
							
						if(mysqli_query($conn,$sql) == true){
							echo 1;
						}else{
							echo mysqli_error($conn);
						}
			}else{
				echo "file is uploade error";
				
			}
		}
		
		
		

				
		
		
	}else{
		echo "Please upload image of product";
	}

 ?>