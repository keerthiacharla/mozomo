<?php 


	 $id = $_POST['tvbtn_id'];

			include "../../../infile/config.php";

				
				$sql = "UPDATE television SET off_rate = 'No Offer', off_per =  'No Offer' WHERE sno = $id";

				if(mysqli_query($conn,$sql) ){
					echo 1;
				}else{
					echo 0;
				}




 ?>