
<?php 
include "../../../infile/config.php";

				
				$sql = "SELECT * FROM television";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						echo "<button class='btn btn-primary m-2 tv-item-btn' id='tv-item-btn' data-tvid= '{$row['sno']}' >{$row['ml_name']}' </button>  <br>

						";
					
					}

					
				}else{
					echo "No data Found ";
				}






 ?>


 