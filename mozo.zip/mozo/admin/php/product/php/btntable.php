
<?php 

				include "../../../infile/config.php";

				$view = $_POST['view_id'];

				$sql = "SELECT mobile.sno,mobile.file, mobile.br_name,mobile.ml_name,mobile.ml_num,mobile.tec,mobile.color,mobile.pr_cam,mobile.se_cam,mobile.ram,mobile.dis_type,mobile.resol,mobile.os,mobile.fea,mobile.manu,mobile.sto,mobile.made,mobile.disc,mobile.amt,mobile.off_rate,mobile.pro_name,mobile.dis_mode,pro.pname FROM mobile LEFT JOIN pro ON mobile.br_name = pro.sno  WHERE mobile.sno = $view";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						if($row['dis_mode'] == 1){
							$display = "Display";
						}else{
							$display = "None";
						}

						echo "<thead class='bg-primary text-white'>
									<tr>
		         						<th>Item Discription</th>
		         						<th>Details of Items </th>
		         					</tr>
	         					</thead>
	         					<tbody id='data-table-tbody'>
	         					 <tr>
	         							<td><b>Image</b></td>
	         							<td><img src='php/product/php/Mobile-images/{$row['file']}' id='view-img-flex' alt=''><span ><span></span><span>
	         								<button class='btn btn-sucess btn-sm ' id='mob_view_more' data-target='#mob-view-blog' data-toggle='modal' data-cid='{$view}'data-pvname='{$row['pro_name']}'>VIEW</button>
	         								<button class='btn btn-sucess btn-sm ' id='addmore-mob-images'  data-target='#addmob-img' data-toggle='modal' data-acid='{$view}'data-pname='{$row['pro_name']}'>ADD</button></td>
	         						</tr>
	         						<tr>
	         							<td><b>Brand Name</b></td>
	         							<td>{$row['pname']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Modal Name</b></td>
	         							<td>{$row['ml_name']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Modal Number</b></td>
	         							<td>{$row['ml_num']}  </td>
	         						</tr>
	         						<tr>
	         							<td><b>Technology</b></td>
	         							<td>{$row['tec']}  </td>
	         						</tr>
	         						<tr>
	         							<td><b>Color</b></td>
	         							<td>{$row['color']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Primary Camera</b></td>
	         							<td>{$row['pr_cam']}</td>
	         						</tr>
	         						<tr>
	         							<td><b>Secodary Camera</b></td>
	         							<td>{$row['se_cam']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>RAM</b></td>
	         							<td>{$row['ram']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Display Type</b></td>
	         							<td>{$row['dis_type']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Resolution</b></td>
	         							<td>{$row['resol']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Operating System </b></td>
	         							<td>{$row['os']}</td>
	         						</tr>
	         						<tr>
	         							<td><b>Feautures</b></td>
	         							<td>{$row['fea']}e </td>
	         						</tr>
	         						<tr>
	         							<td><b>Manufactured by</b></td>
	         							<td>{$row['pname']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Storage</b></td>
	         							<td>{$row['sto']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Made In</b></td>
	         							<td>{$row['made']}</td>
	         						</tr>
	         						<tr>
	         							<td><b>Discription</b></td>
	         							<td>{$row['disc']}</td>
	         						</tr>
	         						<tr>
	         							<td><b>Amount</b></td>
	         							<td id='mob_amt'>{$row['amt']} <span><button class='btn' id='mobrate-update-btn'data-yesno='{$row['off_rate']}' data-btno='{$view}'data-mobant='{$row['amt']} 'data-toggle='modal' data-target='#mob-arate'>Modify Rate</button></span> </td>
	         						</tr>
	         						<tr>
	         							<td><b>Offer Rate</b></td>
	         							<td id='off_row'><span id='mob_offpro'>{$row['off_rate']}</span> <span id ='amt-update'><button class='btn' id='moboff-update-btn'data-yesno='{$row['off_rate']}' data-oubtn='{$view}'data-mobpri='{$row['amt']} 'data-toggle='modal' data-target='#ofupmob-offer'>Update </button></span> </td>
	         						</tr>

	         						<tr>
	         							<td><b>In Display</b></td>
	         							<td id='dis_row' > <span id='show_dis'> {$display}</span> <span><button class='btn' id='mobdis-update-btn'data-dis='{$row['dis_mode']}' data-sno ='{$row['sno']}'data-toggle='modal' data-target='#disupmob'>Modify</button></span></td>
	         						</tr>
	         				</tbody>

						";
					
					}

					
				}else{
					echo "No data Found ";
				}






 ?>


 