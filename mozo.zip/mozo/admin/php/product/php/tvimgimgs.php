<?php 

$file = $_FILES["tv-view-add-input"]["name"];
$tv_file_id =  $_POST['tvadd_img_id'];

if($file != ""){

        

        $tv_add_file_temp = $_FILES['tv-view-add-input']['tmp_name'];

        $tv_add_extension = pathinfo($file,PATHINFO_EXTENSION);

        $tv_add_valid_extension = array("jpg","jpeg");
        
        
        if(in_array($tv_add_extension,$tv_add_valid_extension) === false){
        
            echo "File is not support.. please uploade jpg ,jpeg";
            
        }else{
            $tv_add_img =  "tv_"." ".rand()." -" .basename($file);
            $tv_add_target = "tv-images/". $tv_add_img;
            $tv_add_image_name = $tv_add_img; 
            
            
            
            if(move_uploaded_file($tv_add_file_temp,$tv_add_target)){
                
               include "../../../infile/config.php";

                $sql = "INSERT INTO images 
                                (img_id,img_name,pro_no)
                                VALUES({$tv_file_id},'{$tv_add_img}',2)";
                            
                        if(mysqli_query($conn,$sql) == true){
                            echo 1;
                        }else{
                            echo 0;
                        }
            }else{
                echo "file is uploade error";
                
            }
        }
        
        
        

                
        
        
    }else{
        echo "Please upload image of product";
    }






 ?>