<?php 

	$id = $_POST['id'];
	$tvres = $_POST['tvres'];

	


include "../../../../infile/config.php";

				
				$sql = "SELECT specival.under,specival.s_val, speci.spec_title FROM specival
							LEFT JOIN speci ON specival.under  = speci.sno 
							WHERE specival.pname = {$id} AND specival.under = {$tvres } ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						echo "
						<input type='radio' id='{$row['s_val']}' name='tv-res-val' value='{$row['s_val']}' class=' tv-res-val form-control m-2'>

								<label for='{$row['s_val']}'>{$row['s_val']}</label>
								";
					
					}

					
				}else{
					echo "No data Found ";
				}






 ?>