<?php 

	$id = $_POST['id'];
	$dt = $_POST['dt'];

	



		include "../../../../infile/config.php";

				
				$sql = "SELECT specival.under,specival.s_val, speci.spec_title FROM specival
							LEFT JOIN speci ON specival.under  = speci.sno 
							WHERE specival.pname = {$id} AND specival.under = {$dt} ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						echo "<option value='{$row['s_val']}'>{$row['s_val']}'</option>";
					
					}

					
				}else{
					echo "No data Found ";
				}






 ?>