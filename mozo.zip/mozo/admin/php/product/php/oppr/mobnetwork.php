<?php 

	$id = $_POST['id'];
	$no = $_POST['sp'];

	



			include "../../../../infile/config.php";

				
				$sql = "SELECT specival.under,specival.s_val, speci.spec_title FROM specival
							LEFT JOIN speci ON specival.under  = speci.sno 
							WHERE specival.pname = {$id} AND specival.under = {$no} ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						echo "<input type='radio' id='{$row['s_val']}' name='mob-tec' value='{$row['s_val']}' class=' mob-tec form-control m-2'>

								<label for='{$row['s_val']}'>{$row['s_val']}</label>";
					
					}

					
				}else{
					echo "No data Found ";
				}






 ?>