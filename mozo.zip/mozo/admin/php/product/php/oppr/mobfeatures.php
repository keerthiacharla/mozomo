<?php 

	$id = $_POST['id'];
	$fea = $_POST['fea'];

	



			include "../../../../infile/config.php";

				
				$sql = "SELECT specival.under,specival.s_val, speci.spec_title FROM specival
							LEFT JOIN speci ON specival.under  = speci.sno 
							WHERE specival.pname = {$id} AND specival.under = {$fea } ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						echo "
						<input type='checkbox' name='mob-fea-val[]' class='form-control ml-2 mob-fea'  value='{$row['s_val']}' id='{$row['s_val']}'></input>
								<label for='{$row['s_val']}' class='ml-1'> {$row['s_val']}</label>
								";
					
					}

					
				}else{
					echo "No data Found ";
				}






 ?>