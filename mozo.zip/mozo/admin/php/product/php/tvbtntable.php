
<?php 

				include "../../../infile/config.php";

				$view = $_POST['tvview_id'];

				$sql = "SELECT television.sno,television.file, television.br_name,television.ml_name,television.ml_no,television.color,television.inch,television.dis,television.resol,television.fea,television.usb,television.hdmi,television.manu,television.made,television.disc,television.amt,television.off_rate,pro.pname,television.dis_mode,television.pro_name FROM television LEFT JOIN pro ON television.br_name = pro.sno  WHERE television.sno = $view";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					

					
					while($row = mysqli_fetch_assoc($res)){


						if($row['dis_mode'] == 1){
							$display = "Display";
						}else{
							$display = "None";
						}

						echo "<thead class='bg-primary text-white'>
									<tr>
		         						<th>Item Discription</th>
		         						<th>Details of Items </th>
		         					</tr>
	         					</thead>
	         					<tbody id='data-table-tbody'>
	         					 <tr>
	         							<td><b>Image</b></td>
	         							<td><img src='php/product/php/tv-images/{$row['file']}' id='view-img-flex' alt=''><span ><span></span><span>
	         								<button class='btn btn-sucess btn-sm ' id='tv_view_more' data-target='#tv-view-blog' data-toggle='modal' data-tvcid='{$view}'data-tvpname='{$row['pro_name']}'>VIEW</button>
	         								<button class='btn btn-sucess btn-sm ' id='addmore-tv-images' data-target='#tvadd-img' data-toggle='modal' data-tvacid='{$view}'data-tvpname='{$row['pro_name']}'>ADD</button></td>
	         						</tr>
	         						<tr>
	         							<td><b>Brand Name</b></td>
	         							<td>{$row['pname']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Modal Name</b></td>
	         							<td>{$row['ml_name']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Modal Number</b></td>
	         							<td>{$row['ml_no']}  </td>
	         						</tr>
	         						<tr>
	         							<td><b>Color</b></td>
	         							<td>{$row['color']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Inches</b></td>
	         							<td>{$row['inch']}  </td>
	         						</tr>
	         						
	         						<tr>
	         							<td><b>Display Type</b></td>
	         							<td>{$row['dis']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Resolution</b></td>
	         							<td>{$row['resol']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>HDMI</b></td>
	         							<td>{$row['hdmi']}</td>
	         						</tr>
	         						<tr>
	         							<td><b>USB</b></td>
	         							<td>{$row['usb']}</td>
	         						</tr>
	         						<tr>
	         							<td><b>Feautures</b></td>
	         							<td>{$row['fea']}e </td>
	         						</tr>
	         						<tr>
	         							<td><b>Manufactured by</b></td>
	         							<td>{$row['pname']} </td>
	         						</tr>
	         						<tr>
	         							<td><b>Made In</b></td>
	         							<td>{$row['made']}</td>
	         						</tr>
	         						<tr>
	         							<td><b>Discription</b></td>
	         							<td>{$row['disc']}</td>
	         						</tr>
	         						<tr>
	         							<td><b>Made by</b></td>
	         							<td>{$row['amt']} <span><button class='btn' id='tvbrate-update-btn'data-yesno='{$row['off_rate']}' data-btvno='{$view}'data-tvbant='{$row['amt']} 'data-toggle='modal' data-target='#tv-arate'>Modify Rate</button></span</td>
	         						</tr>
	         						<tr>
	         							<td><b>Offer Rate</b></td>
	         							<td>{$row['off_rate']} <span><button class='btn' id='tvoff-update-btn'data-tvyesno='{$row['off_rate']}' data-tvbtn='{$view}'data-tvpri='{$row['amt']} 'data-toggle='modal' data-target='#ofuptv-offer'>Update Offer</button></span> </td> 
	         						</tr>

	         						<tr>
	         							<td><b>In Display</b></td>
	         							<td> {$display} <span><button class='btn' id='tvdis-update-btn'data-tvdis='{$row['dis_mode']}' data-tvsno ='{$row['sno']}'data-toggle='modal' data-target='#disuptv'>Modify</button></span></td>
	         						</tr>
	         				</tbody>

						";
					
					}

					
				}else{
					echo "No data Found ";
				}






 ?>


 