<?php 

$file = $_FILES["mob-view-add-input"]["name"];
$pname = $_POST['add_img_proname'];
$file_id =  $_POST['add_img_id'];

if($file != ""){

        

        $mob_add_file_temp = $_FILES['mob-view-add-input']['tmp_name'];

        $mob_add_extension = pathinfo($file,PATHINFO_EXTENSION);

        $mob_add_valid_extension = array("jpg","jpeg");
        
        
        if(in_array($mob_add_extension,$mob_add_valid_extension) === false){
        
            echo "File is not support.. please uploade jpg ,jpeg";
            
        }else{
            $mob_add_img = "mobile_"." ".rand()." -" .basename($file);
            $mob_add_target = "Mobile-images/". $mob_add_img;
            $mob_add_image_name = $mob_add_img; 
            
            
            
            if(move_uploaded_file($mob_add_file_temp,$mob_add_target)){
                include "../../../infile/config.php";

                $sql = "INSERT INTO images 
                                (img_id,img_name,pro_no)
                                VALUES({$file_id},'{$mob_add_img}',{$pname})";
                            
                        if(mysqli_query($conn,$sql) == true){
                            echo 1;
                        }else{
                            echo 0;
                        }
            }else{
                echo "file is uploade error";
                
            }
        }
        
        
        

                
        
        
    }else{
        echo "Please upload image of product";
    }






 ?>