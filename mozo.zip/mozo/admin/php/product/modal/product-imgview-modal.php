<div class="modal fade " id="mob-view-blog" data-backdrop="static">
	<div class="modal-dialog  modal-xl  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">imges</h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid ">
					<div class="row" >
						<div class="col-md-12 d-flex m-2 p-2" id="viewer-img-flex">	</div>					
					</div>
				
				</div>

			</div>
		</div>
	</div>
</div>

<div class="modal fade " id="addmob-img" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Add images</h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="mob_view_add">
								<input type="text" name="add_img_id" id="add_img_id" hidden>
								<input type="text" name="add_img_proname" id="add_img_proname"hidden>
								<div class="form-group">
									<input type="file" class="form-control" id="mob-view-add-input" name="mob-view-add-input">
									<button class="btn btn-success " id="sub-mob-image" >Add Image </button>
								</div>
							</form>

						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
				
			</div>
			

		</div>
	</div>
</div>





<div class="modal fade " id="ofupmob-offer" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 " >
				<h5 class="text-white p-2" id="mobup_title">offter update</h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="mob_view_add">
								<div class="form-group">
									<select name="mob_updat" id="mob_updat">
										
									</select>
								</div>
								<div class="form-group input=group" id="mobupdate_off_form">
									<label for="">Rate %</label>
									  
											<div class="input-group-append">
												<span class="input-group-text">per%</span>
												<input type="text" class="form-control" id="mobupdate_off_input" name="mobupdate_off_input">
											</div>

									</div>
									<button class="btn btn-primary"id="mobyes">Submit</button>
									
									
							</form>

						</div>
					</div>
				</div>

			</div>
			
			

		</div>
	</div>
	</div>

	<div class="modal fade " id="disupmob" >
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="mob_dis_add">
								<div class="form-group">
									<select name="mob_dis" id="mob_dis">
										
									</select>
								</div>
								
									
									
							</form>

						</div>
					</div>
				</div>

			</div>
			
			

		</div>
	</div>
	</div>


	<div class="modal fade " id="mob-arate" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 " >
				<h5 class="text-white p-2" id="updaterate_title">Modify Rate</h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="mob_upratech">
								
								<div class="form-group input=group" id="mobuprate_off_form">
									<label for="">New Rate</label>
									
											<div class="input-group-append">
												<span class="input-group-text">RS</span>
												<input type="text" class="form-control" id="mobuprate_input" name="mobuprate_input">
											</div>

									</div>
									<button class="btn btn-primary"id="moratech">Submit</button>
									
									
							</form>

						</div>
					</div>
				</div>

			</div>
			
			

		</div>
	</div>
	</div>