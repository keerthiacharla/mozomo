<div class="modal" id="product-add" data-backdrop="static">
	<div class="modal-dialog modal-lg  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Add Product details</h5>
				<span id="error-box">Lorem, ipsum dolor.</span>
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="form-group form-inline">
						<label for=""> Product</label>
						<select name="pro-br" id="pro-br" class="custom-select form-control-sm ml-3">
							<option value="select" >Select</option>
						</select>
					</div>
					<hr><hr>

					<!-- Mobile form  -->

					<!-- Image  -->

				<form action="" id="mob-form" class="form p-2">
					<input type="text" name="pro_id" id="pro_id" hidden>
					<div class="form-group">
						<label for="" class=" d-flex">Image <span class="text-danger img text-bold image-error">*</span></label>
						<input type="file" id="mob-img" name="mob-img" class="form-control">
					</div>

					<!-- Brand Name  -->
					<div class="form-group form-inline">
						<label for="" class="d-flex "> Brand Name<span class="text-danger br-err text-bold image-error">*</span></label>
						<select name="mob-pro-br" id="mob-pro-br" class="custom-select form-control-sm ml-3">
							<option value="select" >Select</option>
						</select>
					</div>

					<!-- Modal Name  -->
					<div class="form-group">
						<label for="" class="d-flex ">Modal Name <span class="text-danger ml-err text-bold image-error">*</span></label>
						<input type="text" id="model-name" name="model-name" class="form-control">
					</div>

					<!-- modal Number  -->
					<div class="form-group">
						<label for="" class="d-flex">Modal Number<span class="text-danger mn-err text-bold image-error">*</span></label>
						<input type="text" id="model-no" name="model-no" class="form-control">
					</div>
					
					<!-- Network -->
					<div class=" form-group d-flex  form-inline" >
						<label for="" class="d-flex">Network<span class="text-danger nt-err text-bold image-error">*</span></label>
							<div id="mob_network" class="form-inline "></div>
					
						</div>

						<!-- Color  -->
						<div class=" form-group d-flex  form-inline" >

							<label for="" class="d-flex ">Color<span class="text-danger mob-color-err text-bold image-error">*</span></label>
								<div id="mob_color" class="form-inline "></div>

								<input type="checkbox" name="mob-ot-input" id="mob-ot-input" class="form-control m-2"> 

								<label for="mob-ot-input" class="m-1"> Others color</label>

								<input type="text" class="form-control m-2" id="input-color" name="input-color">
					
						</div>
						<!-- Camera Operators  -->
						<div class="form-group form-inline">
								<input type="checkbox" name="mob-cam-radio" class="form-control   m-2 mob-cam-radio"  value="camera" id="mob-cam-radio">  </input>
								<label for="mob-cam-radio" class="m-1"> Camera</label>

								
						</div>

						<!-- Primary Camera  -->

						<div class="form-group" id="mob-cam-container">
							<label for="d-flex">Primary Camera <span class="text-danger mob-pri-cam-err text-bold image-error">*</span></label>
									<div class="input-group">
										<input type="text" class="form-control" id="mob-cam" name="mob-cam">
											<div class="input-group-append">
												<span class="input-group-text">MEGA PIXCEL</span>
											</div>
										</div>
										<div class="form-group form-inline">
											<input type="checkbox" name="mob-cam-sec-radio" class="form-control form-control-sm m-2  mob-cam-sec-radio"  value="scam" id="mob-cam-sec-radio">  </input>
										<label for="mob-cam-sec-radio" class="m-1"> Secondary Camera<span class="text-danger mob-pri-cam-err text-bold image-error">*</span></label>

											
									</div>
										
								</div>

							<!-- Secondary Camera  -->

							<div class="form-group" id="mob-sec-cam-container">
								
									<div class="input-group">
										<input type="text" class="form-control" id="mob-sec-cam" name="mob-sec-cam">
											<div class="input-group-append">
												<span class="input-group-text">MEGA PIXCEL</span>
											</div>
										</div>
									</div>

							<!-- RAM -->

						<div class="form-group form-inline">
							<label for="d-flex"> RAM <span class="text-danger mob-ram-err text-bold image-error">*</span></label>
							<select name="mob_ram" id="mob_ram" class="custom-select form-control-sm ml-3">
								<option value="select" >Select</option>
							</select>
						</div>

						<!-- Display Type  -->
						<div class="form-group form-inline">
							<label for="d-flex"> Display Type<span class="text-danger mob-dt-err text-bold image-error">*</span></label>
							<select name="mob-dt" id="mob-dt" class="custom-select form-control-sm ml-3">
								<option value="select" >Select</option>
							</select>
						</div>

						<!-- Resolution -->
						<div id="mod_resol_container">
							
							<div class=" form-group  form-inline" >
								<label for="" class="d-flex ">Resolution<span class="text-danger mob-resol-err text-bold image-error">*</span></label>
									<div id="mob_reso" class="form-inline "></div>
							</div>
						</div>

						<!-- Operating System  -->
						<div id="mod_os_container">
							<div class=" form-group d-flex  form-inline" >
							<label for="d-flex" class=" ">Operating System <span class="text-danger mob-os-err text-bold image-error">*</span></label>
								<div id="mob_os" class="form-inline ">	</div>
							</div>

						</div>
						<!-- Features -->

						<div class=" form-group d-flex  form-inline" >
							<label for="d-flex" class=" d-flex">Features <span class="text-danger mob-fea-err text-bold image-error">*</span></label>
								<div id="mob_fea" class="form-inline ">	</div>
						</div>

						<!-- Manufacture  -->

						<div class="form-group form-inline">
							<label for="" class="d-flex "> Manufactured By <span class="text-danger mob-manu-err text-bold image-error">*</span></label>
							<select name="mob-manu" id="mob-manu" class="custom-select form-control-sm ml-3">
								<option value="select" >Select</option>
							</select>
						</div>

						<!-- Battery -->

						<div class="form-group">
							<label for="d-flex">Battery<span class="text-danger mob-bt-err text-bold image-error">*</span></label>
							<input type="text" class="form-control" id="mob-bat" name="mob-bat">
						</div>

						<!-- Made in  -->

						<div class="form-group form-inline">
							<label for="d-flex"> Made In<span class="text-danger mob-made-err text-bold image-error">*</span></label>
							<select name="mob_made" id="mob_made" class="custom-select form-control-sm ml-3">
								<option value="select" >Select</option>
							</select>
						</div>

						<!-- Storage Upto  -->

						<div class=" form-group d-flex  form-inline" >
							<label for="d-flex" class="" >Storage upto<span class="text-danger mob-st-err text-bold image-error">*</span></label>
								<div id="mob_sto_ut" class="form-inline ">	</div>
						</div>

						<!-- Description -->
		
						<div class="form-group">
							<label for="d-flex">Descrption<span class="text-danger mob-dis-err text-bold image-error">*</span></label>
							<textarea cols="10" rows="10" class="form-control" id="mob-dis" name="mob-dis"></textarea>
						</div>

						<!-- Price  -->

						<div class="form-group ">
							<label for="d-flex">Price <span class="text-danger mob-pri-err text-bold image-error">*</span></label>
								<div class="input-group-append">
										<span class="input-group-text">RS</span>
										<input type="text" class="form-control" id="mob-price" name="mob-price">
									</div>
							</div>
							
							<!-- offer Opperator  -->
							<div class="form-group form-inline">
								<label for=""> Offer</label>
								<select name="mob-off-sel" id="mob-off-sel" class="custom-select form-control-sm ml-3">
									<option value="select" >Select</option>
									<option value="Yes">Yes</option>
											<option value="No Offer">No</option>
								</select>
							</div>
								
								<!-- Offer Price  -->

								<div class="rate-off">
									<div class="form-group">
										<label for="d-flex">Offer % <span class="text-danger mob-off-err text-bold image-error">*</span></label>
											<div class="input-group-append">
												<span class="input-group-text">RS</span>
												<input type="text" class="form-control" id="mob-off-rate" name="mob-off-rate">
											</div>
									</div>
								</div>
								<!-- Display Mode -->
								<div class="form-group form-inline">
									<label for="" class="d-flex "> In Display <span class="text-danger mob-manu-err text-bold dis-mode-error">*</span></label>
									<select name="dis-mode" id="dis-mode" class="custom-select form-control-sm ml-3">
										
										<option value="1" >Display</option>
										<option value="2" >None</option>

									</select>
						</div>

								<!-- Form susmit button  -->

							<div class="form-group">
									<button class="btn btn-success d-block ml-auto " id="mob-sub">Susmit</button>
							</div>

				</form>





				<!-- Television form  -->

				<form action="" id="tv-form">
					<input type="text" name="tvpro_id" id="tvpro_id" hidden>
					<div class="form-group">
						<label for="" class=" d-flex">Image <span class="text-danger tv-image-error text-bold image-error">*</span></label>
						<input type="file" id="tv-img" name="tv-img" class="form-control">
					</div>

					<!-- Brand Name  -->
					<div class="form-group form-inline">
						<label for="" class="d-flex "> Brand Name<span class="text-danger tv-br-err text-bold image-error">*</span></label>
						<select name="tv-pro-br" id="tv-pro-br" class="custom-select form-control-sm ml-3">
							<option value="select" >Select</option>
						</select>
					</div>

					<!-- Modal Name  -->
					<div class="form-group">
						<label for="" class="d-flex ">Modal Name <span class="text-danger tv-ml-err text-bold image-error">*</span></label>
						<input type="text" id="tv-model-name" name="tv-model-name" class="form-control">
					</div>

					<!-- modal Number  -->
					<div class="form-group">
						<label for="" class="d-flex">Modal Number<span class="text-danger tv-mn-err text-bold image-error">*</span></label>
						<input type="text" id="tv-model-no" name="tv-model-no" class="form-control">
					</div>
					
					<!-- Color  -->
						<div class=" form-group d-flex  form-inline" >

							<label for="" class="d-flex ">Color<span class="text-danger tv-color-err text-bold image-error">*</span></label>
								<div id="tv_color" class="form-inline "></div>

								<input type="checkbox" name="tv-ot-input" id="tv-ot-input" class="form-control m-2"> 

								<label for="tv-ot-input" class="m-1 tv-input-box"> Others color</label>		<input type="text" class="form-control m-2 box" id="tv-ot-input-color" name="tv-ot-input-color" placeholder="Enter Color">
					
						</div>

						<!-- Inch Type  -->
						<div class="form-group form-inline">
							<label for="d-flex"> Inch <span class="text-danger tv-inch-err text-bold image-error">*</span></label>
							<div id="tv_inch" class="form-inline "></div>
						</div>
						
						<!-- Display Type  -->
						<div class="form-group form-inline">
							<label for="d-flex"> Display<span class="text-danger tv-dt-err text-bold image-error">*</span></label>
							<div id="tv_dis" class="form-inline "></div>
						</div>

						<!-- Resolution -->
						<div id="mod_resol_container">
							
							<div class=" form-group  form-inline" >
								<label for="" class="d-flex ">Resolution<span class="text-danger tv-resol-err text-bold image-error">*</span></label>
									<div id="tv_reso" class="form-inline "></div>
							</div>
						</div>

						
						<!-- Features -->

						<div class=" form-group d-flex  form-inline" >
							<label for="d-flex" class=" d-flex">Features <span class="text-danger tv-fea-err text-bold image-error">*</span></label>
								<div id="tv-fea" class="form-inline ">	</div>

						</div>
						<!-- ports -->

						<div class=" form-group d-flex  form-inline" >
							

							
								<label for='HDMI' class='ml-1 d-flex'> HDMI<span class="text-danger tv-hdmi-err text-bold image-error">*</span> </label>
								<input type="text" id="tv-hdmi-no" name="tv-hdmi-no" class="ml-3 form-control">

								
								<label for='USB' class='ml-1 d-flex'> USB<span class="text-danger tv-usb-err text-bold image-error">*</span> </label>
								<input type="text" id="tv-usb-no" name="tv-usb-no" class="ml-3 form-control">

							

						</div>

						<!-- Manufacture  -->

						<div class="form-group form-inline">
							<label for="" class="d-flex "> Manufactured By <span class="text-danger tv-manu-err text-bold image-error">*</span></label>
							<select name="tv-manu" id="tv-manu" class="custom-select form-control-sm ml-3">
								<option value="select" >Select</option>
							</select>
						</div>


						<!-- Made in  -->

						<div class="form-group form-inline">
							<label for="d-flex"> Made In<span class="text-danger tv-made-err text-bold image-error">*</span></label>
							<select name="tv_made" id="tv_made" class="custom-select form-control-sm ml-3">
								<option value="select" >Select</option>
							</select>
						</div>

						
						<!-- Description -->
		
						<div class="form-group">
							<label for="d-flex">Descrption<span class="text-danger tv-dis-err text-bold image-error">*</span></label>
							<textarea cols="10" rows="10" class="form-control" id="tv-dis" name="tv-dis"></textarea>
						</div>

						<!-- Price  -->

						<div class="form-group ">
							<label for="d-flex">Price <span class="text-danger tv-pri-err text-bold image-error">*</span></label>
								<div class="input-group-append">
										<span class="input-group-text">RS</span>
										<input type="text" class="form-control" id="tv-price" name="tv-price">
									</div>
							</div>
							
							<!-- offer Opperator  -->
							<div class="form-group form-inline">
								<label for=""> Offer</label>
								<select name="tv-off-sel" id="tv-off-sel" class="custom-select form-control-sm ml-3">
									<option value="select" >Select</option>
									<option value="Yes">Yes</option>
											<option value="No Offer">No</option>
								</select>
							</div>
								
								<!-- Offer Price  -->

								<div class="tv-rate-off">
									<div class="form-group">
										<label for="d-flex">Offer % <span class="text-danger tv-off-err text-bold image-error">*</span></label>
											<div class="input-group-append">
												<span class="input-group-text">RS</span>
												<input type="text" class="form-control" id="tv-off-rate" name="tv-off-rate">
											</div>
									</div>
								</div>
									<div class="form-group form-inline">
									<label for="" class="d-flex "> In Display <span class="text-danger mob-manu-err text-bold tv-dis-mode-error">*</span></label>
									<select name="tv-dis-mode" id="tv-dis-mode" class="custom-select form-control-sm ml-3">
										<option value="select" >Select</option>
										<option value="1" >Display</option>
										<option value="2" >None</option>

									</select>
						</div>

								<!-- Form susmit button  -->

							<div class="form-group">
									<button class="btn btn-success d-block ml-auto " id="tv-sub">Susmit</button>
							</div>

				</form>


				
				

			</div>
			

		</div>
	</div>
</div>