<div class="modal fade " id="tv-view-blog" data-backdrop="static">
	<div class="modal-dialog  modal-xl  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">imges</h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid ">
					<div class="row" >
						<div class="col-md-12 d-flex m-2 p-2" id="tvviewer-img-flex">	</div>					
					</div>
				
				</div>

			</div>
		</div>
	</div>
</div>




<div class="modal fade " id="tvadd-img" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Add images</h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="tv_view_add">
								<input type="text" name="tvadd_img_id" id="tvadd_img_id" hidden>
								<input type="text" name="tvadd_pro_name" id="tvadd_pro_name" hidden>
								<div class="form-group">
									<input type="file" class="form-control" id="tv-view-add-input" name="tv-view-add-input">
									<button class="btn btn-success " id="sub-tv-image" >Add Image </button>
								</div>
							</form>

						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
				
			</div>
			

		</div>
	</div>
</div>


<div class="modal fade " id="ofuptv-offer" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 " >
				<h5 class="text-white p-2" id="tvup_title">offter update</h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="mob_view_add">
								<div class="form-group">
									<select name="tv_updat" id="tv_updat">
										
									</select>
								</div>
								<div class="form-group input=group" id="tvupdate_off_form">
									<label for="">Rate %</label>
									
											<div class="input-group-append">
												<span class="input-group-text">per%</span>
												<input type="text" class="form-control" id="tvupdate_off_input" name="tvupdate_off_input">
											</div>

									<button class="btn btn-primary"id="tvyes">Submit</button>
									</div>
									
									
							</form>

						</div>
					</div>
				</div>

			</div>
			
			

		</div>
	</div>
	</div>


	<div class="modal fade " id="disuptv" >
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="tv_disopp">
								<div class="form-group">
									<select name="tv_dis_opp" id="tv_dis_opp">
										
									</select>
								</div>
								
									
									
							</form>

						</div>
					</div>
				</div>

			</div>
			
			

		</div>
	</div>
	</div>

	<div class="modal fade " id="tv-arate" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 " >
				<h5 class="text-white p-2" id="updateratetv_title">Modify Rate</h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="tv_upratech">
								
								<div class="form-group input=group" id="tvuprate_off_form">
									<label for="">New Rate</label>
									
											<div class="input-group-append">
												<span class="input-group-text">RS</span>
												<input type="text" class="form-control" id="tvuprate_input" name="tvuprate_input">
											</div>

									</div>
									<button class="btn btn-primary"id="tvratech">Submit</button>
									
									
							</form>

						</div>
					</div>
				</div>

			</div>
			
			

		</div>
	</div>
	</div>