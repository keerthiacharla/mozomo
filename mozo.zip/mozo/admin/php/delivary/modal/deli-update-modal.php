<div class="modal fade " id="deli-login-add" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Delivary Agents Details    </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action=""  class="form p-1" id="user-deli-form">
								
								<div class="form-gouup">
									<label for="">First Name </label>
									<input type="text" class="form-control" name="deli_fname" id="deli_fname" placeholder="Enter Your First Name ">
								</div>
								<div class="form-gouup">
									<label for="">Last Name </label>
									<input type="text" class="form-control" name="deli_lname" id="deli_lname" placeholder="Enter Your Last Name ">
								</div>

									
									<div class="form-group">
											<div class="form-group form-inline p-2">
												<label for="" class="d-flex">Gender <span id="" class="gen_na_error color_fild">*</span> </label>
												<input type="radio" class="form-control m-2 deli_gender" id="male" name="deli_gender" value="Male">
												<label for="male">Male </label>
												<input type="radio" class="form-control m-2 deli_gender" id="female" name="deli_gender" value="Female">
												<label for="female">Female </label>
											</div>
										</div>
								
								<div class="form-gouup">
									<label for="">Email Name </label>
									<input type="text" class="form-control" name="deli_email" id="deli_email" placeholder="Enter Your Email ID ">
								</div>
								<div class="form-gouup">
									<label for="">Phone </label>
									<input type="text" class="form-control" name="deli_phone" id="deli_phone" placeholder="Enter Your Phone Number" maxlength="10">
								</div>
								<div class="form-gouup">
									<label for="">Address </label>
									<textarea name="deli_add" class="form-control"  id="deli_add"  cols="30" rows="10" placeholder="Enter Your address  "></textarea>
								</div>
								<div class="form-gouup">
									<label for="">State </label>
									<select name="deli_state" class="form-control custom-select" id="deli_state" >				
										
									</select>
								</div>
								<div class="form-gouup ">
									<label for="">City </label>
									<select name="deli_city" class="form-control custom-select" id="deli_city">
									</select>
								</div>
								<div class="form-gouup ">
									<label for="">Zone </label>
									<select name="deli_zone" class="form-control custom-select" id="deli_zone">
									</select>
								</div>
								<div class="form-gouup">
									<label for="">Zip Code  </label>
									<input type="text" class="form-control" name="deli_zip" id="deli_zip" placeholder="Enter Your Pin Code ">
								</div>
								
								
								<button class="btn btn-primary mt-2 " id="user-deli-btn"> Save Details </button>



							</form>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
			</div>

		</div>
	</div>
</div>
 