
<div class="deli_items_container p-3">
	<h1 class="bg-primary d-block text-white" id="title">Delivary Modification</h1><span>
		
	</span>

<div class="product-items-container">
	

		
	<button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#deli_set_data">Employee Details</button>



			<div class="product_data collapse p-3" id="deli_set_data">

				<button class="btn btn-primary d-block ml-auto " data-toggle="modal" data-target="#deli-login-add">ADD</button>

		 	 
	
		 	 <?php include "modal/deli-update-modal.php "?>
				
			<form class="form-group form-inline col-md-12  m-3 p-3" >
							<div class="form-group m-2 serch-item d-block">
								<input type="text" class="form-control d-block ml-auto " id="deli-del-val-search-box" name="deli-del-val-search-box" placeholder="SEARCH ">
							</div>
							<div class="form-group m-3 ">
								<label>state</label>
								<select class="form-control" id="search-state" name="search-state">
									<option value="">Select </option>
								</select>
							</div>
							<div class="form-group m-3">
								<label>City</label>
								<select class="form-control " id="search-dis" name="search-dis">
									<option value="">Select </option>
								</select>
							</div>
							<div class="form-group m-3">
								<label>Zone</label>
								<select class="form-control " id="search-zone" name="search-zone">
									<option value="">Select </option>
								</select>
							</div>
						</form>

			        

			       <div class="col-md-12 productdata-container d-lg-flex">

			       	 <div class="col-md-6" id="show-deli-btn">
			       	 	
			       	 </div>
			       	 <div class="col-md-6" id="show-deli-con">
			       	 	<table class="table" id="show-deli-table">

			       	 		

			       	 	</table>
			      
			       	 </div>
			       	 
			       </div>
			    </div>


			    
			    
			  

	   
		</div>
</div>


