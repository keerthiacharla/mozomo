<?php 

	include "../../../infile/config.php";
if($_POST['type'] == ""){


	$sql = "SELECT * FROM state";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	$str = "";

	$str .="<option value=''>Select</option>";

		while($row = mysqli_fetch_assoc($res)){
			$str .= "<option value='{$row['sno']}'>{$row['state']}</option>";



		}
	
}else if($_POST['type'] == "statedata"){
	
	$sql2 = "SELECT * FROM city WHERE state_val = {$_POST['id']}";

	$res2 = mysqli_query($conn,$sql2) or die("offerheader.php query failed");
	
	$str = "";
	$str .= "<option value='select' selected>Select City</option>";

		while($row2 = mysqli_fetch_assoc($res2)){
			$str .= "<option value='{$row2['sno']}'>{$row2['city']}</option>";


	}
}else if($_POST['type'] == "zonedata"){
	
	$sql3 = "SELECT * FROM deli_zone WHERE city = {$_POST['id']}";

	$res3 = mysqli_query($conn,$sql3) or die("offerheader.php query failed");
	
	$str = "";

		while($row3 = mysqli_fetch_assoc($res3)){
			$str .= "<option value='{$row3['sno']}'>{$row3['address']}</option>";


	}
}
  echo $str;

 ?>