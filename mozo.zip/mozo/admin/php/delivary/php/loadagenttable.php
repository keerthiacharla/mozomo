<?php 


	include "../../../infile/config.php";
	$id = $_POST['id'];

				
			$sql = "SELECT deli_agent.*,state.state AS state_name, city.sno AS city_num ,city.city AS city_name FROM deli_agent 
					LEFT JOIN state ON deli_agent.dis = state.sno
					LEFT JOIN city ON deli_agent.city = city.sno
					 WHERE deli_agent.sno = $id";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
						 
					
						echo "<tr rowspan='2'>
								<td colspan='2'>
								<button class='btn btn-primary mb-1' data-delino='{$row['sno']}' id='deli-print' data-toggle='modal' data-target=''>Print Data </button>
								</td>
							 </tr>

							<tr>
								<td><b>Category</b></td>
								<td><b>details</b></td>
							</tr>
							<tr>
								<td><b>Employee photo </b></td>
								<td><img src='php/delivary/php/photos/{$row['image']}' alt='' id='empl-photo'></td>
							</tr>
							
							<tr>
								<td><b>Employee ID </b></td>
								<td>{$row['deli_id']}</td>
							</tr>
							<tr>
								<td><b>Employee Name </b></td>
								<td>{$row['fname']} {$row['lname']}</td>
							</tr>
							<tr>
								<td><b>Gender </b></td>
								<td>{$row['gen']}</td>
							</tr>
							<tr>
								<td><b>Phone</b></td>
								<td>{$row['phone']}</td>
							</tr>
							<tr>
								<td><b>Email </b></td>
								<td>{$row['email']}</td>
							</tr>
							<tr>
								<td><b>Address </b></td>
								<td>{$row['address']}, {$row['city_name']}, {$row['state_name']} -{$row['zip']}</td>
							</tr>
							
							
							
							";

						
					
					}

					
				}else{ 
					echo "No login";
				}

 ?>