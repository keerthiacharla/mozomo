
 

				<?php 

 
	include "../../../infile/config.php";

	$deli_search =$_POST['deli_search'];
				
			$sql = "SELECT deli_agent.*,state.state AS state_name, city.sno AS city_num ,city.city AS city_name FROM deli_agent 
					LEFT JOIN state ON deli_agent.dis = state.sno
					LEFT JOIN city ON deli_agent.city = city.sno
					 WHERE deli_agent.fname LIKE '%{$deli_search}%' OR deli_agent.lname LIKE '%{$deli_search}%'  OR deli_agent.email LIKE '%{$deli_search}%'  OR deli_agent.phone LIKE '%{$deli_search}%' OR  city.city LIKE '%{$deli_search}%' ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
						
					
						echo "<button class='btn btn-primary mb-1' data-deliid='{$row['sno']}' id='deli-btn'>{$row['deli_id']}</button> <br>";

						
					
					}

					
				}else{ 
					echo "<h1> No Recent Order By Costomer </h1>";
				}

 ?>
