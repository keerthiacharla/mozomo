<?php 
		include "../../../infile/config.php";
		$emp_id = "mozodeli". rand(000000,999999);
		$fname = mysqli_escape_string($conn,$_POST['deli_fname']);
		$lname = mysqli_escape_string($conn,$_POST['deli_lname']);
		
		$gen = mysqli_escape_string($conn,$_POST['deli_gender']);
		$email = mysqli_escape_string($conn,$_POST['deli_email']);
		$phone = $_POST['deli_phone'];
		$add = $_POST['deli_add'];
		$state = $_POST['deli_state'];
		$city = $_POST['deli_city'];
		$zone = $_POST['deli_zone'];
		$zip = $_POST['deli_zip'];
		
		

		
		/*$arr = array(
					"userid" => $emp_id,
					"First" => $fname,
					"Last" => $lname,
					
					"Gender" => $gen,
					"phone" => $phone,
					"Email" => $email,
					"Adress" => $add,
					"City" => $city,
					"State" => $state,
					"zone" => $zone,
					"zip" => $zip
					

				);
				echo "<pre>";
					print_r($arr);
				echo "</pre>";*/

		$sql = "SELECT * FROM deli_agent WHERE  email ='{$email}' OR phone ='{$phone}'";
		$res = mysqli_query($conn,$sql) or die("conn failed");

			if(mysqli_num_rows($res) > 0){
			
					echo "file is already exsist";
					die();

				
			
			}else{
				$sql2 = "INSERT INTO 
					deli_agent(deli_id,fname,lname,gen,phone,email,address,city,dis,zone,zip) 
					VALUES('{$emp_id}','{$fname}','{$lname}','{$gen}','{$phone}','{$email}','{$add}',{$state},{$city},{$zone},{$zip})";
						if(mysqli_query($conn,$sql2)){
							echo 1;
						}else{
							echo " 2nd Qury Faild";
			

			}
		}
		



		

 ?>