
 

				<?php 

 
	include "../../../infile/config.php";
				
			$sql = "SELECT * FROM deli_agent ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
						
					
						echo "<button class='btn btn-primary mb-1' data-deliid='{$row['sno']}' id='deli-btn'>{$row['deli_id']}</button> <br>";

						
					
					}

					
				}else{ 
					echo "<h1> No Recent Order By Costomer </h1>";
				}

 ?>
