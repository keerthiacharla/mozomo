<div class="modal fade " id="zone-add" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Zone Details    </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="zone-form">
								<div class="form-group">
									<select name="zone-dis" id="zone-dis" class="form-control">
										<option value="select" selected>Select</option>
									</select>
								</div>
								<div class="form-group">
									<select name="zone-city" id="zone-city" class="form-control">
										<option value="select" selected>Select</option>
									</select>
								</div>
								<div class="form-group">
									<textarea name="zone-add" id="zone-add" cols="30" rows="10" class="form-control"></textarea>
								</div>
								<button class="btn btn-primary " id="zone-add-btn" name="zone-add-btn">Save Zone  </button>
							</form>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
			</div>

		</div>
	</div>
</div>
 