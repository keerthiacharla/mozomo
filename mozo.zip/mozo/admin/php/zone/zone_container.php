
<div class="zone_items_container p-3">
	<h1 class="bg-primary d-block text-white" id="title">Zone Offices  Modification</h1><span>
		
	</span>

<div class="product-items-container">
	<button class="btn btn-primary d-block ml-auto " data-toggle="modal" data-target="#zone-add">ADD</button>

		 	 <?php include "modal/add-modal.php "?>
		 	 <form class="form-group form-inline col-md-12  m-3 p-3" >
							
							<div class="form-group m-3 ">
								<label>state</label>
								<select class="form-control" id="search-zone-state" name="search-zone-state">
									<option value="">Select </option>
								</select>
							</div>
							<div class="form-group m-3">
								<label>City</label>
								<select class="form-control " id="search-zone-dis" name="search-zone-dis">
									<option value="">Select </option>
								</select>
							</div>
							
						</form>     

				<table class="table" id="producttable">
			       		<thead class="bg-primary text-white">
			       			<tr>
			       				<th>Sno</th>
			       				<th>State </th>
			       				<th>City</th>
			       				<th>zone</th>
			       				
			       				<th>Delete</th>
			       				
			       			</tr>
			       		</thead>
			       		<tbody id="zone_table_row"></tbody>

			       		
			       	</table>
			
				

	
			  
	   
</div>
</div>


