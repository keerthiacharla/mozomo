<?php 
	include "../../../infile/config.php";

	$state = $_POST['zone-dis'];
	$city = $_POST['zone-city'];
	$add = $_POST['zone-add'];
	



$sql = "SELECT * FROM deli_zone WHERE address = '{$add}'";
$res = mysqli_query($conn,$sql) or die("Query Failed");

if(mysqli_num_rows($res)){

	echo 0;

}else{
	$sql2 = "INSERT INTO deli_zone(state,city,address) VALUES($state,$city,'{$add}')";

	
	

	if(mysqli_query($conn,$sql2)){
			echo 1;
	}else{
		echo die("2nd query failed");
	}
}


	

		
	


 

 ?>