<?php


include "../../../infile/config.php";

	$id = $_POST['id'];

	$sql = "DELETE FROM deli_zone WHERE sno = $id"; 
	

	
	if(mysqli_query($conn,$sql) == true){
		echo 1;
	}else{
		echo 0;
	}

?>