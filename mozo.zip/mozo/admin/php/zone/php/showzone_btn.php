<?php


include "../../../infile/config.php";

	
			$sql = "SELECT deli_zone.*,state.state AS state_name, city.sno AS city_num ,city.city AS city_name FROM deli_zone 
					LEFT JOIN state ON deli_zone.state = state.sno
					LEFT JOIN city ON deli_zone.city = city.sno
					";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	if(mysqli_num_rows($res) > 0){

		
		while($row = mysqli_fetch_assoc($res)){
			/*echo $row['sno']." ". $row['c_name']." ". $row['pname']."<br>";*/
			echo "<tr>
	       				<td>{$row['sno']}</td>
	       				<td>{$row['state_name']}</td>
	       				<td>{$row['city_name']}</td>
	       				<td>{$row['address']}</td>
	       			
	       			
	       				<td><button class='btn btn-danger d-block m-auto ' data-did='{$row['sno']}' id='del-zone-btn'>Delete</button></td>
	       			</tr>";

	       		
		}

		
	}else{
		echo "No data Found ";
	}



?>