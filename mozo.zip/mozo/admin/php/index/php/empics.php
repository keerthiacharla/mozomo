<?php
session_start();
	echo "<a href='' title='' id='img-btn' data-target='#first-img-modal' data-toggle='modal'><img src='php/index/php/photos/{$_SESSION['img']}' alt='' class=''></a>"

	?>