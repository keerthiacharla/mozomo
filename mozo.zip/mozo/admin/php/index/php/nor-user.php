<?php 
session_start();



	 $usname = $_POST['usname'];
	 $pass = md5($_POST['pass']);
	 $id = $_POST['id'];
/*
	 echo $usname ." ". $pass." ". $id;
*/

		include "../../../infile/config.php";
				
		$sql = "SELECT user.pass,user.role,user.email,user.name,emp_details.emp_id AS emp_no ,emp_details.image FROM user LEFT JOIN emp_details ON user.emp_id = emp_details.sno WHERE user.email = '{$usname}' AND user.pass ='{$pass}' AND user.role = {$id}";
				$res = mysqli_query($conn,$sql) or die(" query failed");
				if(mysqli_num_rows($res) > 0){
					
					while($row = mysqli_fetch_assoc($res)){

						$tpass = md5("admin");
						
						if($row['pass'] ==  $tpass){

							echo 2;


						}else if($row['pass'] !==  $tpass){
							
									$_SESSION['emp_id'] = $row['emp_no'];
									$_SESSION['name'] = $row['name'];
									
									$_SESSION['pass'] = $row['pass'];
									$_SESSION['email'] = $row['email'];
									$_SESSION['role'] = $row['role'];
									$_SESSION['img'] = $row['image'];
						
								echo 1;
						}
		
					
					}

					
				}else{ 
					echo 0;
				}

 ?>

						