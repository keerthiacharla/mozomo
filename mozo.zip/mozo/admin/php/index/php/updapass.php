<?php 
session_start();



	
	 $pass = md5($_POST['logreset_retus_pass']);
	 $id = $_POST['loreset-id'];

	/* echo  $pass." ". $id;*/


		include "../../../infile/config.php";

				
		$sql = "UPDATE user SET pass = '{$pass}' WHERE email = '{$id}'";

				if(mysqli_query($conn,$sql)){
					echo 1;
				}else{
					echo 0;
				}


 ?>

						