<?php 
	session_start();

	echo "<h4 class='text-center'>Name : {$_SESSION['name'] }</h4>
					<h6 class='text-center'>ID : {$_SESSION['emp_id']}</h6>
					<button class='btn btn-primary d-block m-auto' id='logout_user'>Logout</button>"

 ?>