<?php 
session_start();


	$usname = $_POST['name'];
	 $pass = md5($_POST['pass']);
	 $id = $_POST['id'];


	include "../../../infile/config.php";

				
			$sql = "SELECT user.*, emp_details.emp_id AS emp_no ,emp_details.first_name, emp_details.last_name,emp_details.image FROM user LEFT JOIN emp_details ON user.emp_id = emp_details.sno WHERE user_id = '{$usname}' AND pass ='{$pass}' AND role = {$id}";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						$_SESSION['emp_id'] = $row['emp_no'];
						$_SESSION['name'] = $row['first_name'] . " " .$row['last_name']  ;
						$_SESSION['user'] = $row['user_id'];
						$_SESSION['pass'] = $row['pass'];
						$_SESSION['email'] = $row['email'];
						$_SESSION['role'] = $row['role'];
						$_SESSION['img'] = $row['image'];
												
						echo "yes login";

						
					
					}

					
				}else{ 
					echo "No login";
				}

 ?>