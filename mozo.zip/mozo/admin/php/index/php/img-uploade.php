	<?php




		  $cos_img = $_FILES['img-up-field']['name'];
		$cos_id = $_POST['img-sno'];
		
		

	

if($cos_img != ""){

		

		$file_temp = $_FILES['img-up-field']['tmp_name'];

		$extension = pathinfo($cos_img,PATHINFO_EXTENSION);

		$valid_extension = array("jpg","jpeg");
		
		
		if(in_array($extension,$valid_extension) === false){
		
			echo 2;
			
		}else{
			$new_name =  $cos_id.".jpg";
			$target = "photos/". $new_name;
			$image_name = $new_name;
			
			
			
			if(move_uploaded_file($file_temp,$target)){
				
				
				include "../../../infile/config.php";

				$sql = "UPDATE emp_details SET image = '{$new_name}' WHERE emp_id = '{$cos_id}'";
						if(mysqli_query($conn,$sql) == true){
							echo 1;
						}else{
							echo 0;
						}
			}else{
				echo 0;
				
			}
		}
		
		
		

				
		
		
	}else{
		echo "Please upload image of product";
	}
	



			?>
