<?php 

	 $idval = $_POST['idval'];
	 $val = $_POST['val'];


	include "../../../infile/config.php";

				
			$sql = "SELECT * FROM user WHERE user_id = '{$idval}' AND role ='{$val}' ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						echo 1;

						
					
					}

					
				}else{ 
					echo 0;
				}


 ?>