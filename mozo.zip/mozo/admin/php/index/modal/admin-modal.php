<?php 

 ?><div class="modal fade " id="adminuse_modal" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Admin Id <span id="ad-erro"> Lorem, ipsum.</span></h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid ">
					<div class="row" >
						<form action="" id="adminid_add">
								<div class="form-group">
									<input type="text" name="adminid" class="form-control w-100" id="adminid">
								</div>
								<button class="btn btn-primary " id="empid-sub"> Submit</button>
								
							</form>					
					</div>
				
				</div>

			</div>
		</div>
	</div>
</div>

