<div class="modal fade " id="log_reset" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2"><div id="loreset-heder"></div> <span id="ad-reset-erro"> <p></p></span></h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid ">
					<div class="row" >
						<div class="col-md-12">
							<form action="" id="logreset_add">
									<input type="text" id="loreset-id" name="loreset-id" value="" hidden>
									
								<div class="form-group input-group">
										<input type="password" class="form-control" id="logreset_us_pass" name="logreset_us_pass" placeholder="Enter Your password " >
										<div class="input-group-append">
											<span id="logreset_icon" class="input-group-text"><i class="fa-solid fa-eye" id="logreset_show_icon"></i></span>
										</div>
									</div>
									<div class="form-group input-group">
										<input type="password" class="form-control" id="logreset_retus_pass" name="logreset_retus_pass" placeholder="Enter Your password ">
										<div class="input-group-append">
											<span id="logreset_reset_icon" class="input-group-text"><i class="fa-solid fa-eye" id="logreset_com_show_icon"></i></span>
										</div>
									</div>
								<button class="btn btn-primary " id="logreset-sub"> Submit</button>
								
							</form>			
						</div>		
					</div>
				
				</div>

			</div>
		</div>
	</div>
</div>