<?php 
	

 ?><div class="modal fade " id="first-img-modal" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Image <span id="ad-erro"> Lorem, ipsum.</span></h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid ">
					<div class="row" >
						<form action="" id="img-uploade">
								<div class="form-group">
									<input type="text" name="img-sno" class="form-control w-100" id="img-sno" value="<?php echo $_SESSION['emp_id'] ?>" hidden>
									<input type="file" class="form-control" id="img-up-field" name="img-up-field">
								</div>
								<button class="btn btn-primary " id="empid-sub"> Submit</button>
								
							</form>					
					</div>
				
				</div>

			</div>
		</div>
	</div>
</div>