<?php
/*echo "coro tru .php";*/
	
	
	include "../../../infile/config.php";

	$sql = "TRUNCATE TABLE carosol";

	if(mysqli_query($conn,$sql)){
		$folder = "corosol-images";
		$file = glob($folder . '/*');

			foreach ($file as $files) {
				if(is_file($files)){
					unlink($files);
					echo 1;
				}else{
					echo "Not Deleted in folder";
				}
				// code...
			}
	}else{
		echo 0;
	}

?>