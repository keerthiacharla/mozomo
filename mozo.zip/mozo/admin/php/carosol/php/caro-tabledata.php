<?php
/*echo "coro .php";*/
	
	
include "../../../infile/config.php";

	$sql = "SELECT * FROM carosol";

	$res = mysqli_query($conn,$sql) or die("loadbtn.php query failed");

	$output = "";

	if(mysqli_num_rows($res) > 0){
		while($row = mysqli_fetch_assoc($res)){
			$output .=  "<tr>
	         				<td>{$row['sno']}</td>
	         				<td><a href='php/carosol/php/corosol-images/{$row['img']}'><img src='php/carosol/php/corosol-images/{$row['img']}' alt='' id='table-prew-img'></a></td>
	         				<td>{$row['title']}</td>
	         				<td>{$row['dis']}</td>
	         			</tr>";
		}
	}else{
		$output .= "No data Found ";
	}

		echo $output;

		?>