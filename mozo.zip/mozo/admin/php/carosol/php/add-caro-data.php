	<?php




		$caro_file = $_FILES['caro-img']['name'];
		$caro_title = $_POST['caro-til'];
		$caro_dis = $_POST['caro-des'];
		

	/*$arr = array(
		"file"  => $caro_file,
		"Title" => $caro_title,
		"discription" => $caro_dis
		
			);
				echo "<pre>";
					print_r($arr);
				echo "</pre>";*/

if($caro_file != ""){

		

		$file_temp = $_FILES['caro-img']['tmp_name'];

		$extension = pathinfo($caro_file,PATHINFO_EXTENSION);

		$valid_extension = array("jpg","jpeg");
		
		
		if(in_array($extension,$valid_extension) === false){
		
			echo "File is not support.. please uploade jpg ,jpeg";
			
		}else{
			$new_name = basename($caro_file);
			$target = "corosol-images/". $new_name;
			$image_name = $new_name;
			
			
			
			if(move_uploaded_file($file_temp,$target)){
				
			include "../../../infile/config.php";

				$sql = "INSERT INTO carosol(img,title,dis) VALUES('{$new_name}','{$caro_title}','{$caro_dis}')";
						if(mysqli_query($conn,$sql) == true){
							echo 1;
						}else{
							echo 0;
						}
			}else{
				echo 0;
				
			}
		}
		
		
		

				
		
		
	}else{
		echo "Please upload image of product";
	}
	



			?>
