<?php

	$file = "corosol-images";

	if(file_exists($file)){
		echo "yes";
	}else{
		echo "No";
	}
?>