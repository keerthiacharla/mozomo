<div class="modal" id="carosol-add">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Add Carosol</h5>
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<form action="" id="carosol-form">
					<div class="form-group">
						<label for="">Slide Image </label>
						<input type="file" name="caro-img" id="caro-img" class="form-control">
					</div>
					<div class="form-group">
						<label for="">Slide Title </label>
						<input type="text" name="caro-til" id="caro-til" class="form-control">
					</div>
					<div class="form-group">
						<label for="">Slide Description </label>
						<input type="text" name="caro-des" id="caro-des" class="form-control">
					</div>
					<div class="form-group">
						<button class="btn btn-success " name="caro-sub" id="caro-sub">Susmit</button>
					</div>
				</form>

			</div>
		

		</div>
	</div>
</div>
