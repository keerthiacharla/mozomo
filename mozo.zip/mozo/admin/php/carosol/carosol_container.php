<div class="carosol_items_container">
	<h1 class="bg-primary d-block text-white" id="title">Carosol</h1>

	<div class="carosol_data d-block ml-auto">
		<button class="btn btn-danger ml-auto" id="truecate">Delete All</button>
		<button class="btn btn-primary  ml-auto" data-toggle="modal" data-target="#carosol-add" id="carosol-add-btn">ADD</button>
	</div>
	         <?php include "modal/carosol-modal.php "?>
	      

	         <div class="caro-data-container">
	         	<table class="table">
	         		<thead class="bg-primary text-white">
	         			<tr>
	         				<th>Slide No.</th>
	         				<th>Slide Image</th>
	         				<th>Slide Tittle</th>
	         				<th>Slide Description.</th>
	         			</tr>
	         		</thead>
	         		<tbody id="caro-tabload">
	         			
	         		</tbody>
	         	</table>
	         </div>


</div>

