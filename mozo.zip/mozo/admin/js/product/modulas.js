 export  function btnview(){

							$.ajax({
								url:"php/product/php/btnview.php",
								
								success:function(data){
									/*console.log(data);*/
									$("#mob-btn-container").html(data);
								}
							})
						}


	export function tvbtnview(){

							$.ajax({
								url:"php/product/php/tvbtnview.php",
								
								success:function(data){
									/*console.log(data);*/
									$("#tv-btn-container").html(data);
								}
							})
						}
						
						