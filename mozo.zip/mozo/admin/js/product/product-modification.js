import {btnview} from "./modulas.js";
import {tvbtnview} from "./modulas.js";
import {loaduser} from "../setting/madular.js";
$(document).ready(function(){
			/*alert("add product ");*/


			$("#mob-price,#mob-cam,#mob-sec-cam,#mob-off-rate,#tv-usb-no,#tv-hdmi-no,#tv-price,#tv-off-rate,#mobupdate_off_input").keypress(function(evt){
						var ch = String.fromCharCode(evt.which);
						if((/[a-z A-z /?]/.test(ch))){
						evt.preventDefault();
						}
					});

	/*Color Others*/

		$("#mob-ot-input").click(function(event){
				var x = $(this).is(":checked");

				if(x == true){
					$("#input-color").css("display","block");

				}else{
					$("#input-color").css("display","none");
				}
		});

		/*Primary Camera Operators */

		$("#mob-cam-radio").click(function(event){
				var camera = $(this).is(":checked");

				

				if(camera == true){
					$("#mob-cam-container").css("display","block");
					
				}else if(camera == false){
					
					$("#mob-cam-container").css("display","none");
					$("#mob-cam").val("");
				}
		});

		/*Secondary Camera Operators */

			$("#mob-cam-sec-radio").click(function(event){
				var scamera = $(this).is(":checked");

				

				if(scamera == true){
					$("#mob-sec-cam-container").css("display","block");

				}else{
					$("#mob-sec-cam-container").css("display","none");
					$("#mob-sec-cam").val("");
				}
		});


			/*Offer oparation*/

		$("#mob-off-sel").on("change",function(){
			
			var change = $(this).val();
			

			if(change == "Yes"){
				$(".rate-off").css("display","block");

			}else{
				$(".rate-off").css("display","none");
				$("#mob-off-rate").val("0");
			}

		});

		$("#tv-off-sel").on("change",function(){
			
			var tv_change = $(this).val();
			

			if(tv_change == "Yes"){
				$(".tv-rate-off").css("display","block");

			}else{
				$(".tv-rate-off").css("display","none");
				$("#tv-off-rate").val("0");
				
			}

		});

		$("#mob-dt").on("change",function(){
			
			var dischange = $(this).val();
			

			if(dischange == "Keypad"){
				$("#mod_resol_container").css("display","none");
				$("#mod_os_container").css("display","none");
				$(".mob-resol").prop("checked",false);
				$(".mob-os").prop("checked",false);

			}else{
				
				$("#mod_resol_container").css("display","block");
				$("#mod_os_container").css("display","block");
			}

		});

		

		$("#pro-br").on("change",function(){
			var prid = $(this).val();

			if(prid == 1){
				$("#tv-form").css("display","none");
				$("#mob-form").css("display","block");
				$("#pro_id").val(prid);
				


				/*For mobile Brand  */
				function mobbrsel(){

							$.ajax({
								url:"php/product/php/oppr/mobbrsel.php",
								type:"POST",
								data:{selid:prid},
								success:function(data){
									/*console.log(data);*/
									$("#mob-pro-br,#mob-manu").html(data);
								}
							})
						}
						mobbrsel();

						/*For mobile Network  */
				function mobnetwork(){

							$.ajax({
								url:"php/product/php/oppr/mobnetwork.php",
								type:"POST",
								data:{id:prid,sp:4},
								success:function(data){
									/*console.log(data);*/
									$("#mob_network").html(data);
								}
							})
						}
						mobnetwork();

						/*For mobile color  */
				function mobcolor(){

							$.ajax({
								url:"php/product/php/oppr/mobcolor.php",
								type:"POST",
								data:{id:prid,color:10},
								success:function(data){
									/*console.log(data);*/
									$("#mob_color").html(data);
								}
							})
						}
						mobcolor();

								/*For mobile ram  */
				function mobram(){

							$.ajax({
								url:"php/product/php/oppr/mobram.php",
								type:"POST",
								data:{id:prid,ram:14},
								success:function(data){
									/*console.log(data);*/
									$("#mob_ram").append(data);
								}
							})
						}
						mobram();
									/*For mobile display type  */
				function mobdistype(){

							$.ajax({
								url:"php/product/php/oppr/mobdistype.php",
								type:"POST",
								data:{id:prid,dt:12},
								success:function(data){
									/*console.log(data);*/
									$("#mob-dt").append(data);
								}
							})
						}
						mobdistype();

						/*For mobile Resolution  */
					function mobresol(){

							$.ajax({
								url:"php/product/php/oppr/mobresol.php",
								type:"POST",
								data:{id:prid,res:13},
								success:function(data){
									/*console.log(data);*/
									$("#mob_reso").html(data);
								}
							})
						}
						mobresol();

								/*For mobile Operating System  */
					function mobos(){

							$.ajax({
								url:"php/product/php/oppr/mobos.php",
								type:"POST",
								data:{id:prid,os:11},
								success:function(data){
									/*console.log(data);*/
									$("#mob_os").html(data);
								}
							})
						}
						mobos();

									/*For mobile Features  */
					
					function mobfeatures(){

							$.ajax({
								url:"php/product/php/oppr/mobfeatures.php",
								type:"POST",
								data:{id:prid,fea:15},
								success:function(data){
									/*console.log(data);*/
									$("#mob_fea").html(data);
								}
							})
						}
						mobfeatures();


						/*For mobile Made In   */
					
					function mobmade(){

							$.ajax({
								url:"php/product/php/oppr/mobmade.php",
								type:"POST",
								data:{id:prid,madein:16},
								success:function(data){
									/*console.log(data);*/
									$("#mob_made").append(data);
								}
							})
						}
						mobmade();
							/*For mobile Storage   */
					
					function mobsto(){

							$.ajax({
								url:"php/product/php/oppr/mobsto.php",
								type:"POST",
								data:{id:prid,sto:17},
								success:function(data){
									/*console.log(data);*/
									$("#mob_sto_ut").html(data);
								}
							})
						}
						mobsto();

						


								/*For mobile submition  */

				$("#mob-form").submit(function(w){
					w.preventDefault();


					var image = $("#mob-img").val();
					var brand = $("#mob-pro-br").val();
					var modal = $("#model-name").val();
					var modelno = $("#model-no").val();
					var mob_ram = $("#mob_ram").val();
					var mob_net = $(".mob-tec");
					var mob_dt = $("#mob-dt").val();
					var mob_resol = $(".mob-resol");
					var mob_os = $(".mob-os");
					var mob_color = [];
					var mob_fea = [];
					var mob_camera = $("#mob-cam-radio").is(":checked");
					var mob_camera_val = $("#mob-cam").val();
					var mob_camera_sec = $("#mob-cam-sec-radio").is(":checked");
					var mob_camera_sec_val = $("#mob-sec-cam").val();
					var mob_manu = $("#mob-manu").val();
					var mob_bt = $("#mob-bat").val();
					var mob_made = $("#mob_made").val();
					var mob_sto = $(".mob-sto");
					var mob_dis = $("#mob-dis").val();
					var mob_pri = $("#mob-price").val();
					var mob_off_sel = $("#mob-off-sel").val();
					var mob_off_pri = $("#mob-off-rate").val();
				
					$(".mob-color:checked").each(function(key){
						if($(this).is(":checked")){
								mob_color.push($(this).val());

								}
								
							});

							mob_color = mob_color.toString();


							$(".mob-fea:checked").each(function(key){
								if($(this).is(":checked")){
										mob_fea.push($(this).val());

										}
										
									});

									mob_fea = mob_fea.toString();
								




					if(image == ""){
						$(".mob-error p").css("display","block");
						$(".img").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Uploade Approximate Image ");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
						return false;

					}else if(brand == "select"){
						$(".mob-error p").css("display","block");
						$(".br-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Select Brand");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
						return false;

					}else if(modal == ""){
						$(".mob-error p").css("display","block");
						$(".ml-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Modal Name");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
						return false;
					}else if(modelno == ""){
						$(".mob-error p").css("display","block");
						$(".mn-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Modal Number");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);

						return false;

					}else if((mob_net).filter(":checked").length < 1){
							$(".nt-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Network Type");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
								return false;

						}else if(mob_color == ""){
							$(".mob-color-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Color of Product");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
							return false;

						}else if(mob_camera && mob_camera_val == ""){
							$(".mob-fea-err").css("display","block");
							$(".mob-pri-cam-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Primary Camere Pixcel or Uncheck Box ");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
							return false;

						}else if(mob_camera_sec && mob_camera_sec_val == ""){
							$(".mob-fea-err").css("display","block");
							$(".mob-pri-cam-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Secondary Camere Pixcel or Uncheck Box");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
							return false;

						}else if(mob_ram== "select"){
						$(".mob-error p").css("display","block");
						$(".mob-ram-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Select RAM");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
						return false;

					}else if(mob_dt == "select"){
							$(".mob-dt-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Display Type");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
								return false;

						}else if(mob_dt != "Keypad" && (mob_resol).filter(":checked").length < 1){
							$(".mob-resol-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Resolution type");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
								return false;

						}else if(mob_dt != "Keypad" && (mob_os).filter(":checked").length < 1){
							$(".mob-os-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Operating System type");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
								return false;

						}else if(mob_fea == ""){
							$(".mob-fea-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Select Feautures");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
							return false;

						}else if(mob_manu == "select"){
						$(".mob-error p").css("display","block");
						$(".mob-manu-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Select Manudactured By ");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
						return false;

					}else if(mob_bt == ""){
						$(".mob-error p").css("display","block");
						$(".mob-bt-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Battery Company");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
						return false;

					}else if(mob_made == "select"){
						$(".mob-error p").css("display","block");
						$(".mob-made-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Select Made In ");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
						return false;

					}else if((mob_sto).filter(":checked").length < 1){
							$(".mob-st-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Select Storage Upto ");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
								return false;

						}else if(mob_dis == ""){
							$(".mob-dis-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Discription of Product ");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
								return false;

						}else if(mob_pri == ""){
							$(".mob-pri-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Price of Product ");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
								return false;

						}else if(mob_off_sel == "Yes" && mob_off_pri == ""){
							$(".mob-off-err").css("display","block");
							$("#error-box").fadeIn();
							$("#error-box").html("Please Enter Offer Price of Product or Select No Offer ");
							setTimeout(function(){
								$("#error-box").fadeOut();
								$("#error-box").css("display","none");
								$("#error-box").html("");

							},5000);
								return false;

						}


					

					var mob_form_input =  new FormData(this);		
							$.ajax({
										url:"php/product/php/addmob.php",
										type:"POST",
										data : mob_form_input ,
										contentType:false,
										processData:false,
										success : function(data){
											/*console.log(data);*/
											
											if(data == 1){
												$("#mob-form").trigger("reset");
												$("#addmob-img").modal("hide"); 
												$("#product-add").modal("hide"); 
												btnview();
												loaduser();

												
											}else{
													console.log(data);
												}

											
										}
									})
					
						
				})

			}else if(prid == 2){
				$("#tv-form").css("display","block");
				$("#mob-form").css("display","none");
				$("#tvpro_id").val(prid);




				/*Color Others*/

				$("#tv-ot-input").click(function(event){
						var y = $(this).is(":checked");

						if(y == true){
							$("#tv-ot-input-color").css("display","block");

						}else{
							$("#tv-ot-input-color").css("display","none");
						}
				})

					function mobbrsel(){

							$.ajax({
								url:"php/product/php/oppr/mobbrsel.php",
								type:"POST",
								data:{selid:prid},
								success:function(data){
									/*console.log(data);*/
									$("#tv-pro-br, #tv-manu").html(data);
								}
							})
						}
						mobbrsel();

							/*For mobile color  */
				function tvcolor(){

							$.ajax({
								url:"php/product/php/oppr/tvcolor.php",
								type:"POST",
								data:{id:prid,tv_color:18},
								success:function(data){
									/*console.log(data);*/
									$("#tv_color").html(data);
								}
							})
						}
						tvcolor();

						function tvinch(){

							$.ajax({
								url:"php/product/php/oppr/tvinch.php",
								type:"POST",
								data:{id:prid,tvinch:8},
								success:function(data){
									/*console.log(data);*/
									$("#tv_inch").html(data);
								}
							})
						}
						tvinch();

						function tvdisplay(){

							$.ajax({
								url:"php/product/php/oppr/tvdisplay.php",
								type:"POST",
								data:{id:prid,tvdis:19},
								success:function(data){
									/*console.log(data);*/
									$("#tv_dis").html(data);
								}
							})
						}
						tvdisplay();

						function tvresol(){

							$.ajax({
								url:"php/product/php/oppr/tvresol.php",
								type:"POST",
								data:{id:prid,tvres:20},
								success:function(data){
									/*console.log(data);*/
									$("#tv_reso").html(data);
								}
							})
						}
						tvresol();

						function tvfea(){

							$.ajax({
								url:"php/product/php/oppr/tvfea.php",
								type:"POST",
								data:{id:prid,tvfea:21},
								success:function(data){
									/*console.log(data);*/
									$("#tv-fea").html(data);
								}
							})
						}
						tvfea();

						function tvmade(){

							$.ajax({
								url:"php/product/php/oppr/mobmade.php",
								type:"POST",
								data:{id:1,madein:16},
								success:function(data){
									/*console.log(data);*/
									$("#tv_made").append(data);
								}
							})
						}
						tvmade();



						




						$("#tv-form").submit(function(a){
							a.preventDefault();
							/*alert("tv-sub");*/

							var tv_image = $("#tv-img").val();
							var tv_brand = $("#tv-pro-br").val();
							var tv_modal = $("#tv-model-name").val();
							var tv_modelno = $("#tv-model-no").val();
							var tv_color = [];
							var tv_fea = [];
							var tv_inch = $(".tv-inch-val");
							var tv_dis = $(".tv-dis-val");
							var tv_resol = $(".tv-res-val");
							var tv_hdmi = $("#tv-hdmi-no").val();
							var tv_usb = $("#tv-usb-no").val();
							var tv_manu = $("#tv-manu").val();
							var tv_made = $("#tv-made").val();
							var tv_disc = $("#tv-dis").val();
							var tv_price = $("#tv-price").val();
							var tv_off_sel = $("#tv-off-sel").val();
					var tv_off_pri = $("#tv-off-rate").val();


							$(".tv-color-val:checked").each(function(key){
								if($(this).is(":checked")){
										tv_color.push($(this).val());

										}
										
									});

									tv_color = tv_color.toString();


									$(".tv-fea-val:checked").each(function(key){
										if($(this).is(":checked")){
												tv_fea.push($(this).val());

												}
												
											});

											tv_fea = tv_fea.toString();

						
									if(tv_image == ""){
										
											$(".tv-image-error").css("display","block");
											$("#error-box").fadeIn();
											$("#error-box").html("Please Uploade Approximate Image");
											setTimeout(function(){
												$("#error-box").fadeOut();
												$("#error-box").css("display","none");
												$("#error-box").html("");

											},5000);
										return false;

									}else if(tv_brand == "select"){
											$(".tv-br-err").css("display","block");
											$(".br-err").css("display","block");
												$("#error-box").fadeIn();
												$("#error-box").html("Please Select Brand");
												setTimeout(function(){
													$("#error-box").fadeOut();
													$("#error-box").css("display","none");
													$("#error-box").html("");

												},5000);
											return false;

										}else if(tv_modal == ""){
													$(".tv-ml-err").css("display","block");
													$(".ml-err").css("display","block");
														$("#error-box").fadeIn();
														$("#error-box").html("Please Enter Modal Name");
														setTimeout(function(){
															$("#error-box").fadeOut();
															$("#error-box").css("display","none");
															$("#error-box").html("");

														},5000);
													return false;
												}else if(tv_modelno == ""){
													$(".tv-mn-err").css("display","block");
													$(".mn-err").css("display","block");
														$("#error-box").fadeIn();
														$("#error-box").html("Please Enter Modal Number");
														setTimeout(function(){
															$("#error-box").fadeOut();
															$("#error-box").css("display","none");
															$("#error-box").html("");

														},5000);

													return false;

												}else if(tv_color == ""){
														$(".tv-color-err").css("display","block");
														$("#error-box").fadeIn();
														$("#error-box").html("Please Enter Color of Product");
														setTimeout(function(){
															$("#error-box").fadeOut();
															$("#error-box").css("display","none");
															$("#error-box").html("");

														},5000);
														return false;

													}else if((tv_inch).filter(":checked").length < 1){
															$(".tv-inch-err").css("display","block");
															$("#error-box").fadeIn();
															$("#error-box").html("Please Enter TV Inches ");
															setTimeout(function(){
																$("#error-box").fadeOut();
																$("#error-box").css("display","none");
																$("#error-box").html("");

															},5000);
																return false;
															}else if((tv_dis).filter(":checked").length < 1){
																$(".tv-inch-err").css("display","block");
																$("#error-box").fadeIn();
																$("#error-box").html("Please Enter Display Type  ");
																setTimeout(function(){
																	$("#error-box").fadeOut();
																	$("#error-box").css("display","none");
																	$("#error-box").html("");

																},5000);
																	return false;
															}else if((tv_resol).filter(":checked").length < 1){
																$(".tv-inch-err").css("display","block");
																$("#error-box").fadeIn();
																$("#error-box").html("Please Enter Resolution Type  ");
																setTimeout(function(){
																	$("#error-box").fadeOut();
																	$("#error-box").css("display","none");
																	$("#error-box").html("");

																},5000);
																	return false;
															}else if(tv_fea == ""){
																	$(".tv-fea-err").css("display","block");
																	$("#error-box").fadeIn();
																	$("#error-box").html("Please Enter Feautures of Product");
																	setTimeout(function(){
																		$("#error-box").fadeOut();
																		$("#error-box").css("display","none");
																		$("#error-box").html("");

																	},5000);
																	return false;

																}else if(tv_hdmi == ""){
																	$(".tv-hdmi-err").css("display","block");
																	$("#error-box").fadeIn();
																	$("#error-box").html("Please Enter No. of HDMI ports");
																	setTimeout(function(){
																		$("#error-box").fadeOut();
																		$("#error-box").css("display","none");
																		$("#error-box").html("");

																	},5000);
																	return false;

																}else if(tv_usb == ""){
																	$(".tv-usb-err").css("display","block");
																	$("#error-box").fadeIn();
																	$("#error-box").html("Please Enter No. of USB ports");
																	setTimeout(function(){
																		$("#error-box").fadeOut();
																		$("#error-box").css("display","none");
																		$("#error-box").html("");

																	},5000);
																	return false;

																}else if(tv_manu == "select"){
																	$(".tv-manu-err").css("display","block");
																	$(".br-err").css("display","block");
																		$("#error-box").fadeIn();
																		$("#error-box").html("Please Enter Manufactured By.. ");
																		setTimeout(function(){
																			$("#error-box").fadeOut();
																			$("#error-box").css("display","none");
																			$("#error-box").html("");

																		},5000);
																	return false;

																}else if(tv_made == "select"){
																	$(".tv-made-err").css("display","block");
																	$(".br-err").css("display","block");
																		$("#error-box").fadeIn();
																		$("#error-box").html("Please Select Country of Brand Made");
																		setTimeout(function(){
																			$("#error-box").fadeOut();
																			$("#error-box").css("display","none");
																			$("#error-box").html("");

																		},5000);
																	return false;

																}else if(tv_disc == ""){
																	$(".tv-dis-err").css("display","block");
																	$(".br-err").css("display","block");
																		$("#error-box").fadeIn();
																		$("#error-box").html("Please Enter Discription");
																		setTimeout(function(){
																			$("#error-box").fadeOut();
																			$("#error-box").css("display","none");
																			$("#error-box").html("");

																		},5000);
																	return false;

																}else if(tv_price == ""){
																	$(".tv-pri-err").css("display","block");
																	$(".br-err").css("display","block");
																		$("#error-box").fadeIn();
																		$("#error-box").html("Please Enter Price");
																		setTimeout(function(){
																			$("#error-box").fadeOut();
																			$("#error-box").css("display","none");
																			$("#error-box").html("");

																		},5000);
																	return false;

																}else if(tv_off_sel == "Yes" && tv_off_pri == ""){
																		$(".tv-off-err").css("display","block");
																		$("#error-box").fadeIn();
																		$("#error-box").html("Please Enter Offer Price of Product or Select No Offer ");
																		setTimeout(function(){
																			$("#error-box").fadeOut();
																			$("#error-box").css("display","none");
																			$("#error-box").html("");

																		},5000);
																			return false;

																	}

							var tv_form_input =  new FormData(this);		
							$.ajax({
										url:"php/product/php/addtv.php",
										type:"POST",
										data : tv_form_input ,
										contentType:false,
										processData:false,
										success : function(data){
											/*console.log(data);*/
											
											if(data == 1){
												$("#tv-form").trigger("reset");
												$("#product-add").modal("hide"); 
												tvbtnview()

											}else{
													console.log(data);
												}

											
										}
									})
						});

						
			}
					

		})
	



});