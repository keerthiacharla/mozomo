import {btnview} from "./modulas.js";
import {tvbtnview} from "./modulas.js";
import {loaduser} from "../setting/madular.js";
import {slideloaduser} from "../setting/madular.js";
import {tvslideloaduser} from "../setting/madular.js";

$(document).ready(function(){
/*alert("Product implementation");*/

/*alert(mad+" Product implementation ");*/



				btnview();

						function mobviewtable(view_id){
									$.ajax({
										url:"php/product/php/btntable.php",
										type:"POST",
										data: {view_id:view_id},
										success:function(data){
											/*console.log(data);*/
											$("#data-table").html(data);


										}
								})
							}
							

						$(document).on("click","#mob_item",function(){
							/*alert("aaa")*/
							var viewid = $(this).data("vid");

							

							alert(viewid+" new");
							mobviewtable(viewid);

							


						})
							$("#mob_view_add").submit(function(pv){
											pv.preventDefault();

											var img_data = new FormData(this);
											var img_id = $("#addmore-mob-images").data("acid");

											/*alert(img_id);*/

											function mobimgaddimgs(){
													$.ajax({
														url:"php/product/php/mobimgimgs.php",
														type:"POST",
														data: img_data,
														contentType:false,
														processData:false,
														success:function(data){
															/*console.log(data);*/
															$("#viewer-img-flex").html(data);
															$("#mob_view_add").trigger("reset");
															$("#addmob-img").modal("hide");
															mobviewtable(img_id);
															slideloaduser();

															
														}
												})
											}
											mobimgaddimgs();
										})	
						$(document).on("click","#addmore-mob-images",function(){
							var ccid = $(this).data("acid");
							var vss_pname = $(this).data("pname");
							

							/*alert(vss_pname+" "+ccid);*/

							$("#add_img_id").val(ccid);
							$("#add_img_proname").val(vss_pname); 

							
						})


						$(document).on("click","#mob_view_more",function(){
							var v_pname = $(this).data("pvname");
							var vcid = $(this).data("cid");
							

						/*	alert(v_pname+" "+vcid);*/

							

							function mobimgview(){

										$.ajax({
											url:"php/product/php/mobimgview.php",
											type:"POST",
											data:{cid:vcid,pnme:v_pname},											
											success:function(data){
												/*console.log(data);*/
												$("#viewer-img-flex").html(data);
											}
										})
									}
									mobimgview();
						})


						$(document).on("click","#moboff-update-btn",function(){
							var mobup_rate = $(this).data("oubtn");

							

							function mobupmgtitle(){

										$.ajax({
											url:"php/product/php/mobupmgtitle.php",
											type:"POST",
											data:{mobupdate:mobup_rate},											
											success:function(data){
												/*console.log(data);*/
												$("#mobup_title,#updaterate_title").html(data);
											}
										})
									}
									mobupmgtitle();


								function upoffsel(){

										$.ajax({
											url:"php/product/php/upoffsel.php",
											type:"POST",
											data:{mobupdatesel:mobup_rate},											
											success:function(data){
												/*console.log(data);*/
												$("#mob_updat").html(data);
												/*mobviewtable(mob_upbtn);*/
											}
										})
									}
									upoffsel();

									

						})

					$(document).on("click","#moboff-update-btn",function(){
						var yesno = $(this).data("yesno");

						if(yesno == "No Offer"){
							$("#mobupdate_off_form").css("display","none");
						}else{
							$("#mobupdate_off_form").css("display","block");
						}
					
					});	
						

						$("#mob_updat").change(function(){
							var moboffchage = $(this).val();
								var mob_upbtn = $("#moboff-update-btn").data("oubtn");
								var mob_uppri = $("#moboff-update-btn").data("mobpri");
								var mob_upinputval = $("#mobupdate_off_input").val();
								var mobupans = mob_upinputval * mob_uppri/100;
							


							alert(moboffchage+" "+ mob_uppri+" "+ mob_upbtn);
							if(moboffchage == 0){

								

								$("#mobupdate_off_form").css("display","none");

								function mobnooffer(){

										$.ajax({
											url:"php/product/php/mob_nooffer.php",
											type:"POST",
											data:{btn_id:mob_upbtn},											
											success:function(data){
												/*console.log(data);*/
												if(data == 1){
													$("#ofupmob-offer").modal("hide");
													$("#mobupdate_off_input").val("");
													mobviewtable(mob_upbtn);
													

												}else{
													console.log(data);
												}
											}
										})
									}
									mobnooffer();




							}else if(moboffchage == 1){
								$("#mobupdate_off_form").css("display","block");
							

									$("#mobyes").click(function(c){
										c.preventDefault();
										var mob_uppri = $("#moboff-update-btn").data("mobpri");
										var mob_upinputval = $("#mobupdate_off_input").val();
										var mobupans = mob_uppri* mob_upinputval/100;
										var mob_tot_per = mob_uppri - mobupans;
									
										/*alert(mob_upinputval);*/

												$.ajax({
													url:"php/product/php/mob_yesoffer.php",
													type:"POST",
													data:{btn_id:mob_upbtn,totup:mob_tot_per,valueup:mob_upinputval},											
													success:function(data){
														/*console.log(data);*/
														if(data == 1){
															$("#ofupmob-offer").modal("hide");
															$("#mobupdate_off_input").val("");
															mobviewtable(mob_upbtn);
															

														}else{
													console.log(data);
												}
													}
												})
																						

											})
									}
						})
						function dissel(id){

										$.ajax({
											url:"php/product/php/dissel.php",
											type:"POST",
											data:{disid:id},											
											success:function(data){
												/*console.log(data);*/
												$("#mob_dis").html(data);
												
											}
										})
									}
									dissel();

						$(document).on("click","#mobdis-update-btn",function(){
							var mobdis = $(this).data("dis");
							var mobdisid = $(this).data("sno");
							/*alert(mobdis+" "+mobdisid)*/

								
									dissel(mobdis);

							$("#mob_dis").on("change",function(){
								var val = $(this).val();
								var mobdisid = $("#mobdis-update-btn").data("sno");
								/*alert(val);*/
								var dis_val = $(this);

								if(val == 1){
										
									
											/*alert("display" + mobdisid)*/
									$.ajax({
											url:"php/product/php/yes_dissel.php",
											type:"POST",
											data:{id:mobdisid},											
											success:function(data){
												/*console.log(data);*/
												if(data == 1){
													$("#disupmob").modal("hide");
												mobviewtable(mobdisid);
													


													
													
												}else{
													console.log(data);
												}
											}
										})
								}else{
									
									
									/*alert("no display" + mobdisid)*/
									$.ajax({
											url:"php/product/php/no_dissel.php",
											type:"POST",
											data:{id:mobdisid},											
											success:function(data){
												/*console.log(data);*/
												if(data == 1){
													$("#disupmob").modal("hide");
												mobviewtable(mobdisid);
													
													
												}else{
													console.log(data);
												}
											}
										})
								}



							})

							

						})

						$(document).on("click","#moratech",function(c){
								c.preventDefault();
								var inrate = $("#mobuprate_input").val();
								var rateid = $("#mobrate-update-btn").data("btno");

								/*alert(inrate + " "+ rateid)*/


								$.ajax({
											url:"php/product/php/mobuprate.php",
											type:"POST",
											data:{id:rateid,nrate:inrate},											
											success:function(data){
												if(data == 1){
													/*console.log(data);*/
													$("#mob-arate").modal("hide");
													$("#mobuprate_input").val("");
													mobviewtable(rateid);
												}else{
													console.log(data);
												}
											}
										})
							})















						/*Televiaion*/
	$(document).on("click","#tv-view",function(e){
		e.preventDefault();

		tvbtnview();
		$("#tv-data-table ").html("");

	})


						tvbtnview();

						function tvviewtable(tvview_id){
									$.ajax({
										url:"php/product/php/tvbtntable.php",
										type:"POST",
										data: {tvview_id:tvview_id},
										success:function(data){
											/*console.log(data);*/
											$("#tv-data-table").html(data);


										}
								})
							}
						

						$(document).on("click","#tv-item-btn",function(){
							/*alert("aaa")*/
							var tvviewid = $(this).data("tvid");

							/**/

							alert(tvviewid + " tele")
							tvviewtable(tvviewid);

							


						})

								$("#tv_view_add").submit(function(pv){
											pv.preventDefault();

											var tvimg_data = new FormData(this);
											var tvimg_id = $("#addmore-tv-images").data("tvacid");

											alert(tvimg_id);

											function tvimgaddimgs(){
													$.ajax({
														url:"php/product/php/tvimgimgs.php",
														type:"POST",
														data: tvimg_data,
														contentType:false,
														processData:false,
														success:function(data){
															/*console.log(data);*/
															$("#tvviewer-img-flex").html(data);
															$("#tv_view_add").trigger("reset");
															$("#tvadd-img").modal("hide");
															tvviewtable(tvimg_id);
															tvslideloaduser();

														}
												})
											}
											tvimgaddimgs();
										})
						$(document).on("click","#addmore-tv-images",function(){
							var tvccid = $(this).data("tvacid");
							var tvvss_pname = $(this).data("tvpname");
							

							/*alert(tvccid+" "+tvvss_pname);*/

							$("#tvadd_img_id").val(tvccid);
							$("#tvadd_pro_name").val(tvvss_pname); 

							
						})

						$(document).on("click","#tv_view_more",function(){
							var tv_pname = $(this).data("tvpname");
							var tvcid = $(this).data("tvcid");
							

							/*alert(tv_pname+" "+tvcid);*/

							

							function tvimgview(){

										$.ajax({
											url:"php/product/php/tvimgview.php",
											type:"POST",
											data:{tvcid:tvcid,tvpname:tv_pname},											
											success:function(data){
												/*console.log(data);*/
												$("#tvviewer-img-flex").html(data);
											}
										})
									}
									tvimgview();
						})
					$(document).on("click","#tvoff-update-btn",function(){
							var tvbup_rate = $(this).data("tvbtn");

							

							function tvupmgtitle(){

										$.ajax({
											url:"php/product/php/tvupmgtitle.php",
											type:"POST",
											data:{tvupdate:tvbup_rate},											
											success:function(data){
												/*console.log(data);*/
												$("#tvup_title").html(data);
											}
										})
									}
									tvupmgtitle();

									function tvupoffsel(){

										$.ajax({
											url:"php/product/php/tvupoffsel.php",
											type:"POST",
											data:{tvupdatesel:tvbup_rate},											
											success:function(data){
												/*console.log(data);*/
												$("#tv_updat").html(data);
											}
										})
									}
									tvupoffsel();
								});
					$(document).on("click","#tvoff-update-btn",function(){
						var tvyesno = $(this).data("tvyesno");

						if(tvyesno == "No Offer"){
							$("#tvupdate_off_form").css("display","none");
						}else{
							$("#tvupdate_off_form").css("display","block");
						}
					
					});	
					$("#tv_updat").change(function(){
							var tvoffchage = $(this).val();
							var tv_upbtn = $("#tvoff-update-btn").data("tvbtn");
							var tv_uppri = $("#tvoff-update-btn").data("tvpri");
							var tv_upinputval = $("#tvupdate_off_input").val();
							var tvupans = tv_upinputval * tv_uppri/100;


							
							if(tvoffchage == 0){
								$("#tvupdate_off_form").css("display","none");

								function tvnooffer(){

										$.ajax({
											url:"php/product/php/tv_nooffer.php",
											type:"POST",
											data:{tvbtn_id:tv_upbtn},											
											success:function(data){
												/*console.log(data);*/
												if(data == 1){
													$("#ofuptv-offer").modal("hide");
													tvviewtable(tv_upbtn);

												}else{
													console.log(data);
												}
											}
										})
									}
									tvnooffer();




							}else if(tvoffchage == 1){
								$("#tvupdate_off_form").css("display","block");
							

									$("#tvyes").click(function(c){
										c.preventDefault();
										var tv_uppri = $("#tvoff-update-btn").data("tvpri");
										var tv_upinputval = $("#tvupdate_off_input").val();
										var tvupans = tv_uppri* tv_upinputval/100;
										var tv_tot_per = tv_uppri - tvupans;
									
										(tv_tot_per);

												$.ajax({
													url:"php/product/php/tv_yesoffer.php",
													type:"POST",
													data:{btv_id:tv_upbtn,tvotup:tv_tot_per,tvval:tv_upinputval},											
													success:function(data){
														/*console.log(data);*/
														if(data == 1){
															$("#ofuptv-offer").modal("hide");
															$("#tvupdate_off_input").val("");
														tvviewtable(tv_upbtn);

														}else{
													console.log(data);
												}
													}
												})
																						

											})
									}
						})

					$(document).on("click","#tvdis-update-btn",function(){
							var tvdis = $(this).data("tvdis");
							var tvdisid = $(this).data("tvsno");
							/*alert(tvdis+" "+tvdisid)*/

								function tvdisopp(){

										$.ajax({
											url:"php/product/php/tvdissel.php",
											type:"POST",
											data:{tvdis:tvdis},											
											success:function(data){
												/*console.log(data);*/
												$("#tv_dis_opp").html(data);
											}
										})
									}
									tvdisopp();
						});

					$("#tv_dis_opp").on("change",function(){
								var tvval = $(this).val();
								var tvdisid = $("#tvdis-update-btn").data("tvsno");
								/*alert(tvval);*/

								if(tvval == 1){
									/*alert("tv display" + tvdisid)*/
									$.ajax({
											url:"php/product/php/yes_tvdissel.php",
											type:"POST",
											data:{id:tvdisid},											
											success:function(data){
												/*console.log(data);*/
												if(data == 1){
													$("#disuptv").modal("hide");
													tvviewtable(tvdisid);
												}else{
													console.log(data);
												}
											}
										})
								}else{
									/*alert("no tv display" + tvdisid);*/
									$.ajax({
											url:"php/product/php/no_tvdissel.php ",
											type:"POST",
											data:{id:tvdisid},											
											success:function(data){
												
												if(data == 1){
													$("#disuptv").modal("hide");
													tvviewtable(tvdisid);
												}else{
													console.log(data);
												}
											}
										})
								}



							})

					$(document).on("click","#tvratech",function(c){
								c.preventDefault();
								var tvinrate = $("#tvuprate_input").val();
								var tvrateid = $("#tvbrate-update-btn").data("btvno");

								/*alert(tvinrate + " "+ tvrateid)*/


								$.ajax({
											url:"php/product/php/tvuprate.php",
											type:"POST",
											data:{id:tvrateid,nrate:tvinrate},											
											success:function(data){
												if(data == 1){
													console.log(data);
													$("#tv-arate").modal("hide");
													$("#tvuprate_input").val("")
													tvviewtable(tvrateid);
												}
											}
										})
							})


						

});