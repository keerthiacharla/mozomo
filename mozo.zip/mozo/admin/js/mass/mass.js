$(document).ready(function(){
	alert("mass js 11111111");

/**/
	$(document).on("click",".inbox",function(){
		$(this).addClass("active-btn");
		$(".send").removeClass("active-btn");

		$(".mass-div").css("display","block");
		$(".send-del").css("display","none");
	})
	$(document).on("click",".send",function(){
		$(this).addClass("active-btn");
		$(".inbox").removeClass("active-btn");
		$(".mass-div").css("display","none");
		$(".send-del").css("display","block");
	})

	function inputmass(){
		$.ajax({
			url:"php/mass/php/mass-view.php",
			success:function(data){
				$(".mass-del").html(data);
			}
		})
	}
	inputmass();


	function unread(){
		$.ajax({
			url:"php/mass/php/unread.php",
			success:function(data){
				if(data != 0){
					$("#uread-status").html(data);
				}else{
					$("#uread-status").css("display","none");
					/*console.log(data);*/
				}
			}
		})
	}
	unread();


	$(document).on("click","#mass-show-btn",function(r){
		r.preventDefault();
		var sid = $(this).data("sid");
			

		function inputmassbox(){
		$.ajax({
			url:"php/mass/php/massbox-view.php",
			type:"POST",
			data:{id:sid},
			success:function(data){
				$(".mass-box").html(data);
				inputmass();
				unread();
			}
		})
	}
	inputmassbox();



	})

	$(document).on("click","#mass-rly-btn",function(r){
		r.preventDefault();
		var rid = $(this).data("rid");
		var name = $(this).data("cos");
		var opp = $(this).data("opp");

		$("#see_mass2").modal("show");

		alert(rid +" "+ name +" "+ opp);

		$("#cosmass_id").val(rid);
		$("#cosmass_cos").val(name);
		$("#cosmass_opp").val(opp);
		
	})
	function inputsentmass(){
		$.ajax({
			url:"php/mass/php/mass-sent-view.php",
			success:function(data){
				$(".send-mass-del").html(data);
			}
		})
	}
	inputsentmass();

	$("#mass-form").submit(function(i){
		i.preventDefault();
		

	

		

		$.ajax({
			url:"php/mass/php/massbox-form.php",
			type:"POST",
			data:$("#mass-form").serialize(),
			success:function(data){
				if(data == 1){
					$("#rpl").modal("hide");
					inputmass();
					unread();
					inputsentmass();
				}else{
					console.log(data);
				}
			}
		})



	})

	$(document).on("click","#del-all-opp",function(){
		if($("#del-all-opp").prop("checked")){

			$('input[name="mass-del-opp"]').each(function(){
					$('#'+this.id).prop("checked",true);
					$("#del-all").css("display","block");

				});
		}else{
			$('input[name="mass-del-opp"]').each(function(){
					$('#'+this.id).prop("checked",false);
					$("#del-all").css("display","none");

				});
		}

			
		
});

	$(document).on("click",".mass_opp",function(){

		var sapval = $(this).val();

		if($(this).prop("checked")){
			$("#del-all").css("display","block");	

		}else{
			$("#del-all").css("display","none");	
		}

		
	})

	
		


	
	$(document).on("click","#del-all",function(b){
		b.preventDefault();

			var input = $("#mass-del-opp");

			var valu = [];

			var thi = $(this);

			$('input[name="mass-del-opp"]:checked').each(function(){
				valu.push($(this).val());

			});
			/*console.log(valu)*/
			

			$.ajax({
					url:"php/mass/php/massbox-delete.php",
					type:"POST",
					data:{id:valu},
					success:function(data){
						if(data == 1){
							inputmass();

						}else{
							console.log(data);
						}
					}
				})
	




		})

	


})