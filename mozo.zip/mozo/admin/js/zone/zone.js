$(document).ready(function(){
	/*alert("zone.js");*/
function showzone_btn(){
		$.ajax({
						url:"php/zone/php/showzone_btn.php",
						
						success:function(data){
							/*console.log(data);*/
							$("#zone_table_row").html(data);
						
						}
					})
	}
	showzone_btn();

		function loadzonestatedatasel(type,id){
				$.ajax({
						url:"php/zone/php/loadstatedatasel.php",
						type:"POST",
						data:{type:type,id:id},
						success:function(data){
							if(type == "statedata"){
								$("#zone-city").html(data);
								
							}else{
								$("#zone-dis").html(data);
							}
						
						
								

							
						}
					})
	}
	loadzonestatedatasel();





	$("#zone-dis").change(function(){
		var idval = $("#zone-dis").val();
		/*alert(idval);*/
		loadzonestatedatasel("statedata",idval);
	})



	function loadzonestatedatasearchzone(type,id){
				$.ajax({
						url:"php/zone/php/loadstatedatasel.php",
						type:"POST",
						data:{type:type,id:id},
						success:function(data){
							if(type == "statedata"){
								$("#search-zone-dis").html(data);
								
							}else if(type == "zonedata"){
								$("#search-zone-zone").html(data);

							}else{
								$("#search-zone-state").html(data);
							}
						
						
								

							
						}
					})
	}
	loadzonestatedatasearchzone();





	$("#search-zone-state").change(function(){
		var se_idval = $("#search-zone-state").val();
		alert(se_idval);
		loadzonestatedatasearchzone("statedata",se_idval);

		function search_state(){
				$.ajax({
						url:"php/zone/php/search_state.php",
						type:"POST",
						data: {se_idval:se_idval},
						
						success:function(data){
							/*console.log(data);*/
							$("#zone_table_row").html(data);
						
						
						
								

							
						}
					})
	}
	search_state();
	})

	$("#search-zone-dis").change(function(){
		/*s*/
		var se_dis = $("#search-zone-dis").val();
		alert(se_dis);
		loadzonestatedatasearchzone("zonedata",se_dis);

		function searchzone_dis(){
				$.ajax({
						url:"php/zone/php/searchzone_dis.php",
						type:"POST",
						data: {se_dis:se_dis},
						
						success:function(data){
							/*console.log(data);*/
							$("#zone_table_row").html(data);
						
						
						
								

							
						}
					})
	}
	searchzone_dis();
	})


	

	$(document).on("submit","#zone-form",function(e){
		e.preventDefault();

		var zone_form = $("#zone-form").serialize();

		alert(zone_form);

		$.ajax({
						url:"php/zone/php/add-zone.php",
						type:"POST",
						data:$("#zone-form").serialize(),
						success:function(data){
							if(data == 1){
								$("#zone-add").modal("hide");

							}else{
								console.log(data);
								$(".mob-error").css("display","block");
								$(".mob-error").fadeIn();
								$(".mob-error").html("This Addreen Already Have Been Inserted  ");
								setTimeout(function(){
									$(".mob-error").fadeOut();
									$(".mob-error").css("display","none");
									$(".mob-error").html("");
									},5000);
								return false;
							}
						}

					})
	})

	


	$(document).on("click","#del-zone-btn",function(){

		var id = $(this).data("did");
		var zonetr = $(this);
		
		/*alert(spvaldel);*/
			
			$.ajax({
					url:"php/zone/php/del-zone-data.php",
					type:"POST",
					data :{id:id},
					success : function(data){
						if(data == 1){
							$(zonetr).closest("tr").fadeOut();
							showzone_btn();
						}else{
							console.log(data);
						}
						

						
					}
				});



	})
})