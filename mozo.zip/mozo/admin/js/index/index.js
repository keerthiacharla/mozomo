$(document).ready(function(){
	/*alert("index.js aaaaaaaaaaa");
*/


	 $("#icon,#moruser_icon,#logreset_show_icon,#logreset_icon,#logreset_reset_icon").click(function(){


                $("#show_icon,#moruser_show_icon,#logreset_show_icon,#logreset_com_show_icon").toggleClass("fa-eye-slash");


                $("#show_icon,#moruser_show_icon,#logreset_show_icon,#logreset_com_show_icon").css("color","black")


                $(".fa-eye-slash").css("color","red");


      var input= $("#us_pass,#moruser_us_pass,#logreset_us_pass,#logreset_retus_pass");
                    
            if(input.attr("type")==="password"){
    
                input.attr("type","text");
            
            }else{
                input.attr("type","password");
            }

			})

	 
        $("#index_role").change(function(){
            var value = $(this).val();
           /* alert(value)*/

            if(value == 1){
                $("#adminuse_modal").modal("show");

               
                $("#adminid_add").submit(function(v){ 
                    v.preventDefault();
                   
                    var idval = $("#adminid").val();
                     /*alert(value + " "+ idval);*/


                             $.ajax({
                                    url:"php/index/php/addadminuser.php",
                                    type:"POST",
                                    data: {idval : idval , val: value},
                                   success:function(data){
                                    
                                        if(data == 1){
                                             $("#moruser_input").css("display","none");
                                             $("#form_input").css("display","block");
                                              $("#adminuse_modal").modal("hide");
                                              $("#adminid_add").trigger("reset");
                                              $("#us_name").val(idval);

                                             $("#sign-up,#for-pass").css("display","block");
                                            
                                        }else{
                                            $("#ad-erro").css("display","block");                                      
                                           
                                                $("#ad-erro").html("You had not have permisson");
                                                setTimeout(function(){
                                                    $("#ad-erro").fadeOut();
                                                    $("#ad-erro").css("display","none");
                                                    $("#ad-erro").html("");

                                                },5000);
                                                console.log(data)
                                            return false;

                                        }
                                    }
                                 })
                           
                                         
                    
                })
               
                

                $("#form_input").submit(function(i){
                    i.preventDefault();
                          /*  alert("yes");*/
                        var name = $("#us_name").val();  
                        var pass = $("#us_pass").val();  

                            $.ajax({
                                url:"php/index/php/aduser.php",
                                type:"POST",
                                data: {name:name,pass:pass,id:value},
                                success:function(data){
                                    if(data == "yes login"){
                                     
                                      swal({
                                              title: "Welcome",
                                              text: "login Suceessfully",
                                              icon: "success",
                                              
                                        });
                                        
                                        window.location.href ='http://localhost/mozo/admin/home.php'
                                    }else if(data == "No login"){
                                             $("#log_error").css("display","block");                                      
                                           
                                                $("#log_error").html("Crediatials is Incorrect");
                                                setTimeout(function(){
                                                    $("#log_error").fadeOut();
                                                    $("#log_error").css("display","none");
                                                    $("#log_error").html("");

                                                },5000);
                                                console.log(data)
                                            return false;
                                    }
                                }
                            })
                       })
            }else if(value == 0){

                $("#form_input").css("display","none");
                 $("#moruser_input").css("display","block");


                $(document).on("click","#moruser_sign-in",function(c){
                    c.preventDefault();

                    var usname = $("#moruser_us_name").val();
                    var nor_pass = $("#moruser_us_pass").val();

                    /*console.log(usname + " " + nor_pass);*/


                             $.ajax({
                                url:"php/index/php/nor-user.php",
                                type:"POST",
                                data: {usname : usname,pass:nor_pass,id:value},
                                success:function(data){
                                  console.log(data);
                                    if(data == 2){
                                     /*   alert("You Should Reset the password");*/
                                        $("#log_reset").modal("show");
                                        $("#loreset-heder").html(usname);
                                        $("#loreset-id").val(usname);

                                       }else if(data == 1){
                                             swal({
                                                  title: "Welcome",
                                                  text: "login Suceessfully",
                                                  icon: "success",
                                                  
                                            });
                                        
                                        window.location.href ='http://localhost/mozo/admin/home.php'

                                    }else if(data == 0){
                                             $("#log_error").css("display","block");                                      
                                           
                                                $("#log_error").html("Crediatials is Incorrect");
                                                setTimeout(function(){
                                                    $("#log_error").fadeOut();
                                                    $("#log_error").css("display","none");
                                                    $("#log_error").html("");

                                                },5000);
                                                console.log(data)
                                            return false;
                                    }
                                }
                                });
                                     
                                      
                                              
                                        
                })

               
            }
        })

        /*Logout .php*/

        $(document).on("click","#logreset-sub",function(a){
            a.preventDefault();

            var reset_pass = $("#logreset_us_pass").val();
            var reset_cpass = $("#logreset_retus_pass").val();
             var correct_pass = /^[a-z]{4,7}[0-1]{1}@$/;

            if(reset_pass == ""){
                $("#ad-reset-erro").css("display","block");                                      
                                           
                           $("#ad-reset-erro p").html("Please Enter Password");
                           setTimeout(function(){
                               $("#ad-reset-erro ").fadeOut();
                               $("#ad-reset-erro p").html("");
                        },5000);
                    return false;

            }else if(!correct_pass.test(reset_pass)){
                $("#ad-reset-erro").css("display","block");                                      
                                           
                           $("#ad-reset-erro P").html("Please Enter Valid Password");
                           setTimeout(function(){
                               $("#ad-reset-erro").fadeOut();
                              
                               $("#ad-reset-erro p").html("");
                        },5000);
                    return false;

                }else if(reset_cpass == ""){
                $("#ad-reset-erro").css("display","block");                                      
                                           
                           $("#ad-reset-erro P").html("Please Enter Confirm Password");
                           setTimeout(function(){
                               $("#ad-reset-erro").fadeOut();
                              
                               $("#ad-reset-erro p").html("");
                        },5000);
                    return false;
                }else if(reset_cpass!== reset_pass){
                $("#ad-reset-erro").css("display","block");                                      
                                           
                           $("#ad-reset-erro P").html("Please Enter Password are not matched ");
                           setTimeout(function(){
                               $("#ad-reset-erro").fadeOut();
                              
                               $("#ad-reset-erro p").html("");
                        },5000);
                    return false;
                }

                     $.ajax({
                                url:"php/index/php/updapass.php",
                                type:"POST",
                                data: $("#logreset_add").serialize(),
                                success:function(data){
                                   if(data == 1){
                                     $("#log_reset").modal("hide");
                                       window.location.href ='http://localhost/mozo/admin/'

                                   }else{
                                    console.log(data)
                                   }
                                }
                                    
                            })
            
        })

        


       
})