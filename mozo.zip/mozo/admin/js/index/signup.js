$(document).ready(function(){
	/*alert("singn up");*/
     $("#f_name,#l_name,#nor_f_name,#nor_l_name").keypress(function(evt){
            var ch = String.fromCharCode(evt.which);
                if((/[0-9/!/@/#/$/%/^/&/*/(/)/_/-/+/=/{/[/?/}/:/;/""/''/</,/>/./// ]/.test(ch))){
                    evt.preventDefault();
                    }
            });
      $("#us_phone,#nor_us_phone").keypress(function(evt){
            var ch = String.fromCharCode(evt.which);
                if((/[a-zA-Z/!/@/#/$/%/^/&/*/(/)/_/-/+/=/{/[/?/}/:/;/""/''/</,/>/./// ]/.test(ch))){
                    evt.preventDefault();
                    }
            });

    $("#us_sel").change(function(){
        var input = $(this).val();
       /* alert(input);*/

        if(input == 1){
            $("#ad_user").val(input);

                $("#singup_ad_form").css("display","block");
                $("#singup_nor_form").css("display","none");

               $("#singup_ad_form").submit(function(b){
                b.preventDefault();
                var signup_ad = $("#singup_ad_form").serialize();
                    

                    var first_nsme = $("#f_name").val();
                    var last_nsme = $("#l_name").val();
                    var ad_email = $("#us_email").val();
                    var ad_ph = $("#us_phone").val();
                    var gender = $(".gender");
                    var correct_email = /^[a-z]{3,}@[a-z]{3,}.[a-z]{2,}.([a-z]{2})?$/;

                   if((gender).filter(":checked").length < 1){
                             $(".gen_na_error").css("display","block");
                             $("#signup_error").css("display","block");
                                $("#error-box").fadeIn();
                                $("#signup_error").html("Please Select gender ");
                                setTimeout(function(){
                                    $("#signup_error").fadeOut();
                                    $("#signup_error").css("display","none");
                                    $("#signup_error").html("");

                                },5000);
                                return false;
                        }else if(first_nsme == ""){
                        $(".fir_na_error").css("display","block");
                        $("#signup_error").css("display","block");
                            $("#error-box").fadeIn();
                            $("#signup_error").html("Please Enter First Name");
                            setTimeout(function(){
                                $("#signup_error").fadeOut();
                                $("#signup_error").css("display","none");
                                $("#signup_error").html("");

                            },5000);
                        return false;

                    }else if(last_nsme == ""){
                        $(".last_na_error").css("display","block");
                        $("#signup_error").css("display","block");
                            $("#error-box").fadeIn();
                            $("#signup_error").html("Please Enter Last Name");
                            setTimeout(function(){
                                $("#signup_error").fadeOut();
                                $("#signup_error").css("display","none");
                                $("#signup_error").html("");

                            },5000);
                            return false;

                    }else if(ad_email == ""){
                                 $(".email_na_error").css("display","block");
                                $("#signup_error").css("display","block");
                                    $("#error-box").fadeIn();
                                    $("#signup_error").html("Please Enter Email ID");
                                    setTimeout(function(){
                                        $("#signup_error").fadeOut();
                                        $("#signup_error").css("display","none");
                                        $("#signup_error").html("");

                                    },5000);
                                    return false;

                    

                    }else if(!correct_email.test(ad_email)){
                           $(".email_na_error").css("display","block");
                           $("#signup_error").css("display","block");
                            $("#error-box").fadeIn();
                            $("#signup_error").html("Email ID is Invalid ");
                            setTimeout(function(){
                                $("#signup_error").fadeOut();
                                $("#signup_error").css("display","none");
                                $("#signup_error").html("");

                            },5000);
                            return false;

                        }else if(ad_ph == ""){
                                 $(".ph_na_error").css("display","block");
                                $("#signup_error").css("display","block");
                                    $("#error-box").fadeIn();
                                    $("#signup_error").html("Please Enter Phone Number");
                                    setTimeout(function(){
                                        $("#signup_error").fadeOut();
                                        $("#signup_error").css("display","none");
                                        $("#signup_error").html("");

                                    },5000);
                                    return false;

                    }

                    $.ajax({
                        url:"php/index/php/signup.php",
                        type:"POST",
                        data:$("#singup_ad_form").serialize(),
                        success:function(data){
                            if(data == "file is already exsist"){
                                    $("#signup_error").css("display","block");
                                    $("#error-box").fadeIn();
                                    $("#signup_error").html("file is already exsist");
                                    setTimeout(function(){
                                        $("#signup_error").fadeOut();
                                        $("#signup_error").css("display","none");
                                        $("#signup_error").html("");

                                    },5000);

                            }else if(data == 1){
                                  $("#singup_ad_form").trigger("reset");
                                  $("#signup-form").modal("hide");
                                swal({
                                              title: "Added User",
                                              text: "Welcome to MOZOMO",
                                              icon: "success",
                                              
                                        });
                            }
                        }

                    })



               });

            }else if(input == 0){
            /*    alert(input);*/
                $("#nor_user").val(input);
                 $("#singup_nor_form").css("display","block");
                $("#singup_ad_form").css("display","none");

                $("#nor_user").val(input);

            $("#singup_nor_form").submit(function(b){
                b.preventDefault();
                var nor_signup_ad = $("#singup_nor_form").serialize();
                    

                    var nor_first_nsme = $("#nor_f_name").val();
                    var nor_last_nsme = $("#nor_l_name").val();
                    var nor_ad_email = $("#nor_us_email").val();
                    var nor_ad_ph = $("#nor_us_phone").val();
                    var nor_gender = $(".nor_gender");
                    var nor_correct_email = /^[a-z]{3,}@[a-z]{3,}.[a-z]{2,}.([a-z]{2})?$/;

                   if((nor_gender).filter(":checked").length < 1){
                             $(".nor_gen_na_error").css("display","block");
                             $("#signup_error").css("display","block");
                                $("#error-box").fadeIn();
                                $("#signup_error").html("Please Select gender ");
                                setTimeout(function(){
                                    $("#signup_error").fadeOut();
                                    $("#signup_error").css("display","none");
                                    $("#signup_error").html("");

                                },5000);
                                return false;
                        }else if(nor_first_nsme == ""){
                        $(".nor_fir_na_error").css("display","block");
                        $("#signup_error").css("display","block");
                            $("#error-box").fadeIn();
                            $("#signup_error").html("Please Enter First Name");
                            setTimeout(function(){
                                $("#signup_error").fadeOut();
                                $("#signup_error").css("display","none");
                                $("#signup_error").html("");

                            },5000);
                        return false;

                    }else if(nor_last_nsme == ""){
                        $(".nor_last_na_error").css("display","block");
                        $("#signup_error").css("display","block");
                            $("#error-box").fadeIn();
                            $("#signup_error").html("Please Enter Last Name");
                            setTimeout(function(){
                                $("#signup_error").fadeOut();
                                $("#signup_error").css("display","none");
                                $("#signup_error").html("");

                            },5000);
                            return false;

                    }else if(nor_ad_email == ""){
                                 $(".nor_email_na_error").css("display","block");
                                $("#signup_error").css("display","block");
                                    $("#error-box").fadeIn();
                                    $("#signup_error").html("Please Enter Email ID");
                                    setTimeout(function(){
                                        $("#signup_error").fadeOut();
                                        $("#signup_error").css("display","none");
                                        $("#signup_error").html("");

                                    },5000);
                                    return false;

                    

                    }else if(!nor_correct_email.test(nor_ad_email)){
                           $(".nor_email_na_error").css("display","block");
                           $("#signup_error").css("display","block");
                            $("#error-box").fadeIn();
                            $("#signup_error").html("Email ID is Invalid ");
                            setTimeout(function(){
                                $("#signup_error").fadeOut();
                                $("#signup_error").css("display","none");
                                $("#signup_error").html("");

                            },5000);
                            return false;

                        }else if(nor_ad_ph == ""){
                                 $(".nor_ph_na_error").css("display","block");
                                $("#signup_error").css("display","block");
                                    $("#error-box").fadeIn();
                                    $("#signup_error").html("Please Enter Phone Number");
                                    setTimeout(function(){
                                        $("#signup_error").fadeOut();
                                        $("#signup_error").css("display","none");
                                        $("#signup_error").html("");

                                    },5000);
                                    return false;

                    }
                   /* alert(nor_signup_ad);*/

                    $.ajax({
                        url:"php/index/php/nor_user.php",
                        type:"POST",
                        data:$("#singup_nor_form").serialize(),
                        success:function(data){
                         /*   console.log(data);*/
                            if(data == "file is already exsist"){
                                    $("#signup_error").css("display","block");
                                    $("#error-box").fadeIn();
                                    $("#signup_error").html("file is already exsist");
                                    setTimeout(function(){
                                        $("#signup_error").fadeOut();
                                        $("#signup_error").css("display","none");
                                        $("#signup_error").html("");

                                    },5000);

                            }else if(data == 1){
                                $("#singup_nor_form").trigger("reset");
                                $("#signup-form").modal("hide");

                                swal({
                                              title: "Added User",
                                              text: "Welcome to MOZOMO",
                                              icon: "success",
                                              
                                        });
                            }else{
                                console.log(data)
                            }
                        }

                    })



               })

            }
    })

    


	
	 
        
   

})