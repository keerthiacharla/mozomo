$(document).ready(function(){
	/*alert("home.js");*/


	function empldel(){
			   $.ajax({
                     url:"php/index/php/empldel.php",
                     success:function(data){
                     	$(".empl-del").html(data);
                        
                                }
                            })
					}
					empldel()

					function empics(){
							   $.ajax({
				                     url:"php/index/php/empics.php",
				                     success:function(data){
				                     	$(".empl-pics").html(data);
				                        
				                                }
				                            })
									}
					empics();

					$(document).on("click","#logout_user",function(u){ 
						u.preventDefault();
								

							 $.ajax({
				                     url:"php/index/php/logout.php",
				                     success:function(data){
				                     	if(data == 1){
				                     	
				                     		window.location.href ='http://localhost/mozo/admin';
				                     		swal({
                                              title: "Updated Successfully",
                                              text: "Updated your name",
                                              icon: "success",
                                              button: "OK",
                                        });

				                     	}else{
				                     		console.log(data);
				                     	}
				                        
                                }
                            })
					
					})

					$(document).on("submit","#img-uploade",function(o){
					            o.preventDefault();

					            /*alert("img-uploade");*/

					            var img = new FormData(this);

					             $.ajax({
				                     url:"php/index/php/img-uploade.php",
				                     type:"POST",
				                   	 data : img,
									 contentType:false,
									 processData:false,
				                     success:function(data){
				                     	if(data == 1){
				                     		$("#img-uploade").trigger("reset");
				                     		$("#first-img-modal").modal("hide");
				                     		window.location.href ='http://localhost/mozo/admin';				                     	
				                     		

				                     	}else if(data == 2){

				                     		$("#ad-erro").css("display","block");                                      
                                           
					                           $("#ad-erro").html("File is not support.. please uploade jpg ,jpeg");
					                           setTimeout(function(){
					                               $("#ad-erro").fadeOut();
					                              
					                               $("#ad-erro").html("");
					                        },5000);

				                     	}else{
				                     		console.log(data);
				                     	}
				                        
				                                }
				                            })
					        })
		})