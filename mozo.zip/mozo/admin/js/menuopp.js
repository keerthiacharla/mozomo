$(document).ready(function(){
			/*alert("menu options");*/


$(document).on("click","#show",function(e){
		e.preventDefault();

		$("#menu-bar").toggle("slow");

	});

$("#product").addClass("active");
$(".product").css("display","block");
	
	$("#product").click(function(){
		

		$(this).addClass("active");
		$("#overview").removeClass("active");
		$("#setting").removeClass("active");
		$("#products_cat").removeClass("active");
		$("#products_data").removeClass("active");
		$("#user_data").removeClass("active");
		$("#carosol").removeClass("active");
		$("#delivery").removeClass("active");
		$("#zon").removeClass("active");
		$("#cos-mass").removeClass("active");
		$("#pay-opp").removeClass("active");
		$("#all-orders").removeClass("active");
		$("#pay-menu").removeClass("active");

		$(".product").css("display","block");
		$(".carosol_container").css("display","none");
		$(".set").css("display","none");
		$(".pro-set-con").css("display","none");
		$(".user-set-con").css("display","none");
		$(".pay_con").css("display","none");
		$(".deli_items_container").css("display","none");
		$(".zone_items_container").css("display","none");
			$(".allpayment_items_container").css("display","none");
		$(".mass_con").css("display","none");
	})

	$("#products_cat").click(function(){
		

		$("#setting").addClass("active");
		$(this).addClass("active");
		$("#product").removeClass("active");
		$("#overview").removeClass("active");
		$("#products_data").removeClass("active");
		$("#user_data").removeClass("active");
		$("#carosol").removeClass("active");
		$("#delivery").removeClass("active");
		$("#zon").removeClass("active");
		$("#cos-mass").removeClass("active");
		$("#pay-opp").removeClass("active");
		$("#all-orders").removeClass("active");
		$("#pay-menu").removeClass("active");

		$(".pro-set-con").css("display","none");
		$(".set").css("display","block");
		$(".product").css("display","none");
		$(".carosol_container").css("display","none");
		$(".user-set-con").css("display","none");
		$(".pay_con").css("display","none");
		$(".deli_items_container").css("display","none");
		$(".zone_items_container").css("display","none");
			$(".allpayment_items_container").css("display","none");
		$(".mass_con").css("display","none");
	})
	$("#products_data").click(function(){
		/*alert("a");*/
		

		$(this).addClass("active");
		$("#product").removeClass("active");
		$("#overview").removeClass("active");
		$("#setting").addClass("active");
		$("#products_cat").removeClass("active");
		$("#user_data").removeClass("active");
		$("#carosol").removeClass("active");
		$("#delivery").removeClass("active");
		$("#zon").removeClass("active");
		$("#cos-mass").removeClass("active");
		$("#pay-opp").removeClass("active");
		$("#all-orders").removeClass("active");
		$("#pay-menu").removeClass("active");

		$(".pro-set-con").css("display","block");
		$(".set").css("display","none");
		$(".user-set-con").css("display","none");
		$(".product").css("display","none");
		$(".carosol_container").css("display","none");
		$(".pay_con").css("display","none");
		$(".deli_items_container").css("display","none");
		$(".zone_items_container").css("display","none");
		$(".allpayment_items_container").css("display","none");
		$(".mass_con").css("display","none");
	})


	$("#user_data").click(function(){
		/*alert("b");*/
		

		$(this).addClass("active");
		$("#product").removeClass("active");
		$("#products_data").removeClass("active");
		$("#overview").removeClass("active");
		$("#setting").addClass("active");
		$("#products_cat").removeClass("active");
		$("#carosol").removeClass("active");
		$("#delivery").removeClass("active");
		$("#zon").removeClass("active");
		$(".user-set-con").css("display","block");
		$(".pro-set-con").css("display","none");
		$(".set").css("display","none");
		$("#cos-mass").removeClass("active");
		$("#pay-opp").removeClass("active");
		$("#all-orders").removeClass("active");
		$("#pay-menu").removeClass("active");

		$(".product").css("display","none");
		$(".carosol_container").css("display","none");
		$(".pay_con").css("display","none");
		$(".deli_items_container").css("display","none");
		$(".zone_items_container").css("display","none");
			$(".allpayment_items_container").css("display","none");
		$(".mass_con").css("display","none");
	})

	$("#carosol").click(function(){
		

		$(this).addClass("active");
		$("#setting").addClass("active");
		$("#product").removeClass("active");
		$("#products_cat").removeClass("active");
		$("#products_data").removeClass("active");
		$(".set").css("display","none");
		$("#user_data").removeClass("active");
		$("#delivery").removeClass("active");
		$("#zon").removeClass("active");
		$("#cos-mass").removeClass("active");
		$("#pay-opp").removeClass("active");
		$("#all-orders").removeClass("active");
		$("#pay-menu").removeClass("active");

		$(".carosol_container").css("display","block");
		$(".product").css("display","none");
		$(".pro-set-con").css("display","none");
		$(".user-set-con").css("display","none");
		$(".pay_con").css("display","none");
		$(".deli_items_container").css("display","none");
		$(".zone_items_container").css("display","none");
			$(".allpayment_items_container").css("display","none");
		$(".mass_con").css("display","none");
	})

	$("#delivery").click(function(){
		/*alert("aaaaaaaaaa");*/
		

		$(this).addClass("active");
		$("#setting").addClass("active");
		$("#carosol").removeClass("active");
		$("#product").removeClass("active");
		$("#products_cat").removeClass("active");
		$("#products_data").removeClass("active");
		$(".set").css("display","none");
		$("#user_data").removeClass("active");
		$("#zon").removeClass("active");
		$("#cos-mass").removeClass("active");
		$("#pay-opp").removeClass("active");
		$("#all-orders").removeClass("active");
		$("#pay-menu").removeClass("active");

		$(".deli_items_container").css("display","block");
		$(".carosol_container").css("display","none");
		$(".product").css("display","none");
		$(".pro-set-con").css("display","none");
		$(".user-set-con").css("display","none");
		$(".pay_con").css("display","none");
		$(".zone_items_container").css("display","none");
			$(".allpayment_items_container").css("display","none");
					$(".mass_con").css("display","none");
	})

	$("#zon").click(function(){
		/*alert("aaaaaaaaaa");*/
		

		$(this).addClass("active");
		$("#setting").addClass("active");
		$("#delivery").removeClass("active");
		$("#carosol").removeClass("active");
		$("#product").removeClass("active");
			$("#products_cat").removeClass("active");
		$("#products_data").removeClass("active");
		$(".set").css("display","none");
		$("#user_data").removeClass("active");
		$("#cos-mass").removeClass("active");
		$("#pay-opp").removeClass("active");
		$("#all-orders").removeClass("active");
		$("#pay-menu").removeClass("active");


		$(".zone_items_container").css("display","block");
		$(".deli_items_container").css("display","none");
		$(".carosol_container").css("display","none");
		$(".product").css("display","none");
		$(".pro-set-con").css("display","none");
		$(".user-set-con").css("display","none");
		$(".pay_con").css("display","none");
			$(".allpayment_items_container").css("display","none");
			$(".mass_con").css("display","none");

	})

	



	$("#all-orders").click(function(){
		/*alert("aaaaaaaaaa");*/
		

		$(this).addClass("active");
		$("#pay-menu").addClass("active");
		$("#product").removeClass("active");
		$("#setting").removeClass("active");
		$("#products_cat").removeClass("active");
		$("#products_data").removeClass("active");
		$(".set").css("display","none");
		$("#user_data").removeClass("active");
		$("#delivery").removeClass("active");
		$("#zon").removeClass("active");
		$("#cos-mass").removeClass("active");
		$("#pay-opp").removeClass("active");

		$(".allpayment_items_container").css("display","block");
		$(".zone_items_container").css("display","none");
		$(".deli_items_container").css("display","none");
		$(".carosol_container").css("display","none");
		$(".product").css("display","none");
		$(".pro-set-con").css("display","none");
		$(".user-set-con").css("display","none");
		$(".pay_con").css("display","none");
		$(".mass_con").css("display","none");
	})

	$("#pay-opp").click(function(){
	/*	alert("a");*/
		
 
		$(this).addClass("active");
		$("#pay-menu").addClass("active");
		$("#product").removeClass("active");
		$("#overview").removeClass("active");
		$("#setting").removeClass("active");
		$("#products_cat").removeClass("active");
		$("#user_data").removeClass("active");
		$("#carosol").removeClass("active");
		$("#delivery").removeClass("active");
		$("#cos-mass").removeClass("active");
		$("#all-orders").removeClass("active");
		$("#zon").removeClass("active");
		$(".pay_con").css("display","block");
		$(".pro-set-con").css("display","none");
		$(".set").css("display","none");
		$(".user-set-con").css("display","none");
		$(".product").css("display","none");
		$(".carosol_container").css("display","none");
		$(".deli_items_container").css("display","none");
		$(".zone_items_container").css("display","none");
			$(".allpayment_items_container").css("display","none");
		$(".mass_con").css("display","none");
	})

	$("#cos-mass").click(function(){
		/*alert("aaaaaaaaaa");*/
		

		$(this).addClass("active");
		$("#pay-menu").addClass("active");
		$("#setting").removeClass("active");
		$("#product").removeClass("active");
		$("#setting").removeClass("active");
		$("#products_cat").removeClass("active");
		$("#products_data").removeClass("active");
		$("#pay-opp").removeClass("active");
		$("#all-orders").removeClass("active");
		$(".set").css("display","none");
		$("#user_data").removeClass("active");
		$("#delivery").removeClass("active");
		$("#zon").removeClass("active");

		$(".mass_con").css("display","block");
		$(".zone_items_container").css("display","none");
		$(".deli_items_container").css("display","none");
		$(".carosol_container").css("display","none");
		$(".product").css("display","none");
		$(".pro-set-con").css("display","none");
		$(".user-set-con").css("display","none");
		$(".pay_con").css("display","none");
			$(".allpayment_items_container").css("display","none");

	})


});