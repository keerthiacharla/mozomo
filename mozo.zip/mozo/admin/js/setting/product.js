$(document).ready(function(){
	/*alert("product.js after")  ;*/

	function loadproductsel(){
		$.ajax({
			url:"php/setting/php/loadproductsel.php", 
			success:function(data){
				$("#product-cat-seldata,#pro-br,#secipro-seldata").append(data);
				/*$("#product-add-form").trigger("reset");*/
			}
		})
	}
	loadproductsel();

	function loadprodata(){
		$.ajax({
			url:"php/setting/php/loadpro.php",
			success:function(data){
				/*console.log(data);*/
				$("#products_data_table_row").html(data);
			}
		})
	}
	loadprodata();

	$(document).on("click","#product-view",function(e){
		e.preventDefault();

		loadprodata();
		loadproductsel();

	});

	$(document).on("click","#products_cat",function(e){
		e.preventDefault();

		loadprodata();
		loadproductsel();

	});

	$("#product-add-form").submit(function(p){
		p.preventDefault();
	if($(".add-pro-val").val() == "select"){
					$(".mob-error").css("display","block");
					$(".mob-error").fadeIn();
					$(".mob-error").html("Select Brand ");
					setTimeout(function(){
						$(".mob-error").fadeOut();
						$(".mob-error").css("display","none");
						$(".mob-error").html("");
						},5000);
					return false;
		}else if($("#add_pro").val() == ""){
					$(".mob-error").css("display","block");
					$(".mob-error").fadeIn();
					$(".mob-error").html("Enter Product");
					setTimeout(function(){
						$(".mob-error").fadeOut();
						$(".mob-error").css("display","none");
						$(".mob-error").html("");
						},5000);
					return false;
		}
		
		var pro_name = new FormData(this);

		
		$.ajax({
					url:"php/setting/php/add-pro-data.php",
					type:"POST",
					data : pro_name ,
					contentType:false,
					processData:false,
					success : function(data){
						/*console.log(data);*/
						if(data == 1){
								$("#product-add-form").trigger("reset")
								loadprodata();
							}else if(data == 2){
									$(".mob-error").css("display","block");
									$(".mob-error").fadeIn();
									$(".mob-error").html("Alredy Existed this Product ");
									setTimeout(function(){
										$(".mob-error").fadeOut();
										$(".mob-error").css("display","none");
										$(".mob-error").html("");
						},5000);
					return false;
							}else{
									console.log(data);
								}				
					}
				})
	})
	$(document).on("click","#pro-del-btn",function(l){
		l.preventDefault();

		var prodel = $(this).data("did");
		var prorow = $(this);
		
		/*alert(prodel);*/
			
			$.ajax({
					url:"php/setting/php/del-pro-data.php",
					type:"POST",
					data :{delid:prodel},
					success : function(data){
						if(data == 1){
							$(prorow).closest("tr").fadeOut();
						}
						

						
					}
				});
	})
	$("#pro-search-box").keyup(function(){

		var search_pro = $(this).val();

		$.ajax({
					url:"php/setting/php/search-pro-data.php",
					type:"POST",
					data : {search : search_pro},
					success : function(data){
						/*console.log(data);*/
						$("#products_data_table_row").html(data); 
						

						
					}
				})
	})






		
})