import {loaduser} from "./madular.js";
import {slideloaduser} from "./madular.js";
import {tvslideloaduser} from "./madular.js";
import {btnview} from "../product/modulas.js";
import {tvbtnview} from "../product/modulas.js";

$(document).ready(function(){
	/*alert("pro-item.js ");*/
	/*alert(mad+" pro-item.js ");*/




	loaduser();
	slideloaduser();

		$(document).on("click","#protab_delbtn",function(){
			var did = $(this).data("pid");
			var thi = this;
			/*alert(did);*/

			$.ajax({
					url:"php/setting/php/deletemob-data.php",
					type:"POST",
					data:{id: did},
					success : function(data){
						if(data == 1){
							$(thi).closest("tr").fadeOut();
							btnview();
						}

						
					}
				})
		})

		function tvloaduser(){
			$.ajax({
					url:"php/setting/php/tvproduct-data.php",
							
					success : function(data){
						$("#tvproductable_row").html(data);

						
					}
				})
		}
		tvloaduser();

			$(document).on("click","#tvprotab_delbtn",function(){
			var tvdid = $(this).data("tvpid");
			var tvthi = this;
			/*alert(tvdid);*/

			$.ajax({
					url:"php/setting/php/tvdeletemob-data.php",
					type:"POST",
					data:{tid: tvdid},
					success : function(data){
					/*	console.log(data);*/
						if(data == 1){
							$(tvthi).closest("tr").fadeOut();
							tvbtnview();
							
						}else{
							console.log(data);
						}

						
					}
				})
		})

			function tvloaduser(){
			$.ajax({
					url:"php/setting/php/tvproduct-data.php",
							
					success : function(data){
						$("#tvproductable_row").html(data);

						
					}
				})
		}
		tvloaduser();

			

		$(document).on("click","#slprotab_delbtn",function(){
			var slmobdid = $(this).data("slpid");
			var slmobthi = this;
			/*alert(slmobdid);*/

			$.ajax({
					url:"php/setting/php/slmobdeletemob-data.php",
					type:"POST",
					data:{slmodtid: slmobdid},
					success : function(data){
						/*console.log(data);*/
						if(data == 1){
							$(slmobthi).closest("tr").fadeOut();
							btnview();
						}else{
							console.log(data);
						}

						
					}
				})
		})

		
		tvslideloaduser();

		$(document).on("click","#tvslprotab_delbtn",function(){
			var tvslmobdid = $(this).data("tvslpid");
			var tvslmobthi = this;
			/*alert(tvslmobdid);*/

			$.ajax({
					url:"php/setting/php/tvslmobdeletemob-data.php",
					type:"POST",
					data:{tvslmobdid: tvslmobdid},
					success : function(data){
						/*console.log(data);*/
						if(data == 1){
							$(tvslmobthi).closest("tr").fadeOut();
							tvbtnview();
						}else{
							console.log(data);
						}

						
					}
				})
		})
	
})