$(document).ready(function(){
	/*alert("state.js");*/


	function loadstate(){
		$.ajax({
			url:"php/setting/php/loadstate.php",
			
			success:function(data){
				/*console.log(data);*/
				$("#state_data_table_row").html(data);
			}
		})
	}
	loadstate();

	$(document).on("click","#state_input-sub",function(a){
		a.preventDefault();


		var state = $("#state_input").val();
		/*alert(state);*/


		if(state == ""){
					$(".mob-error").css("display","block");
					$(".mob-error").fadeIn();
					$(".mob-error").html("Enter State  ");
					setTimeout(function(){
						$(".mob-error").fadeOut();
						$(".mob-error").css("display","none");
						$(".mob-error").html("");
						},5000);
					return false;
		}
		$.ajax({
					url:"php/setting/php/state.php",
					type:"POST",
					data :{val:state},
					success : function(data){
						/*console.log(data);*/
						if(data == 1){
								$("#state-add-form").trigger("reset")
								loadstate();
							}else if(data == 2){
									$(".mob-error").css("display","block");
									$(".mob-error").fadeIn();
									$(".mob-error").html("Alredy Value is already Exsited ");
									setTimeout(function(){
										$(".mob-error").fadeOut();
										$(".mob-error").css("display","none");
										$(".mob-error").html("");
						},5000);
					return false;
					}else{
							console.log(data);
						}
						

						
					}
				});


	})

	$("#state-val-search-box").keyup(function(){

		var search_state = $(this).val();
		/*alert(search_state);*/

		$.ajax({
					url:"php/setting/php/search-state-val-data.php",
					type:"POST",
					data : {search_state : search_state},
					success : function(data){
						/*console.log(data);*/
						$("#state_data_table_row").html(data);
						

						
					}
				})
			})

	$(document).on("click","#state-del-btn",function(l){
		l.preventDefault();

		var stid = $(this).data("stid");
		var stidrow = $(this);
		
		
		/*alert(stid);*/
			
			$.ajax({
					url:"php/setting/php/del-state-data.php",
					type:"POST",
					data :{stid:stid},
					success : function(data){
						if(data == 1){
							$(stidrow).closest("tr").fadeOut();
						}
						

						
					}
				});
	})


	/*city data */



	function loadcity(){
		$.ajax({
			url:"php/setting/php/loadcity.php",
			
			success:function(data){
				/*console.log(data);*/
				$("#city_data_table_row").html(data);
			}
		})
	}
	loadcity();

	function loadstatesel(){
		$.ajax({
			url:"php/setting/php/loadstatesel.php",
			
			success:function(data){
				/*console.log(data);*/
				$("#city-seldata").html(data);
			}
		})
	}
	loadstatesel();

	$(document).on("click","#add-city-sub",function(b){
		b.preventDefault();


		var city = $("#add_city").val();
		var state_val = $("#city-seldata").val();
		/*alert(state);*/


		if(state_val == "select"){
					$(".mob-error").css("display","block");
					$(".mob-error").fadeIn();
					$(".mob-error").html("Select State  ");
					setTimeout(function(){
						$(".mob-error").fadeOut();
						$(".mob-error").css("display","none");
						$(".mob-error").html("");
						},5000);
					return false;
		}else if(city == ""){
					$(".mob-error").css("display","block");
					$(".mob-error").fadeIn();
					$(".mob-error").html("Enter City  ");
					setTimeout(function(){
						$(".mob-error").fadeOut();
						$(".mob-error").css("display","none");
						$(".mob-error").html("");
						},5000);
					return false;
		}
		$.ajax({
					url:"php/setting/php/city.php",
					type:"POST",
					data :{state:state_val,city:city},
					success : function(data){
						/*console.log(data);*/
						if(data == 1){
								$("#state-add-form").trigger("reset")
								/*loadstate();*/
							}else if(data == 2){
									$(".mob-error").css("display","block");
									$(".mob-error").fadeIn();
									$(".mob-error").html("Alredy Value is already Exsited ");
									setTimeout(function(){
										$(".mob-error").fadeOut();
										$(".mob-error").css("display","none");
										$(".mob-error").html("");
						},5000);
					return false;
					}else{
							console.log(data);
						}
						

						
					}
				});


	})

	$("#city-val-search-box").keyup(function(){

		var search_city = $(this).val();
		/*alert(search_city);*/

		$.ajax({
					url:"php/setting/php/search-city-val-data.php",
					type:"POST",
					data : {search_city : search_city},
					success : function(data){
						/*console.log(data);*/
						$("#city_data_table_row").html(data);
						

						
					}
				})
			})

	$(document).on("click","#city-del-btn",function(l){
		l.preventDefault();

		var cyid = $(this).data("cyid");
		var cyidrow = $(this);
		
		
		/*alert(cyid);*/
			
			$.ajax({
					url:"php/setting/php/del-city-data.php",
					type:"POST",
					data :{cyid:cyid},
					success : function(data){
						if(data == 1){
							$(cyidrow).closest("tr").fadeOut();
						}
						

						
					}
				});
	})
})