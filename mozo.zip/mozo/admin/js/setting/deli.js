$(document).ready(function(){
	alert("deli.js aaaaaaaaaa");


	$("#deli_fname,#deli_lname").keypress(function(evt){
            var ch = String.fromCharCode(evt.which);
                if((/[0-9/!/@/#/$/%/^/&/*/(/)/_/-/+/=/{/[/?/}/:/;/""/''/</,/>/./// ]/.test(ch))){
                    evt.preventDefault();
                    }
            });
      $("#deli_phone,#deli_zip").keypress(function(evt){
            var ch = String.fromCharCode(evt.which);
                if((/[a-zA-Z/!/@/#/$/%/^/&/*/(/)/_/-/+/=/{/[/?/}/:/;/""/''/</,/>/./// ]/.test(ch))){
                    evt.preventDefault();
                    }
            });


 function showdeli_btn(){
		$.ajax({
						url:"php/delivary/php/showdeli_btn.php",
						
						success:function(data){
							/*console.log(data);*/
							$("#show-deli-btn").html(data);
						
						
						
								

							
						}
					})
	}
	showdeli_btn();



		function loadzonestatedatasel(type,id){
				$.ajax({
						url:"php/delivary/php/loadstatedatasel.php",
						type:"POST",
						data:{type:type,id:id},
						success:function(data){
							if(type == "statedata"){
								$("#deli_city").html(data);
								
							}else if(type == "zonedata"){
								$("#deli_zone").html(data);

							}else{
								$("#deli_state").html(data);
							}
						
						
								

							
						}
					})
	}
	loadzonestatedatasel();





	$("#deli_state").change(function(){
		var idval = $("#deli_state").val();
		/*alert(idval);*/
		loadzonestatedatasel("statedata",idval);
	})

	$("#deli_city").change(function(){
		alert("a");
		var zone = $("#deli_city").val();
		/*alert(idval);*/
		loadzonestatedatasel("zonedata",zone);
	})


	function loadzonestatedatasearch(type,id){
				$.ajax({
						url:"php/delivary/php/loadstatedatasel.php",
						type:"POST",
						data:{type:type,id:id},
						success:function(data){
							if(type == "statedata"){
								$("#search-dis").html(data);
								
							}else if(type == "zonedata"){
								$("#search-zone").html(data);

							}else{
								$("#search-state").html(data);

								

							}
						
						
								

							
						}
					})
	}
	loadzonestatedatasearch();





	$("#search-state").change(function(){
		var se_idval = $("#search-state").val();
		/*alert(idval);*/
		loadzonestatedatasearch("statedata",se_idval);

		function search_state(){
				$.ajax({
						url:"php/delivary/php/search_state.php",
						type:"POST",
						data: {se_idval:se_idval},
						
						success:function(data){
							/*console.log(data);*/
							$("#show-deli-btn").html(data);
							$("#show-deli-table").html("");
						
						
						
								

							
						}
					})
	}
	search_state();
	})

	$("#search-dis").change(function(){
		/*s*/
		var se_dis = $("#search-dis").val();
		/*alert(idval);*/
		loadzonestatedatasearch("zonedata",se_dis);

		function search_dis(){
				$.ajax({
						url:"php/delivary/php/search_dis.php",
						type:"POST",
						data: {se_dis:se_dis},
						
						success:function(data){
							/*console.log(data);*/
							$("#show-deli-btn").html(data);
							$("#show-deli-table").html("");
						
						
						
								

							
						}
					})
	}
	search_dis();
	})




	$("#search-zone").change(function(){
		/*alert("a");*/
		var se_zone = $("#search-zone").val();
		

		function search_zone(){
				$.ajax({
						url:"php/delivary/php/search_zone.php",
						type:"POST",
						data: {se_zone:se_zone},
						
						success:function(data){
							/*console.log(data);*/
							$("#show-deli-btn").html(data);
							$("#show-deli-table").html("");
						
						
						
								

							
						}
					})
	}
	search_dis();
	})

	


	$(document).on("submit","#user-deli-form",function(e){
		e.preventDefault();/*
		alert("user-deli-form");*/


		var deli_fname = $("#deli_fname").val();
		var deli_lname = $("#deli_lname").val();
		var deli_gen = $(".deli_gender");
		var deli_email = $("#deli_email").val();
		var deli_phone = $("#deli_phone").val();
		var deli_add = $("#deli_add").val();
		var deli_state = $("#deli_state").val();
		var deli_city = $("#deli_city").val();
		var deli_zone = $("#deli_zone").val();
		var deli_zip = $("#deli_zip").val();
		var deli_dig = $("#deli-dig").val();
		
		var deli_correct_email = /^[a-z]{3,}@[a-z]{3,}.[a-z]{2,}.([a-z]{2})?$/;
		

		if(deli_fname == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter First Name  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(deli_lname == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter Last Name  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if((deli_gen).filter(":checked").length < 1){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Select Gender  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(deli_email == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter Email ID  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(!deli_correct_email.test(deli_email)){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter correct Email ID ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(deli_phone == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter Phone Number ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(deli_phone.length < 9){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Phone Number is invalid  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(deli_add == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter address  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(deli_state == "select"){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Select State  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(deli_city == "select"){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Select city  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;

		}else if(deli_zone == "select"){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Select Zone ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
					
		}else if(deli_zip == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter Pincode ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}
		/*alert($("#user-deli-form").serialize());*/

		$.ajax({
                        url:"php/delivary/php/deli-details.php",
                        type:"POST",
                        data:$("#user-deli-form").serialize(),
                        success:function(data){
                        	/*console.log(data);*/

                        	if(data == "file is already exsist"){

                        		$(".mob-error").css("display","block");
								$(".mob-error").fadeIn();
								$(".mob-error").html("file is already exsist  ");
								setTimeout(function(){
									$(".mob-error").fadeOut();
									$(".mob-error").css("display","none");
									$(".mob-error").html("");
								},5000);
									return false;

                        	}else if(data == 1){
                        		$("#user-deli-form").trigger("reset");
                        		$("#deli-login-add").modal("hide");
                        		showdeli_btn();

                        	}else{
                        		console.log(data);

                        	}
                            
                        }

                    })

		})




	$(document).on("click","#deli-btn",function(){

		var id = $(this).data("deliid");

		alert(id);



					$.ajax({
						url:"php/delivary/php/loadagenttable.php",
						type:"POST",
						data: {id:id},
						
						success:function(data){
							console.log(data);
							$("#show-deli-table").html(data);
						
						
						
								

							
						}
						})



	})

	$(document).on("click","#deli-print",function(e){
			e.preventDefault();

			var delino = $(this).data("delino");

			window.location.href ="php/delivary/php/print-deli.php?id="+delino;


		})

	$("#deli-del-val-search-box").keyup(function(){
		var deli_search = $(this).val();

		/*alert(deli_search);*/
		function showdeli_btn(){
				$.ajax({
						url:"php/delivary/php/search_deli.php",
						type:"POST",
						data: {deli_search:deli_search},
						
						success:function(data){
							/*console.log(data);*/
							$("#show-deli-btn").html(data);
						
						
						
								

							
						}
					})
	}
	showdeli_btn();

	})


})