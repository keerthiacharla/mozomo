$(document).ready(function(){
/*	alert("pro-logo.js");*/

function add_brname(){
	$.ajax({
			url:"php/setting/php/brand-name.php",
			type:"POST",
			
			success : function(data){
				/*console.log(data);*/
				$("#brand_name").html(data)
				
									
			
			}
		})

}
add_brname();

$(document).on("click","#pro-logo-view",function(e){
		e.preventDefault();

		add_brname();

	});

	$(document).on("click","#products_cat",function(e){
		e.preventDefault();

		add_brname();

	});

function loadlogo(){
		$.ajax({
			url:"php/setting/php/loadlogo.php",
		
			success:function(data){
				/*console.log(data);*/
				$("#products_data_logo_table_row").html(data);
			}
		})
	}
	loadlogo();

		$("#product-logo-form").submit(function(a){
			a.preventDefault();

					var log_form = new FormData(this);;

							$.ajax({
										url:"php/setting/php/addlogo.php",
										type:"POST",
										data : log_form ,
										contentType:false,
										processData:false,
										success : function(data){
											/*console.log(data);*/
											if(data == 1){
												$("#product-logo-form").trigger("reset");
												loadlogo();
											}else if(data == 2){
													$(".mob-error").css("display","block");
													$(".mob-error").fadeIn();
													$(".mob-error").html("Alredy Existed this Logo ");
													setTimeout(function(){
														$(".mob-error").fadeOut();
														$(".mob-error").css("display","none");
														$(".mob-error").html("");

													},5000);
														return false;
												}else if(data == 3){
													$(".mob-error").css("display","block");
													$(".mob-error").fadeIn();
													$(".mob-error").html("File is not support.. please uploade jpg ,jpeg ");
													setTimeout(function(){
														$(".mob-error").fadeOut();
														$(".mob-error").css("display","none");
														$(".mob-error").html("");

													},5000);
														return false;
												}else{
														console.log(data);
													}
											
									

											
										}
									})
	})


		$(document).on("click","#del-prologo-btn",function(l){
				l.preventDefault();

				var logoid = $(this).data("logoid");
				var logorow = $(this);
				
				/*alert(logoid);*/
					
					$.ajax({
							url:"php/setting/php/del-pro-logo-data.php",
							type:"POST",
							data :{logoid:logoid},
							success : function(data){
								if(data == 1){
									$(logorow).closest("tr").fadeOut();
									loadlogo();
								}
								

								
							}
						});
	})
})