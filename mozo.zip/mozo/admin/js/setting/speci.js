$(document).ready(function(){
			/*alert("speci 1111 ");*/

	
	$("#spe-btn").click(function(r){
		r.preventDefault();
		/*alert("a");*/

		$(this).next("div").toggle("slow");

	})
	function loadspecdata(){
		$.ajax({
			url:"php/setting/php/loadspec.php",
			success:function(data){
				/*console.log(data);*/
				$("#speci_data_table_row").html(data);
			}
		})
	}
	loadspecdata();

	$("#spec-add-form").submit(function(m){
		m.preventDefault();

		if($(".add_speci_val").val() == "select"){
					$(".mob-error").css("display","block");
					$(".mob-error").fadeIn();
					$(".mob-error").html("Select Brand ");
					setTimeout(function(){
						$(".mob-error").fadeOut();
						$(".mob-error").css("display","none");
						$(".mob-error").html("");
						},5000);
					return false;
		}else if($("#add_speci").val() == ""){
					$(".mob-error").css("display","block");
					$(".mob-error").fadeIn();
					$(".mob-error").html("Enter Specification ");
					setTimeout(function(){
						$(".mob-error").fadeOut();
						$(".mob-error").css("display","none");
						$(".mob-error").html("");
						},5000);
					return false;
		}

		var spec_data = new FormData(this);
	

		$.ajax({
					url:"php/setting/php/add-spec-data.php",
					type:"POST",
					data : spec_data ,
					contentType:false,
					processData:false,
					success : function(data){
						/*console.log(data);*/
						if(data == 1){
								$("#spec-add-form").trigger("reset")
								loadspecdata();

							}else if(data == 2){
									$(".mob-error").css("display","block");
									$(".mob-error").fadeIn();
									$(".mob-error").html("Alredy Existed this Specification ");
									setTimeout(function(){
										$(".mob-error").fadeOut();
										$(".mob-error").css("display","none");
										$(".mob-error").html("");
						},5000);
					return false;
					}else{
							console.log(data);
						}

						
					}
				})

	});

	function loadspecdata(){
		$.ajax({
			url:"php/setting/php/loadspec.php",
			success:function(data){
				/*console.log(data);*/
				$("#speci_data_table_row").html(data);
			}
		})
	}
	loadspecdata();

	$(document).on("click","#spec-del-btn",function(l){
		l.preventDefault();

		var specdel = $(this).data("spdid");
		var specrow = $(this);
		
		/*alert(specdel);*/
			
			$.ajax({
					url:"php/setting/php/del-spec-data.php",
					type:"POST",
					data :{delspid:specdel},
					success : function(data){
						if(data == 1){
							$(specrow).closest("tr").fadeOut();
							loadspecdata();
						}
						

						
					}
				});
	})
	$("#spe-search-box").keyup(function(){

		var search_sp = $(this).val();

		$.ajax({
					url:"php/setting/php/search-sp-data.php",
					type:"POST",
					data : {search_sp : search_sp},
					success : function(data){
						/*console.log(data);*/
						$("#speci_data_table_row").html(data); 
						

						
					}
				})
	})


});