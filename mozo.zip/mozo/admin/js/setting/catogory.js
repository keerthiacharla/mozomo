$(document).ready(function(){
	/*alert("catogory.js22222");*/
	function loadcatdata(){
		$.ajax({
			url:"php/setting/php/loadcat.php",
			success:function(data){
				$("#category_table_row").append(data);
			}
		})
	}
	loadcatdata();	

	$(document).on("click","#cat-view",function(e){
		e.preventDefault();

		loadcatdata();	

	});

	$(document).on("click","#products_cat",function(e){
		e.preventDefault();

		loadcatdata();	

	});


	$("#cat-add-form").submit(function(y){
		y.preventDefault();
		
		var cat_name = new FormData(this);

		
		$.ajax({
					url:"php/setting/php/add-cat-data.php",
					type:"POST",
					data : cat_name ,
					contentType:false,
					processData:false,
					success : function(data){
						if(data == 1){
							$("#cat-add-form").trigger("reset");
							loadcatdata()
						}

						
					}
				})
	})

	

})