export 	function loaduser(){
			$.ajax({
					url:"php/setting/php/product-data.php",
							
					success : function(data){
						$("#productable_row").html(data);

						
					}
				})
		}
		
		export function slideloaduser(){
			$.ajax({
					url:"php/setting/php/slideproduct-data.php",
							
					success : function(data){
						$("#img_productable_row").html(data);

						
					}
				})
		}
		export function tvslideloaduser(){
			$.ajax({
					url:"php/setting/php/tvslideproduct-data.php",
							
					success : function(data){
						$("#tv_img_productable_row").html(data);

						
					}
				})
		}
		
	