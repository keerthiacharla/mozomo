$(document).ready(function(){
	/*alert("usersupdate-set aaaaa");*/


	


	$(document).on("click","#empl-update",function(j){
		j.preventDefault();


		var epid = $(this).data("emplup");
		var city = $(this).data("city");
		var city_num = $(this).data("cno");
		var empl_gen = $(this).data("gen");

			/*$("input:radio[name='uplog_gender']").click(function(){
				var check = $(this).val();
				alert(check+" "+ empl_gen);
			})*/
		

			if(empl_gen == "Male"){
				$("input:radio[id='male']").attr("checked",true);
				$("input:radio[id='female']").attr("checked",false);

				
			}else if(empl_gen == "Female"){
				$("input:radio[id='female']").attr("checked",true)
				$("input:radio[id='male']").attr("checked",false);
			}
		

		alert(epid);

		function loadupdatestate(uptype,upid){
				$.ajax({
						url:"php/setting/php/loadupdatestate.php",
						type:"POST",
						data:{uptype:uptype,upid:upid,id:epid},
						success:function(data){
							/*console.log(data);*/
							if(uptype == "upstatedata"){
								$("#uplog_city").html(data);
								
							}else{
								$("#uplog_state").html(data);
							}
						
						
								

							
						}
					})
	}
	loadupdatestate();

	$("#uplog_city").html("<option value='"+city_num+"'>"+city+"</option>");
	


	$("#uplog_state").change(function(){
		var idupval = $("#uplog_state").val();
		/*alert(idupval);*/
		loadupdatestate("upstatedata",idupval);
	});

		var empl_updatebtn = $(this).data("emplup");
		var empl_fname = $(this).data("fname");
		var empl_lname = $(this).data("lname");
		var empl_email = $(this).data("email");
		var empl_ph = $(this).data("ph");
		var empl_add = $(this).data("add");
		var empl_zip = $(this).data("zip");
		var empl_dign = $(this).data("dign");
		
			loadupdatestate();
			$("#uplog_id").val(empl_updatebtn);
			$("#uplog_fname").val(empl_fname);
			$("#uplog_lname").val(empl_lname);
			$("#uplog_email").val(empl_email);
			$("#uplog_phone").val(empl_ph);
			$("#uplog_add").val(empl_add);
			$("#uplog_zip").val(empl_zip);
			$("#uplog-dig").val(empl_dign);
			


		

		




	});

	$(document).on("submit","#userupdate-det-form",function(i){
		i.preventDefault();


		

			function updateuserdata(){
				$.ajax({
						url:"php/setting/php/updateuserdata.php",
						type:"POST",
						data:$("#userupdate-det-form").serialize(),
						success:function(data){
							/*console.log(data);*/
								if(data == 1){
									$("#empl-update-modal-box").modal("hide");
									 window.location.href ='http://localhost/mozo/admin/';
								}else{
									console.log(data);
								}

							
						
						
								

							
						}
					})
	}
	updateuserdata();
	})



});
