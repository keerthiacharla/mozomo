$(document).ready(function(){
	/*alert("speci-val aaa");*/

$("#secipro-seldata").on("change",function(){
			var spe_val = $(this).val();
			/*alert(spe_val);*/


	function loadsp(){
		$.ajax({
			url:"php/setting/php/spesel.php",
			type:"POST",
			data:{id:spe_val},
			success:function(data){
				/*console.log(data);*/
				$("#speci-seldata").html(data);
			}
		})
	}
	loadsp();
});

function inputspval(){
		$.ajax({
			url:"php/setting/php/inputspesel.php",
			
			success:function(data){
				/*console.log(data);*/
				$("#add_speci-intype").append(data);
			}
		})
	}
	inputspval();
	


function loadspval(){
		$.ajax({
			url:"php/setting/php/loadselval.php",
		
			success:function(data){
				/*console.log(data);*/
				$("#specival_data_table_row").html(data);
			}
		})
	}
	loadspval();


$("#spec-val-add-form").submit(function(rrr){
	rrr.preventDefault();
	if($(".secipro-seldata-val").val() == "select"){
					$(".mob-error").css("display","block");
					$(".mob-error").fadeIn();
					$(".mob-error").html("Select Brand ");
					setTimeout(function(){
						$(".mob-error").fadeOut();
						$(".mob-error").css("display","none");
						$(".mob-error").html("");
						},5000);
					return false;
		}else if($(".speci-seldata").val() == "select"){
					$(".mob-error").css("display","block");
					$(".mob-error").fadeIn();
					$(".mob-error").html("Select specification");
					setTimeout(function(){
						$(".mob-error").fadeOut();
						$(".mob-error").css("display","none");
						$(".mob-error").html("");
						},5000);
					return false;
		}else if($("#add_val_speci").val() == ""){
					$(".mob-error").css("display","block");
					$(".mob-error").fadeIn();
					$(".mob-error").html("Enter specification Value");
					setTimeout(function(){
						$(".mob-error").fadeOut();
						$(".mob-error").css("display","none");
						$(".mob-error").html("");
						},5000);
					return false;
		}

	var spval_name = new FormData(this);

		
		$.ajax({
					url:"php/setting/php/add-spval-data.php",
					type:"POST",
					data : spval_name ,
					contentType:false,
					processData:false,
					success : function(data){
						/*console.log(data);*/
						if(data == 1){
								$("#spec-val-add-form").trigger("reset")
								loadspval();
							}else if(data == 2){
									$(".mob-error").css("display","block");
									$(".mob-error").fadeIn();
									$(".mob-error").html("Alredy Existed this Specification Value ");
									setTimeout(function(){
										$(".mob-error").fadeOut();
										$(".mob-error").css("display","none");
										$(".mob-error").html("");
						},5000);
					return false;
					}else{
							console.log(data);
						}	

						
					}
				})
	})

$(document).on("click","#specval-del-btn",function(l){
		l.preventDefault();

		var spvaldel = $(this).data("spvaldid");
		var spcvalrow = $(this);
		
		/*alert(spvaldel);*/
			
			$.ajax({
					url:"php/setting/php/del-spcval-data.php",
					type:"POST",
					data :{spvaldelid:spvaldel},
					success : function(data){
						if(data == 1){
							$(spcvalrow).closest("tr").fadeOut();
							loadspval();
						}
						

						
					}
				});
	})

$("#spe-val-search-box").keyup(function(){

		var search_spval = $(this).val();

		$.ajax({
					url:"php/setting/php/search-sp-val-data.php",
					type:"POST",
					data : {search_spval : search_spval},
					success : function(data){
						/*console.log(data);*/
						$("#specival_data_table_row").html(data); 
						

						
					}
				})
	})

	


})