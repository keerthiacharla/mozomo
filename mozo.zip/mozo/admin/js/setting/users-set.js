

$(document).ready(function(){
	/*alert("users-set1111111");*/

$( "#datepicker" ).datepicker({
  		 dateFormat: "yy-mm-dd"
})

$( "#date-find" ).datepicker({
  		 dateFormat: "yy-mm-dd"

})


	function loadstatedatasel(type,id){
				$.ajax({
						url:"php/setting/php/loadstatedatasel.php",
						type:"POST",
						data:{type:type,id:id},
						success:function(data){
							if(type == "statedata"){
								$("#log_city").html(data);
								
							}else{
								$("#log_state").html(data);
							}
						
						
								

							
						}
					})
	}
	loadstatedatasel();





	$("#log_state").change(function(){
		var idval = $("#log_state").val();
		/*alert(idval);*/
		loadstatedatasel("statedata",idval);
	})

	function loademplbtn(){
			$.ajax({
                        url:"php/setting/php/loademplbtn.php",
                                               
                        success:function(data){
                        	$("#show-empl-btn").html(data)
                            
                        }

                    })

		}
		loademplbtn();

		
	



	$(document).on("submit","#user-det-form",function(e){
		e.preventDefault();
		/*alert("user-det-form");*/

		var log_fname = $("#log_fname").val();
		var log_lname = $("#log_lname").val();
		var log_gen = $(".log_gender");
		var log_email = $("#log_email").val();
		var log_phone = $("#log_phone").val();
		var log_add = $("#lod_add").val();
		var log_state = $("#log_state").val();
		var log_city = $("#log_city").val();
		var log_zip = $("#log_zip").val();
		var log_dig = $("#log-dig").val();
		
		var log_correct_email = /^[a-z]{3,}@[a-z]{3,}.[a-z]{2,}.([a-z]{2})?$/;
		

		if(log_fname == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter First Name  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(log_lname == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter Last Name  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if((log_gen).filter(":checked").length < 1){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Select Gender  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(log_email == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter Email ID  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(!log_correct_email.test(log_email)){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter correct Email ID ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(log_phone == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter Phone Number ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(log_phone.length < 9){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Phone Number is invalid  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(log_add == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter address  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(log_state == "select"){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Select State  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(log_city == "select"){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Select city  ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(log_zip == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter Pincode ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}else if(log_dig == ""){
			$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Enter Emploiyee Disignation ");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
				},5000);
					return false;
		}

		/*alert($(this).serialize());*/

		  		$.ajax({
                        url:"php/setting/php/empl-details.php",
                        type:"POST",
                        data:$("#user-det-form").serialize(),
                        success:function(data){
                        	/*console.log(data);*/

                        	if(data == "file is already exsist"){

                        		$(".mob-error").css("display","block");
								$(".mob-error").fadeIn();
								$(".mob-error").html("file is already exsist  ");
								setTimeout(function(){
									$(".mob-error").fadeOut();
									$(".mob-error").css("display","none");
									$(".mob-error").html("");
								},5000);
									return false;

                        	}else if(data == 1){
                        		$("#user-det-form").trigger("reset");
                        		$("#emlogin-add").modal("hide");
                        		loademplbtn();

                        	}else{
                        		console.log(data);

                        	}
                            
                        }

                    })
			})

		function loadempid(){
			$.ajax({
                        url:"php/setting/php/empl-selbox.php",
                        type:"POST",
                        data:$("#user-det-form").serialize(),
                        success:function(data){
                        	$("#empl_id").html(data);
                            
                        }

                    })
			
		}
		loadempid();

		function loadlogemp(){
			$.ajax({
                        url:"php/setting/php/loadlogemp.php",
                                               
                        success:function(data){
                        	$("#emlogin_row").html(data);
                            
                        } 

                    })

		}
		loadlogemp();

		$("#empl_id").change(function(){
			var emp_id = $(this).val();

			/*alert(emp_id);*/

			if(emp_id == "select"){
					/*alert("Ple")*/

				}else{
					$.ajax({
                        url:"php/setting/php/empl-emailotp.php",
                        type:"POST",
                        data:{id:emp_id},
                        success:function(data){
                        	$("#otp_email").html(data)
                            
                        }

                    })
				}
		})

		$(document).on("submit","#empsel_form",function(e){
			e.preventDefault();

			/*alert("s");*/

			var empid = $("#empl_id").val();
			/*alert(empid);*/

				
					$.ajax({
                        url:"php/setting/php/empl-getotp.php",
                        type:"POST",
                        data:{id:empid},
                        success:function(data){
                        	if(data == ""){
                        		$(".mob-error").css("display","block");
										$(".mob-error").fadeIn();
										$(".mob-error").html("This User Araady Existed ");
										setTimeout(function(){
											$(".mob-error").fadeOut();
											$(".mob-error").css("display","none");
											$(".mob-error").html("");
											},5000);
										return false;

                        	}else{
                        		 $("#singup_otp_form").css("display","block");
                        		$("#singup_otp_form").html(data);
                        		setInterval(updatetime,60000);
                        		loademplbtn();
                        		loadlogemp();
                        	}
                        	


                            
                        }

                    })


				
				/*var empid = $("#empl_id").val()

				if(empid == "select"){
					alert("Ple")

				}else{
					
				}*/
				var updatetime = function(){
					$.ajax({
						url:"php/setting/php/updattime.php",
						type:"POST",
						data:{id:empid},
						success:function(data){
							/*console.log(data);*/
							if(data == 1){
										$(".mob-error").css("display","block");
										$(".mob-error").fadeIn();
										$(".mob-error").html("Your OTP is Expired ");
										setTimeout(function(){
											$(".mob-error").fadeOut();
											$(".mob-error").css("display","none");
											$(".mob-error").html("");
											},5000);
										return false;
                        				

                        				


							}else{
								console.log(data);
							}
						
						
								

							
						}
					})

			}
			
});

		var update = function(){
				$("#sec").each(function(){
					var count = parseInt($(this).html());
					if(count !== 0){
						$("#otp-box").css("display","block");

						$(this).html(count - 1);
					}else{
						 $("#singup_otp_form").css("display","none");
						$("#otp_enter").val();



						
					}
				});
				}
				setInterval(update,1000);

		$(document).on("click","#user_submit",function(i){
			i.preventDefault();
			
			 var id = $(this).data("id");
			 var email =$("#add_user_emaliid").val();
			 var value =$("#add_user_otp").val();
		/*	 alert(id+" "+ email+" "+ value);*/





					 $.ajax({
                        url:"php/setting/php/empl-user.php",
                        type:"POST",
                        data:{id:id,val:value,email:email},
                        success:function(data){
                        	if(data == 1){
                        		$("#signup-form").modal("hide");
                        		clearInterval(update);

                        	}
                            
                        }

                    })

			 /**/

			 
		})
		
		
		$(document).on("click","#empl-brn",function(a){
			a.preventDefault();

			var emplid = $(this).data("empl");

			/*alert(emplid);*/

			$.ajax({
                        url:"php/setting/php/loademplreset.php",
                        method:"POST",
                        data :{id:emplid},
                                               
                        success:function(data){
                        	$("#show-empl-table").html(data)
                            
                        }

                    })

		})

		
	

		



		$(document).on("click","#change-role",function(j){
			j.preventDefault();

			var id = $(this).data("id");

			/*alert(id);*/

		function loadrolesel(){
			$.ajax({
                        url:"php/setting/php/loadrolesel.php",
                        method:"POST",
                        data :{id:id},
                                               
                        success:function(data){
                        	/*console.log(data);*/
                        	$("#change-role-sel").html(data);
                        	loadlogemp();
                            
                        } 

                    })

		}
		loadrolesel();


		$("#change-role-sel").change(function(e){
			e.preventDefault();

			var val = $(this).val();
			

			/*alert(id + " "+ val);*/

;

			if(val == 0){
				/*alert("Normal");*/

					$.ajax({
                        url:"php/setting/php/noruser.php",
                        method:"POST",
                        data :{id:id, val: val},
                                               
                        success:function(data){
                        	/*console.log(data);*/
                        	if(data == 1){
                        		$("#change_user").modal("hide");
                        		loadlogemp();
                        	}
                            
                        } 

                    })

				

			}else if(val == 1){
			/*	alert("admin" +" "+ id);*/

				$.ajax({
                        url:"php/setting/php/admiuser.php",
                        method:"POST",
                        data :{id:id, val: val},
                                               
                        success:function(data){
                        	/*console.log(data);*/
                        	if(data == 1){
                        		$("#change_user").modal("hide");
                        		loadlogemp();
                        	}
                            
                        } 

                    })


			}
		})
		})

		$(document).on("click","#rpass-user",function(j){
			j.preventDefault();

			var pid = $(this).data("pid");

			/*alert(pid);*/

			$.ajax({
                        url:"php/setting/php/resetpass.php",
                        method:"POST",
                        data :{pid:pid},
                                               
                        success:function(data){
                        	/*console.log(data);*/
                        	if(data == 1){
                        		alert("Your Password is Change!")
                        	}
                            
                        } 

                    })


		})


		$(document).on("click","#del-user",function(j){
			j.preventDefault();

			var did = $(this).data("did");
			var dso = $(this).data("dso");

			/*alert(did + " "+ dso);*/
					$.ajax({
                        url:"php/setting/php/del-user.php",
                        method:"POST",
                        data :{did:did , dso:dso},
                                               
                        success:function(data){
                        	/*console.log(data);*/
                        	if(data == 1){
                        		$(dso).closest("tr").fadeOut();   
                        		loadlogemp();                     	}
                            
                        } 

                    })





		}) 

		$("#emldel-val-search-box").keyup(function(){
 
                    	var search_key = $(this).val();

                    	/*alert(key);*/

                    		$.ajax({
								url:"php/setting/php/search-user_details.php",
								type:"POST",
								data : {search_key : search_key},
								success : function(data){
									/*console.log(data);*/
									$("#show-empl-btn").html(data)
									$("#show-empl-table").html("");
									
									

									
								}
							})
                    })

		$("#emlpmob--search-box").keyup(function(){

                    	var search_emp = $(this).val();

                    /*	alert(search_emp);*/

                    		$.ajax({
								url:"php/setting/php/search_emp_details.php",
								type:"POST",
								data : {search_emp : search_emp},
								success : function(data){
									/*console.log(data);*/
									$("#emlogin_row").html(data);
									
									

									
								}
							})
                    })


		$( "#search_date" ).click(function(e){
			e.preventDefault();
			var val = $("#date-find").val();

				$.ajax({
								url:"php/setting/php/search_emp_date.php",
								type:"POST",
								data : {search_val : val},
								success : function(data){
									/*console.log(data);*/
									$("#show-empl-btn").html(data)
									$("#show-empl-table").html("");
									
									

									
								}
							})
                  

			
		})

		$(document).on("click","#empl-print",function(e){
			e.preventDefault();

			var prno = $(this).data("prno");

			window.location.href ="php/setting/php/print-emp-del.php?id="+prno;


		})
 
})