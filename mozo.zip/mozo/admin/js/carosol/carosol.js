$(document).ready(function(){
	/*alert("caro-sub keert");*/

	


	/*button fetch*/

	function loadmobbtn(){
		$.ajax({
			url:"php/carosol/php/caro-tabledata.php",
			success:function(data){
				$("#caro-tabload").append(data);

			}
		})
	}
	loadmobbtn();



	$("#carosol-form").submit(function(t){
		t.preventDefault();
		
		
		var caroform = new FormData(this);

		/*console.log(caroform);*/




		$.ajax({
			url:"php/carosol/php/add-caro-data.php",
			type:"POST",
			data : caroform,
			contentType:false,
			processData:false,
			success:function(data){
				/*console.log(data);*/
				if(data == 1){
						$("#caro-tabload").html(data);
						$("#carosol-form").trigger("reset");
						loadmobbtn();
				}else{
					console.log(data);
				}
			}
		});
	});


	$(document).on("click","#truecate",function(){
		/*alert("truecate");*/
		$.ajax({
			url:"php/carosol/php/caro-trucate.php",
			success:function(data){
				if(data == 1){
					alert("Deleted Sucessfully")
				}else{
					console.log(data);
				}
			}
		})
	
	})
})



