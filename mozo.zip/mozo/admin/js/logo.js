$(document).ready(function(){
/*	alert("logo.js");*/




		$("#logo-main-add-form").submit(function(a){
			a.preventDefault();

					var main_logo = new FormData(this);

					console.log(main_logo);

							$.ajax({
										url:"infile/add-main-logo.php",
										type:"POST",
										data : main_logo ,
										contentType:false,
										processData:false,
										success : function(data){
											/*console.log(data);*/
											if(data == 1){
												$("#product-logo-form").trigger("reset");
												loadlogo();
											}else if(data == 2){
													$(".mob-error").css("display","block");
													$(".mob-error").fadeIn();
													$(".mob-error").html("Alredy Existed this Logo ");
													setTimeout(function(){
														$(".mob-error").fadeOut();
														$(".mob-error").css("display","none");
														$(".mob-error").html("");

													},5000);
														return false;
												}else if(data == 3){
													$(".mob-error").css("display","block");
													$(".mob-error").fadeIn();
													$(".mob-error").html("File is not support.. please uploade jpg ,jpeg ");
													setTimeout(function(){
														$(".mob-error").fadeOut();
														$(".mob-error").css("display","none");
														$(".mob-error").html("");

													},5000);
													console.log(data)
														return false;
												}
											
									

											
										}
									})

	})
})