$(document).ready(function(){
	alert("returnpay.js aaaaaaaa");

	function returnpay_btn(){
				$.ajax({
						url:"php/payment/php/returnpaybyn.php",
						
						success:function(data){
							/*console.log(data);*/
							$("#cos-redet-btn").html(data);
						
						
						
								

							
						}
					})
	}
	returnpay_btn();

	function re_paytable(re_tabtid){
					$.ajax({
						url:"php/payment/php/return-paytable.php",
						type:"POST",
						data: {id:re_tabtid},
						
						success:function(data){
							console.log(data);
							$("#cos-redet-table").html(data);
						
						
						
								

							
						}
						})
				}
				

			function reproselector(retid){
				$.ajax({
						url:"php/payment/php/return-proselector.php",
						type:"POST",
						data: {id:retid},
												
						success:function(data){
							console.log(data);
							$("#rechange-status-sel").html(data);
						
						
						
								

							
						}
					})
	}
	

	


	$(document).on("click","#return-cos-del-btn",function(){

		var retid = $(this).data("returnpayid");

		alert(retid);

		
	re_paytable(retid);
	reproselector(retid);



			})

	$(document).on("click","#cos-agent",function(){

		var retcity = $(this).data("city");
		var retsno = $(this).data("sno");

		alert(retcity+" "+ retsno);

				$.ajax({
						url:"php/payment/php/return-fetch-agent.php",
						type:"POST",
						data: {id:retcity},
						
						success:function(data){
							console.log(data);
							$("#reagent-sel").html(data);
						
						
						
								

							
						}
						})

				$("#reagent_id").val(retsno);
			

		
			})

	$(document).on("change","#reagent-sel",function(e){
		e.preventDefault();
		var agent = $("#reagent-sel").val();


				if(agent |= "select"){
					$.ajax({
						url:"php/payment/php/fetvh-agent-del.php",
						type:"POST",
						data: {val:agent},
						
						success:function(data){												
								console.log(data);
								$(".regent-info").html(data);
							
								}
							})
					$(document).on("click","#reagent-btn",function(e){
							e.preventDefault();
							var cos_id = $("#reagent_id").val();
							var ragent_name = $("#agent_name").val();
							var ragent_no = $("#agent_no").val();

							alert(cos_id+" "+ ragent_name +" "+ragent_no);

							$.ajax({
											url:"php/payment/php/return_agent-status.php",
											type:"POST",
											data: {id:cos_id,name:ragent_name,ph:ragent_no},
											
											success:function(data){

												if(data == 1){ 
													
													$("#agent_return_deli").modal("hide");
													re_paytable(cos_id);
													reproselector(cos_id);

												}else{
													console.log(data);
												}
											
											}


											})
							/**/

							

									})

						}else{


						}

		

				})
$(document).on("click","#recos-upsta",function(e){
	 var sno = $(this).data("upsta");


	 alert(sno)


				swal({
						  title: "Are you sure you want sattle the Payment?",
						
						  icon: "warning",
						  buttons: true,
						  dangerMode: true,
						})
						.then((willDelete) => {

							
							
							
						  if (willDelete) {
						    swal("Poof! Payment has sattled !", {
						      icon: "success",

						    });
						    $.ajax({
										url:"php/payment/php/return_success-status.php",
										type:"POST",
										data: {id:sno},
										
										success:function(data){
											/*console.log(data);*/
											if(data == 1){

												$("#rechange_status").modal("hide");
												returnpay_btn();
												re_paytable(sno);

											}else{
												console.log(data);
											}
										
										}
										})

						     
						    	
						  } else {
						    swal("Payment is not been sattled !");
						    return false;
						  }
						});
	
				alert("Item Receid Sucessluly ")

								
					
			})

	$(document).on("click","#recos-otp",function(e){
		e.preventDefault();

		var id = $(this).data("uotp");

		$("#re-enterotp-id").val(id);
	})


	$(document).on("click","#reenter-otp-sta",function(e){
		e.preventDefault();

		var val = $("#re-enterotp-id").val();
		var reotp = $("#re-enterotp").val();

		if(reotp == ""){
				$(".mob-error").css("display","block");
				$(".mob-error").fadeIn();
				$(".mob-error").html("Please enter delivary OTP");
				setTimeout(function(){
					$(".mob-error").fadeOut();
					$(".mob-error").css("display","none");
					$(".mob-error").html("");
					},5000);
				return false;
				
		}

		/*alert(val+" "+ reotp +"aaaa");*/


								$.ajax({
										url:"php/payment/php/return_receive_agent.php",
										type:"POST",
										data: {id:val,otp:reotp},
										
										success:function(data){
											console.log(data);
											if(data == 1){

												$("#retotp_otp").modal("hide");
												re_paytable(val);

											}else if(data == 2){
												if(reotp == ""){
													$(".mob-error").css("display","block");
													$(".mob-error").fadeIn();
													$(".mob-error").html("OTP is not matched ");
													setTimeout(function(){
														$(".mob-error").fadeOut();
														$(".mob-error").css("display","none");
														$(".mob-error").html("");
														},5000);
													return false;
													
											}
											}else{
												/*console.log(data);*/
											}
										
										}
										})
	})

	function returnrepay_btn(){
				$.ajax({
						url:"php/payment/php/returnrepay_btn.php",
						
						success:function(data){
							/*console.log(data);*/
							$("#allrecos-det-btn").html(data);
						
						
						
								

							
						}
					})
	}
	returnrepay_btn();


	$(document).on("click","#allrecos-del-btn",function(){

		var returnid = $(this).data("allretid");

		alert(returnid);

		

					$.ajax({
						url:"php/payment/php/return-allpaytable.php",
						type:"POST",
						data: {id:returnid},
						
						success:function(data){
							console.log(data);
							$("#allrecos-det-table").html(data);
						
						
						
								

							
						}
					})
			})

})