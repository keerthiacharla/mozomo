$(document).ready(function(){
	/*alert("pay.js aaaaaa ");*/
	

	  $("#enterotp").keypress(function(evt){
            var ch = String.fromCharCode(evt.which);
                if((/[a-zA-Z/!/@/#/$/%/^/&/*/(/)/_/-/+/=/{/[/?/}/:/;/""/''/</,/>/./// ]/.test(ch))){
                    evt.preventDefault();
                    }
            });

	function pay_btn(){
		$.ajax({
						url:"php/payment/php/paybyn.php",
						
						success:function(data){
							/*console.log(data);*/
							$("#cos-det-btn").html(data);
						
						
						
								

							
						}
					})
	}
	pay_btn();

	function proselector(payid){
				$.ajax({
						url:"php/payment/php/proselector.php",
						type:"POST",
						data: {id:payid},
												
						success:function(data){
							/*console.log(data);*/
							$("#change-status-sel").html(data);
						
						
						
								

							
						}
					})
	}
	proselector();

	function paytable_show(pay_btn){
			
			$.ajax({
						url:"php/payment/php/paytable.php",
						type:"POST",
						data: {id:pay_btn},
						
						success:function(data){
						/*	console.log(data);*/
							$("#cos-det-table").html(data);
						
							}
						})
					}
				function status_updatesel(){

				$.ajax({
						url:"php/payment/php/addupdatesel-status.php",
									
						success:function(data){
							$("#up-status-id").html(data);
							
							/*if(data ==  1){
								
								$("#deli_change_status").modal("hide");
								$("#up-sta-form").trigger("reset");
							}else{
								
								console.log(data)
							}*/
						
						
						
								

							
							}
						})

			}
			status_updatesel();




	$(document).on("click","#cos-del-brn",function(){

		var id = $(this).data("payid");

		proselector(id);
		paytable_show(id);

	})

			function loadpaystatus(){
				$.ajax({
						url:"php/payment/php/loadpaystatus.php",
						success:function(data){
							/*console.log(data);*/
							$("#cos-det-st-table").html(data);
						
								}
							});

						}
						loadpaystatus();

	$(document).on("click","#cos-upsta",function(e){
		e.preventDefault();

		var upsta = $(this).data("upsta");
		var upuser = $(this).data("user");

		/*alert(upsta + " " + upuser);*/

							function agent_fetch(){
										$.ajax({
											url:"php/payment/php/fetvh-agent.php",
											type:"POST",
											data: {sno:upuser},
											
											success:function(data){												
													$("#agent-sel").html(data);
												
												}
											})

									}
								agent_fetch();	

				$("#agent-sel").change(function(){
						var agent_val = $(this).val();

									$.ajax({
											url:"php/payment/php/fetvh-agent-del.php",
											type:"POST",
											data: {val:agent_val},
											
											success:function(data){												
													console.log(data);
													$(".gent-info").html(data);
												
												}

											})

										})


			


			$("#change-status-sel").on("change",function(){
				var val = $(this).val();

				/*alert(val); */

				if(val == 2){
					$.ajax({
							url:"php/payment/php/processing-status.php",
							type:"POST",
							data: {id:upsta,val:val},
							success:function(data){
								if(data == 1){
									$("#change_status").modal("hide");
									paytable_show(upsta);
									loadpaystatus();
									status_updatesel();
									proselector(upsta);

								}else{
									console.log(data);
								}
							}
						})
			}else if(val == 3){
				$("#return_appli").modal("show");

				$("#agent_deli").modal("show");
							

							$(document).on("click","#agent-btn",function(i){
								i.preventDefault();

								var agent_name = $("#agent_name").val();
								var agent_no = $("#agent_no").val();


								if(agent_name == "select"){
										$(".mob-error").css("display","block");
										$(".mob-error").fadeIn();
										$(".mob-error").html("Select Agent Name of Costomer Area ");
										setTimeout(function(){
											$(".mob-error").fadeOut();
											$(".mob-error").css("display","none");
											$(".mob-error").html("");
											},5000);
										return false;
									}

								$.ajax({
											url:"php/payment/php/agent-status.php",
											type:"POST",
											data: {id:upsta,name:agent_name,ph:agent_no},
											
											success:function(data){
												if(data == 1){
													$("#change_status").modal("hide");
													/*$("#return_appli").modal("hide");*/
													$("#agent_deli").modal("hide");

												}else{
													console.log(data);
												}
											
											}


											})
							})
							

				 $(document).on("click","#re-app-btn",function(){

				 	var ret = $("#ret-dat").val();
				 	swal({
						  title: "Are you sure OTP should Send to costomer?",
						  text: "Are you Sure ..Weather Delivary have been reach to Desination  !",
						  icon: "warning",
						  buttons: true,
						  dangerMode: true,
						})
						.then((willDelete) => {

							
							
							
						  if (willDelete) {
						    swal("Poof! OTP is Sended To Costomer !", {
						      icon: "success",
						    });

						   			 $.ajax({
											url:"php/payment/php/success-status.php",
											type:"POST",
											data: {id:upsta,val:val,ret:ret},
											
											success:function(data){
												if(data == 1){
													$("#change_status").modal("hide");
													$("#return_appli").modal("hide");
													paytable_show(upsta);
													loadpaystatus();

												}else{
													console.log(data);
												}
											
											}


											})

						     
						    	
						  } else {
						    swal("Your OTP is nat been Sended !");
						  }
						});
				 })




			/*	*/
				 
			}
		});



	})

	

/*
			$(document).on("click","#cos-cust-up-btn",function(e){
				e.preventDefault()

				var st_id = $(this).data("stup");

				alert(st_id);

				$("#up-status-id").val(st_id);
			})*/


			

			$(document).on("click","#up-st-btn",function(a){
				a.preventDefault();

				var st_id = $("#up-status-id").val();
				var st_text = $("#up-status").val();

				/*alert(st_id +" "+st_text);*/

				$.ajax({
						url:"php/payment/php/addupdate-status.php",
						type:"POST",
						data: {id:st_id,val:st_text},
						
						success:function(data){
							if(data ==  1){
								loadpaystatus();
								$("#deli_change_status").modal("hide");
								$("#up-sta-form").trigger("reset");
							}else{
								console.log(data)
							}
						
						
						
								

							
							}
						})

				
			})

			$(document).on("click","#ins-otp",function(e){
				e.preventDefault()

				var st_oid = $(this).data("intotp");

				alert(st_oid);

				$("#enterotp-id").val(st_oid);
			})


			$(document).on("submit","#emter-otp-form",function(g){
				g.preventDefault();

				var st_oid = $("#enterotp-id").val();
				var st_otext = $("#enterotp").val();

				alert(st_oid +" "+st_otext);

				$.ajax({
						url:"php/payment/php/otp-status.php",
						type:"POST",
						data: {id:st_oid,val:st_otext},
						
						success:function(data){
							
							if(data == 1){
								$("#insert_otp").modal("hide");

							}else{
								$(".mob-error").css("display","block");
								$(".mob-error").fadeIn();
								$(".mob-error").html("Costomers OTP is Invalid ");
								setTimeout(function(){
									$(".mob-error").fadeOut();
									$(".mob-error").css("display","none");
									$(".mob-error").html("");
									},5000);
								return false;
								console.log(data);
							}
						
						
						
								

							
								}
							})
						})

			/*all Payments */

				function allpay_btn(){
				$.ajax({
						url:"php/payment/php/allpaybyn.php",
						
						success:function(data){
							/*console.log(data);*/
							$("#allcos-det-btn").html(data);
						
						
						
								

							
						}
					})
	}
	allpay_btn();

	$(document).on("click","#allcos-del-brn",function(){

		var allid = $(this).data("allpayid");

		alert(allid);



					$.ajax({
						url:"php/payment/php/allpaytable.php",
						type:"POST",
						data: {id:allid},
						
						success:function(data){
							/*console.log(data);*/
							$("#allcos-det-table").html(data);
						
						
						
								

							
						}
						})



	})
			




})