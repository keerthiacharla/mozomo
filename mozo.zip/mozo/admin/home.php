<?php 
	session_start();
	if(!isset($_SESSION["name"])){
		header ("Location:http://localhost/mozo/admin/");
		
	}




 ?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>MOZOMO-admin</title>
	<link rel="stylesheet" href="infile/bootstrap/bootstrap4.css">
	 <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
	
	<script src="js/jquery.js?v=2"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>  
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">


	<link rel="stylesheet" href="css/home.css?v=111111">
  
 

</head>
<body>
	<div class="containar-fluid">
		<button class="btn " id="show"><i class="fa-solid fa-bars"></i></button>
	<div class="row d-flex" id="row_con">
		<div class=" col-lg-3 col-md-3 col-sm-12 menu-bar" id="menu-bar">
			<div class="blog-del">
				<div class="blog-title ">
					<h1 class="text-sm-center"><img src="infile/logo.gif" alt="" class="img-fluid "></h1>
				</div>
				<div class="empl-pics col-md-12 justify-self-center d-block m-auto">
					
				</div>
				<div class="empl-del col-md-12 justify-content-center m-2">
					

				</div>
			</div>
			<?php include "php/index/modal/img-upload.php" ?>


			<!-- menu -->

			


				
			<div class="col-md-4 " id="menu-option ">
				<nav class="navbar">
    			  <div class="" id="">
				    <ul class="navbar-nav mr-auto">
				       
					       <li class="nav-item menu" id="product">
					       	 <a class="nav-link " href="#">Products</a>
					      </li>
				      
				    
				      <li class="nav-item dropdown menu">
				        <a class="nav-link dropdown-toggle" href="#" id="pay-menu" data-toggle="dropdown" > Payment & Delivary </a>
				        <div class="dropdown-menu sub">
				          <a class="dropdown-item" href="#" id="pay-opp">Recent Order</a>
				          <a class="dropdown-item" href="#" id="all-orders">Order History</a>
				          <a class="dropdown-item" href="#" id="cos-mass">Massages </a>
				         
				        </div>
				      </li>

				      <?php 

				      	if($_SESSION["role"] == 1){
								
						
				       ?>
				      <li class="nav-item dropdown menu" >
					        <a class="nav-link dropdown-toggle" href="#"  data-toggle="dropdown" id="setting" > Settings </a>
					        <div class="dropdown-menu sub">
						          <a  class="dropdown-item text-blue" href="#" id="products_cat">Products implement Setting</a>
						          <a class="dropdown-item text-blue" href="#" id="products_data">Product Opporations  </a>
						          <a class="dropdown-item text-blue" href="#" id="user_data">User Opporations  </a>
						         <a  class="dropdown-item text-blue" href="#" id="carosol">Carosol  Setting</a>
						         <a  class="dropdown-item text-blue" href="#" id="delivery">Delivary Agents </a>
						         <a  class="dropdown-item text-blue" href="#" id="zon">Zons </a>
				 			</div>
				      </li>	
					        

				      <?php 
				      	}

				       ?>
				     
				    
				    </ul>
				    
				  </div>
				</nav>


			</div>
		</div>
			
			
	

		<div class="col section  justify-content-center p-2">

			

			<div class="product">
				<?php include "php/product/product_container.php"?>
					
			</div>
			<div class="pay_con">
				<?php include "php/payment/pay_container.php"?>
				
			</div>
			<div class="allpay_con">
				<?php include "php/payment/allpay_container.php"?>
				
			</div>
			<div class="mass_con">
				<?php include "php/mass/mass-container.php"?>
				
			</div>
			
			<div class="set">
				<?php include "php/setting/cat_container.php"?>
				
			</div>
			<div class="pro-set-con">
				<?php include "php/setting/pro_container.php"?>
				
			</div>
			<div class="user-set-con">
				<?php include "php/setting/user_container.php"?>
				
			</div>
			<div class="carosol_container ">
				
				<?php include "php/carosol/carosol_container.php"?>
			</div>
			<div class="del_container ">
				
				<?php include "php/delivary/deli_container.php"?>
			</div>
			<div class="del_container ">
				
				<?php include "php/zone/zone_container.php"?>
			</div>

	
		</div>
		



	</div>
	</div>

	
	<script src="js/menuopp.js?v=11"></script>
	<script src="js/index/home.js?v=1111"></script>
	<script type="module" src="./js/product/product-impliment.js"></script>
	<script type="module" src="./js/product/product-modification.js"></script>
	<script src="js/carosol/carosol.js?v=11"></script>
	<script src="js/setting/catogory.js?v=11"></script>
	<script src="js/setting/product.js?v=11"></script>
	<script src="js/setting/speci.js?1111"></script>
	<script src="js/setting/speci-val.js"></script>
	<script type="module" src="./js/setting/pro-item.js?v=1"></script>
	<script src="js/setting/pro-logo.js"></script>
	<script src="js/setting/users-set.js"></script>
	<script src="js/setting/user_update.js"></script>
	<script src="js/setting/state.js"></script>
	<script src="js/setting/deli.js"></script>
	<script src="js/index/signup.js?v=111111"></script>
	<script src="js/zone/zone.js?v=11"></script>
	<script src="js/pay/pay.js?v=1111"></script>
	<script src="js/mass/mass.js?v=1"></script>
	<script src="js/pay/returnpay.js?v=11"></script>
	<script src="js/logo.js?v=111111"></script>
</body>
</html>