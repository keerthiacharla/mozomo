<?php 
	session_start();
	if(isset($_SESSION["name"])){
		header ("Location:http://localhost/mozo/admin/home.php");
		
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Mozomo-Login Page</title>
	<link rel="stylesheet" href="infile/bootstrap/bootstrap4.css">
	<script src="js/jquery.js"></script>
	<link rel="stylesheet" href="css/index.css?v=11">
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

	
</head>
<body>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 " id="signin-form_con">
				<div class="col-md-4 m-auto " id="signin-form">
					<div class="header">
						<h1 class="text-sm-center"><img src="infile/logo.gif" alt=""></h1>
					</div>
					
						<center class="m-3">ADMIN LOGIN</center>
						<span class="text-red m-2" id="log_error"> Lorem, ipsum.</span>

							<div class="form-group">
										<label for="">Select Role</label>
											<select name="index_role" id="index_role" class="custom_selectbox">
												<option value="select">Select User</option>
												<option value="0">Normal</option>
												<option value="1">Admin</option>
											</select>
									</div>


				<form action="" class="form_input mt-3 p-3" id="moruser_input" >
						<div class="form-group ">
							<label for="">USERNAME</label>
							<div class="input-group">
									<div class="input-group-prend">
										<span class="input-group-text"><i class="fa-solid fa-users"></i></span>
									</div>
								<input type="text" class="form-control" id="moruser_us_name" name="moruser_us_name" placeholder="Enter Your Username ">
								
							</div>
						</div>
						<div class="form-group mt-3">
							<label for="">PASSWORD</label>
							
								<div class="input-group">
									<div class="input-group-prend">
										<span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
									</div>
									<input type="password" class="form-control" id="moruser_us_pass" name="moruser_us_pass" placeholder="Enter Your password ">
									<div class="input-group-append">
										<span id="moruser_icon" class="input-group-text"><i class="fa-solid fa-eye" id="moruser_show_icon"></i></span>
									</div>
								</div>
							
						</div>
						<button class="btn btn-primary m-3"id="moruser_sign-in" name="moruser_sign-in">LOG IN</button>

						
					</form>





					<form action="" class="form_input mt-3 p-3" id="form_input" >
						<div class="form-group ">
							<label for="">USERNAME</label>
							<div class="input-group">
									<div class="input-group-prend">
										<span class="input-group-text"><i class="fa-solid fa-users"></i></span>
									</div>
								<input type="text" class="form-control" id="us_name" name="us_name" placeholder="Enter Your Username " readonly>
								
							</div>
						</div>
						<div class="form-group mt-3">
							<label for="">PASSWORD</label>
							
								<div class="input-group">
									<div class="input-group-prend">
										<span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
									</div>
									<input type="password" class="form-control" id="us_pass" name="us_pass" placeholder="Enter Your password ">
									<div class="input-group-append">
										<span id="icon" class="input-group-text"><i class="fa-solid fa-eye" id="show_icon"></i></span>
									</div>
								</div>
							
						</div>
						<button class="btn btn-primary m-3"id="sign-in" name="sign-in">LOG IN</button>

						
					</form>

					

				</div>
			</div>
		</div>
	</div>
	<?php include "php/index/modal/admin-modal.php" ?>
	<?php include "php/index/modal/log-reset.php" ?>


<script src="js/index/index.js?v=11"></script>
<script src="js/index/signup.js?v=11"></script>
	
</body>
</html>