<div class="owl-carousel owl-theme">
				  <?php


					include "admin/infile/config.php";


						
						$sql = "SELECT * FROM mobile WHERE dis_mode = 1 ";

						$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

						if(mysqli_num_rows($res) > 0){

							

							while($row = mysqli_fetch_assoc($res)){
								?>
					<div class="item  m-3">
				    	<div class='col-md-12  d-flex flex-md-column p-3 m-3' id='item_flex-item' > 
																				
							<div id='item-flex-img' class="m-auto">
								<a href="#"><img src="admin/php/product/php/Mobile-images/<?php echo $row['file'] ?>" alt=''></a>
							</div>
							<div id='item-brand d-sm-none'>
								<h3 class=""><center><?php echo $row['ml_name'] ?></center></h3>
								
							</div>
						</div> 
				   		 
					</div>
						 <?php

							}
						}
						$sql2 = "SELECT * FROM television WHERE dis_mode = 1 ";

						$res2 = mysqli_query($conn,$sql2) or die("offerheader.php query failed");

						if(mysqli_num_rows($res2) > 0){

							

							while($row2 = mysqli_fetch_assoc($res2)){
								?>
					<div class="item  m-3">
				    	<div class='col-md-12  d-flex  flex-md-column  p-3 m-3' id='item_flex-item' > 
																				
							<div id='item-flex-img' class="m-auto">
								<a href="#"><img src="admin/php/product/php/tv-images/<?php echo $row2['file'] ?>" alt=''></a>
							</div>
							<div id='item-brand d-sm-none '>
								<h3 class=""><center><?php echo $row2['ml_name'] ?></center></h3>
								
							</div>
						</div> 
				   		 
					</div>
					 <?php

					}
				}
								?>
				<!--     <div class="item"><h4>3</h4></div>
				    <div class="item"><h4>4</h4></div>
				    <div class="item"><h4>5</h4></div>
				    <div class="item"><h4>6</h4></div> -->
				   
				</div>