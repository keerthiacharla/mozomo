<?php 


	include "../../admin/infile/config.php";

	 $id = $_POST['id'];
	/* echo "php";*/
				
						
				
			$sql = "SELECT * FROM roz WHERE ord = '{$id}' ";

				$res = mysqli_query($conn,$sql) or die(" query failed first");

				if(mysqli_num_rows($res)){

					
					while($row = mysqli_fetch_assoc($res)){
						$sno = $row['cos_no'];
						$ord = $row['ord'];
						$today = date("d-m-Y");
						
						$date = date_create($today);
						echo  "<br>";

						$delivary = $row['deli_date'];
						
						
						$del_date = date_create($delivary);
					     
					    $ret_differ = date_diff($date,$del_date);

					     
						$inter = $row['deli_ret'];
						 $no_days = $ret_differ->days;

						 $day_left =  date("d-m-Y", strtotime($delivary."+".$inter." days"));						


					if($inter <= $no_days){
						$sql2 = "UPDATE roz SET deli_ret = '' WHERE ord = '{$id}' ";
						if(mysqli_query($conn,$sql2)){
							echo "";
						}else{
							echo die("Update query falied");
						}


					}else{
						echo "<p><b>Product should return by {$day_left}:-</b> 
									<span><button class='btn btn-primary' data-toggle='modal' data-target='#ret-opp' id='return-pro' data-ret='{$sno}' data-ord='{$ord}'> Return </button></span> 
								</p>";
					}

						

					}
				
				}

 ?>