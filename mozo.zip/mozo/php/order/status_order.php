<?php 


	include "../../admin/infile/config.php";

	 $id = $_POST['id'];
	/* echo "php";*/
				
			$sql = "SELECT * FROM roz WHERE ord = '{$id}' ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						if($row['status'] == 'Suceess' || $row['status'] == 'Returned'){

							echo "<div class='st-circle stat-opp'><i class='fa fa-check status-icon firt-status' style='background: green;' id='tick'></i><span class='ml-2'>{$row['status']} on {$row['dat']}</span></div> <br>

								<div class='status-bor firt-status' style='background: green;'></div>";

						}else{
							echo 0 ;
						}

						
					}

					
				}else{ 
					echo "No login";
				}


 ?>