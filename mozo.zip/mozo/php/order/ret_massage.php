<?php 

include "../../admin/infile/config.php";


		$cname = $_POST['id'];
		$ord = $_POST['ord'];
		$opp = $_POST['opp'];
		$mass = $_POST['mass'];
		$masstype = "Product Returned";
		$date = date("d-m-Y");
		$status = "Unread";
		
		

		
		/*$arr = array(
					"cname" => $cname,
					"opp" => $opp,
					
					"mass" => $mass,
					"masstype" => $masstype,
					
					"date" => $date,
					"status" => $status
				);
				echo "<pre>";
					print_r($arr);
				echo "</pre>";*/

		$sql = "SELECT * FROM cos_mass WHERE ord_id ='{$ord}'";
		$res = mysqli_query($conn,$sql) or die(mysqli_error($conn));

			if(mysqli_num_rows($res) > 0){
			
					echo 2;
					die;

				
			
			}else{
				$sql2 = "INSERT INTO cos_mass(cname,ord_id,mass_opp,massage,mass_type,mass_date,mass_status)  VALUES({$cname},'{$ord}','{$opp}','{$mass}','{$masstype}','{$date}','{$status}')";
						if(mysqli_query($conn,$sql2)){
							$sql3 = "UPDATE roz SET status = 'Returned', procss = 0, deli_name = '',deli_ph='',ord_status='Returned', deli_date='',deli_ret='' WHERE ord ='{$ord}'";
							if(mysqli_query($conn,$sql3)){
								echo 1;
								}else{
									echo die(mysqli_error($conn));
							

							}
						}else{
							echo die(mysqli_error($conn));
			

			}
		}
		




 ?>