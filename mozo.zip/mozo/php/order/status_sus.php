<?php 


	include "../../admin/infile/config.php";

	 $id = $_POST['id'];
	/* echo "php";*/
				
			$sql = "SELECT * FROM roz WHERE ord = '{$id}' ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){


					while($row = mysqli_fetch_assoc($res)){

					if($row['ord_status'] == 'Payment Sattled Successfully'){
						$sus_massage = "Amount sattled sucessfully to orginal payment mode on";
					}else{
						$sus_massage = "Delvaried to given address On";
					}

						if($row['ord_status'] == 'Delivared Sucessfully' || $row['ord_status'] == 'Payment Sattled Successfully'){

							echo "<div class='st-circle stat-opp'><i class='fa fa-check status-icon thi-status' style='background: green;' id='tick'></i><span class='ml-2'> {$sus_massage} {$row['deli_date']}</span></div> <br>

								";

						}else{
							echo "<div class='st-circle stat-opp'><i class='fa fa-check status-icon thi-status' style='background: none;' id='tick'></i><span class='ml-2'></span></div> <br>

								"; ;
						}

						
					}

					
				}else{ 
					echo "No login";
				}


 ?>