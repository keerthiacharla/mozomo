<?php 

include "../../admin/infile/config.php";
	 $id = $_POST['id'];
	/* echo "php";*/
				
			$sql = "SELECT * FROM roz WHERE ord = '{$id}' ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						echo " <tr>
								<td><b>Order Id </b></td>
								<td>{$row['ord']} </td>
							</tr>
							<tr>
								<td><b>Payment Id </b></td>
								<td>{$row['pay_id']} </td>
							</tr>
							<tr>
								<td><b>Ammount </b></td>
								<td>{$row['amt']}</td>
							</tr>";

						
					}

					
				}else{ 
					echo "No login";
				}


 ?>