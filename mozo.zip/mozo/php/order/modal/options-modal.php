<div class="modal fade " id="ret-opp" data-backdrop="static">
	<div class="modal-dialog"> 
		<div class="modal-content">
			<div class="modal-header  p-0 ">
				<h5 class="text-white p-2">Reason about returning item  <span id="ad-erro"> Lorem, ipsum.</span></h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid ">
					<div class="row" >
						<div class="col-md-12">
							<form action=""  class="form" id="cos_opp_form">

								
								<input type="text" id="cos_id" name="cos_id" value="" hidden>
								<input type="text" id="cos_ord" name="cos_ord" value="" hidden>
								<div class="form-group  form-inline p-2">
									<input type="radio" name="cos_mass" id="cos_mass1" class="cos_mass  form-control-sm mr-2" value="Order by mistake">
									<label for="cos_mass1">Order by mistake </label><br>
								</div>
								<div class="form-group form-inline p-2">

									<input type="radio" name="cos_mass" id="cos_mass2" class="cos_mass  form-control-sm mr-2" value="Product is Damanged">
									<label for="cos_mass2">Product is Damange </label><br>
								</div>
								<div class="form-group form-inline p-2">

									<input type="radio" name="cos_mass" id="cos_mass3" class="cos_mass  form-control-sm mr-2" value="Wrong item was Sended">
									<label for="cos_mass3">Wrong item was Sended </label><br>
								</div>
								<div class="form-group form-inline p-2">

									<input type="radio" name="cos_mass" id="cos_mass4" class="cos_mass  form-control-sm mr-2" value="Item is not satisfied">
									<label for="cos_mass4">Item is not satisfied </label><br>
								</div>
								<div class="form-group form-inline p-2">

									<input type="radio" name="cos_mass" id="cos_mass5" class="cos_mass  form-control-sm mr-2" value="Delivary is soo late">
									<label for="cos_mass5">Delivary is soo late </label><br>
								</div>
								<input type="text" id="cos_opp_ord" name="cos_opp_ord" value="" hidden>

								<div class="form-group cos_command_return">

									<textarea rows="10" class="form-control" placeholder="Write Your Command" id="cos_ret_comm"></textarea>
									
								</div>
								<button class="btn btn-primary " id="cos-opp-sub"> Submit</button>
								
							</form>					
						</div>

					</div>
				
				</div>

			</div>
		</div>
	</div>
</div>