<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="../css/first.css">
</head>
<body>
	<div class="container-fluid" id="status-container">
		<div class="row">
			<div class="col-md-5">

				<h2> Status </h2>
					<div class="status-container m-2">
					<div class="status-bar d-flex flex-column " id="first-status-bar">
						
						
					</div>
				</div>
					<div class="status-container m-2">
						<div class="status-bar d-flex flex-column " id="sec-status-bar">
							
						</div>
					</div>
					<div class="status-container m-2">
						<div class="status-bar d-flex flex-column " id="thi-status-bar">
							<div class="st-circle stat-opp"><i class="fa fa-check status-icon thi-status" id="tick"></i><span class="ml-2">Processing</span></div> <br>

							<div class="status-bor thi-status"></div>
						</div>
					</div>
			
				</div>

				<hr><hr>

		</div>
				<div class="row">
					<div class="col-md-3">
						<table class="table" boader="1" id="pay_del_table">

							
							

						</table>
						<hr><hr>

						<div id="return">
							
						</div>
						<?php include "modal/options-modal.php"?>


					</div>
				</div>

	</div>
	
</body>
</html>