<?php 


include "../../admin/infile/config.php";

	 $id = $_POST['id'];
	/* echo "php";*/
				
			$sql = "SELECT * FROM roz WHERE ord = '{$id}' ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						$pid = $row['sno'];

						

						if($row['procss'] == 2  || $row['procss'] == 3){

							echo "
							
								<div class='st-circle stat-opp'><i class='fa fa-check status-icon sec-status' style='background: green;' id='tick'></i><span class='ml-2'>Processing</span>
								

								<a href='#' data-toggle='collapse' data-target='.sec-massage'>Current Status</a>

								<div class='status-bor sec-status' style='background: green;'></div>
								

								";
								



								$sql1 = "SELECT * FROM deli_statussn WHERE ord_id = '{$pid}' ";

									$res1 = mysqli_query($conn,$sql1) or die(" query failed");

									if(mysqli_num_rows($res1) > 0){

										
										while($row1 = mysqli_fetch_assoc($res1)){
								
											echo "<div class='sec-massage collapse ml-4' >
												<table class='table' id='status-tabel'>
													<tr>
														<td><p>{$row1['d_date']}.</p></td>
														<td><p>{$row1['s_area']}.</p></td>

													</tr>
												</table>
												
											</div>
										</div> <br>

							";
						}
					}


						}else if($row['procss'] == 0 ){
							echo "<div class='st-circle stat-opp'><i class='fa fa-check status-icon sec-status'  id='tick'></i><span class='ml-2'>Processing</span>

								
								<div class='sec-massage collapse ml-4' >
									
								</div>
							</div> <br>

							<div class='status-bor sec-status'></div>" ;
						}

						
					}

					
				}else{ 
					echo "No login";
				}


 ?>