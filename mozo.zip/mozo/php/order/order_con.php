<head>
	<link rel="stylesheet" href="../css/first.css">
</head>
<div class="container-fluid" id="order_container">
	<div class="row">
		<div class="order head">
			<h2>Order </h2>
		</div>
		
	
		</div>

		<hr><hr>
	

			<div id="recent-ord-det" class="">

				<?php 

		 $id = $_SESSION['id'];
		 

		include "admin/infile/config.php";

					
			 $sql = "SELECT * FROM roz WHERE cos_no = $id ORDER BY sno DESC";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res)){

					
					while($row = mysqli_fetch_assoc($res)){

						$pay_sno = $row['sno'];
					
						 $item =  $row['itm_sno'];
						 $pro = $row['p_id'];
						$pay = $row['pay_id'];

						if($row['deli_name'] != "" && $row['deli_ph'] != "" && $row['cos_otp'] != 0 || $row['ord_status'] == "Ready to Pickup"){
									$gent ="<div class='deli-details  mt-2 text-success' >
									 <b>  Delivary Agent Name & Phone Number: </b>
									  {$row['deli_name']} {$row['deli_ph']}
								</div>";
								}else{
									$gent ="";
								}

						if($pro == 1){
							$sql1 = "SELECT * FROM mobile WHERE sno = $item"; 

									$res1 = mysqli_query($conn,$sql1) or die(" query failed");

									if(mysqli_num_rows($res1)){

										
										while($row1 = mysqli_fetch_assoc($res1)){

											$pro_img = "admin/php/product/php/Mobile-images//".$row1['file'];

											$pro_url = "details.php?pid=$item&id=$pro";
										}
									}


						}else if($pro == 2){
							$sql1 = "SELECT * FROM television WHERE sno = $item"; 

									$res1 = mysqli_query($conn,$sql1) or die(" query failed");

									if(mysqli_num_rows($res1)){

										
										while($row1 = mysqli_fetch_assoc($res1)){

											$pro_img = "admin/php/product/php/tv-images//".$row1['file'];
											$pro_url = "tvdetails.php?pid=$item&id=$pro";
										}
									}
								
						}
						

					


				 ?>

				<table id="ord-racent" class="table">
					<tr>
						<td class="col-3"><img src="<?php echo $pro_img ?>" alt="" id="ord-img"></td>
						<td class="p-3">
							<h3><a href="<?php echo $pro_url ?>"><?php echo $row['p_name'] ?></a></h3>
							<h5>Order Id: <?php echo $row['ord'] ?><span class="text-success" id=""> Stuatus : <?php 
								
								echo  $row['ord_status'] .$gent;


							 ?></span></h5></td>
							
							

					</tr>
					<tr class="">
						<td colspan="2"><a href="#"class="btn btn-link bg-primary  m-3 text-white p-2 " id="status-btn" data-sta="<?php echo $row['ord'] ?>">Track Product </a>
							<a href="php/roz/recipt.php?id=<?php echo $pay ?>"class="btn btn-link bg-primary m-3 text-white p-2 ">Print Reciept </a>
							
						</td>
					</tr>
				</table>
				<?php 
					
			}
		}else{
			echo "<h1> No Orders Found <h1>";
		}


				 ?>
				
				
			</div>

			<hr><hr>
 
			

			





	</div>
</div>

<?php include "track.php" ?>