<?php 

include "../../admin/infile/config.php";
		$co_id = "Mzo". rand(000000,999999);
		$fname = mysqli_escape_string($conn,$_POST['f_name']);
		$lname = mysqli_escape_string($conn,$_POST['l_name']);
		$pass = mysqli_escape_string($conn,md5($_POST['pass']));
		$email = mysqli_escape_string($conn,$_POST['email']);
		$gen = mysqli_escape_string($conn,$_POST['gender']);
		$phone = $_POST['phone'];
		$add = $_POST['add'];
		$state = $_POST['state'];
		$dis = $_POST['dis'];
		$zip = $_POST['zip'];
		

		
		/*$arr = array(
					"userid" => $co_id,
					"First" => $fname,
					"Last" => $lname,
					"Password" => $pass,
					"Gender" => $gen,
					"phone" => $phone,
					"Email" => $email,
					"address" => $add,
					"State" => $state,
					"District" => $dis,
					"pin code" => $zip
					
				);
				echo "<pre>";
					print_r($arr);
				echo "</pre>";*/

		$sql = "SELECT * FROM cos_users WHERE  email ='{$email}' OR phone ='{$phone}'";
		$res = mysqli_query($conn,$sql) or die("conn failed");

			if(mysqli_num_rows($res) > 0){
			
					echo 2;
					die();

				
			
			}else{
			$sql2 = "INSERT INTO cos_users(user_id,fname,lname,pass,gen,phone,email,address,city,dis,zip) VALUES('{$co_id}','{$fname}','{$lname}','{$pass}','{$gen}','{$phone}','{$email}','{$add}',{$state},{$dis},{$zip})";
						if(mysqli_query($conn,$sql2)){
							echo 1;
						}else{
							echo 0;
			

			}
		}
		




 ?>