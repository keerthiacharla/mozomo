<?php
	

	include "../../admin/infile/config.php";


	 $update_otp = $_POST['otp_enter']; 


					
	 $sql = "SELECT * FROM otp_exp WHERE otp = $update_otp";
				
		$res = mysqli_query($conn,$sql) or die(" 2nd conn failed");

			
			if(mysqli_num_rows($res)){
				while($row = mysqli_fetch_assoc($res)){
					if($row['otp'] == $update_otp){

						$name = $_POST['otp_fetch']; 

						$sql2 = "DELETE FROM otp_exp WHERE email ='{$name}'";
						if(mysqli_query($conn,$sql2)){
							echo 1;
						}else{
							echo 0;
						}




					}else if($row['otp'] != $update_otp){
						echo  2;
					}
				}
			}



		

	



 ?>