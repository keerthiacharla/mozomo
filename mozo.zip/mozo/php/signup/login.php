<?php 
session_start();


	 $usname = $_POST['usname'];
	 $pass = md5($_POST['uspass']);
	


	include "../../admin/infile/config.php";

				
			$sql = "SELECT cos_users.*, state.state AS state_name, city.city AS city_name FROM cos_users
					 LEFT JOIN state ON cos_users.city = state.sno 
					 LEFT JOIN city ON cos_users.dis = city.state_val 
					  WHERE cos_users.email = '{$usname}' AND cos_users.pass ='{$pass}'";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						$_SESSION['id'] = $row['sno'];
						$_SESSION['name'] = $row['fname']." ". $row['lname'];
						$_SESSION['email'] = $row['email'];
						$_SESSION['gender'] = $row['gen'];
						$_SESSION['phone'] = $row['phone'];
						$_SESSION['address'] = $row['address']." ,".$row['city_name'] ." ,".$row['state_name']." -".$row['zip'] ;
						$_SESSION['img'] = $row['image'];
				
						
						echo "yes login";

						
					
					}

					
				}else{ 
					echo "No login";
				}

 ?>