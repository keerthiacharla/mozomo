<?php
	

	include "../../admin/infile/config.php";


	 $email = $_POST['cf_pass_hidd']; 
	 $pass = mysqli_escape_string($conn,md5($_POST['f_pass']));

	/* echo $email. " ". $pass;*/


	$sql = "UPDATE cos_users SET pass='{$pass}' WHERE email = '{$email}' OR phone = '{$email}' ";

	if(mysqli_query($conn,$sql)){
		echo 1;
	}else{
		echo 0;
	}


					
	


		

	



 ?>