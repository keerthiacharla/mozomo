<?php 

	include "../../admin/infile/config.php";
if($_POST['type'] == ""){


	$sql = "SELECT * FROM state";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");

	$str = "";

	$str .="<option value='select'>Select</option>";

		while($row = mysqli_fetch_assoc($res)){
			$str .= "<option value='{$row['sno']}'>{$row['state']}</option>";



		}
	
}else if($_POST['type'] == "statedata"){
	
	$sql2 = "SELECT * FROM city WHERE state_val = {$_POST['id']}";

	$res2 = mysqli_query($conn,$sql2) or die("offerheader.php query failed");
	
	$str = "";

		while($row2 = mysqli_fetch_assoc($res2)){
			$str .= "<option value='{$row2['sno']}'>{$row2['city']}</option>";


	}
}
  echo $str;

 ?>