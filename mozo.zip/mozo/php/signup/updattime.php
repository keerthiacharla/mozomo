<?php

	 $id = $_POST['id'] ;
	

	include "../../admin/infile/config.php";


	$sql = "DELETE FROM otp_exp WHERE email ='{$id}'";
						if(mysqli_query($conn,$sql)){
							echo 1;
						}else{
							echo 0;
						}


 ?>