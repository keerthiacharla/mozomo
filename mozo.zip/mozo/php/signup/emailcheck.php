<?php 
	

		include "../../admin/infile/config.php";
		
		$email = $_POST['val'];

		$otp = rand(1000,9999);

		$sql = "SELECT * FROM cos_users WHERE  email ='{$email}' OR phone ='{$email}'";
		$res = mysqli_query($conn,$sql) or die("conn failed");

			if(mysqli_num_rows($res) > 0){
			
				$sql2 = "INSERT INTO otp_exp(email,otp) VALUES('{$email}',{$otp})";
				
				$res2 = mysqli_query($conn,$sql2) or die(" 2nd conn failed");

					if(mysqli_query($conn,$sql2)){
							echo "<div class='form-group form-inline p-2' id='otp-box'>
							<label for=''> Enter OTP</label>

							<input type='text' class='form-control-sm m-2' id='otp_fetch' value='{$email}' maxlength='4' name='otp_fetch' >
							
							<input type='text' class='form-control-sm m-2' id='otp_enter' maxlength='4' name='otp_enter' placeholder='****'><br>

							<div class='time  w-100 m-2 text-danger'><p>OTP LIMIT IS :-   		<span id='sec'>60  </span> SECONDS</p>
							</div>
							<button class='btn btn-primary ' name='sub-otp' id='sub-otp' data-sotp='{$otp}' >Submit OTP</button>
					
					
						</div>";
						}else{
							echo 0;
			

						}
			
			}else{
			
				echo 2;	
		
			}
				
		




 ?>