<?php 
session_start();
	$cos = $_SESSION['id'];
	$sno = $_POST['sno'];
	$pro_id = $_POST['pro_id'];
	$or_id = $_POST['ord'];
	$pid = $_POST['pid'];
	$name = $_SESSION['name'];
	$add = $_SESSION['address'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$amt = $_POST['amt'];

	   


	include "../../admin/infile/config.php";

				
			if(isset($sno) && isset($pro_id) && isset($or_id)){



				$sql = "INSERT INTO roz(cos_no,itm_sno,p_id,ord,p_name,address,amt,status)
						 VALUES ({$cos},{$sno},{$pro_id},'{$or_id}','{$pid}','{$add}',{$amt},'Pendding')";

				if(mysqli_query($conn,$sql)){
					echo 1;
				}else{
					echo die("payment Query Faild");
				}

			}

			
			


		
	
				
	



 ?>