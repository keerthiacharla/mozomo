<?php

	include "../../admin/infile/config.php";

		$sql = "UPDATE order SET  status = 'Failed' WHERE status = 'Pedding....'";

				if(mysqli_query($conn,$sql)){
					echo 1;
				}else{
					die("query failed");
				}
?>