<?php 

	$sno = $_POST['sno'];
	$pro_id = $_POST['pro_id'];
	$or_id = $_POST['ord'];
	$pid = $_POST['pid'];
	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$amt = $_POST['amt'];

	/*echo $sno . " ". $pro_id . " ".$or_id ." ". $pid ." ". $name." ". $phone." ". $email ." ". $amt ;*/   


	include "../../admin/infile/config.php";

				
			if(isset($sno) && isset($pro_id) && isset($or_id)){



				$sql = "INSERT INTO order(itm_sno,p_id,ord,p_name,amt,status) VALUES ({$sno},{$pro_id},'{$or_id }','{$pid}',{$amt},'Pedding....')";

				if(mysqli_query($conn,$sql)){
					echo 1;
				}else{
					echo die("1st query failed")
				}

			}

			
			


		
	
				
	



 ?>