<?php
 session_start();
date_default_timezone_set("Asia/Kolkata");


 	$id = $_GET['id'];

	include "../../admin/infile/config.php";

 	$sql = "SELECT * FROM roz WHERE pay_id = '{$id}' ";

 	$res = mysqli_query($conn,$sql) or die("1st Query Failed ");

 	if(mysqli_num_rows($res) ){
 		while($row = mysqli_fetch_assoc($res)){

 		 $pro = $row['p_id'];
 		$invoice = $row['invoice'].'<br>';
 		$itm = $row['itm_sno'];
 		$amt = $row['amt'];
 		$date = $row['dat'];
 		$add = $row['address'];
 		}
 	}



 			if($pro == 1){
								$sql_mob = "SELECT * FROM mobile WHERE sno = $itm";
								$res_mob = mysqli_query($conn,$sql_mob) or die("Mob Query Failed ");

								 	if(mysqli_num_rows($res_mob) ){
								 		while($row_mob = mysqli_fetch_assoc($res_mob)){

								 		$ml_name = $row_mob['ml_name']; 

								 		$ml_no = $row_mob['ml_num'];
								 		
								 		 $file = $row_mob['file'];
								 		
								 		}
								 	}else{
								 		echo "";
								 	}

							}else{
								$sql_tv = "SELECT * FROM television WHERE sno = $itm";
								$res_tv = mysqli_query($conn,$sql_tv) or die("Mob Query Failed ");

								 	if(mysqli_num_rows($res_tv) ){
								 		while($row_tv = mysqli_fetch_assoc($res_tv)){

								 			 $ml_name = $row_tv['ml_name'];
								 					$ml_no = $row_tv['ml_no'];
								 					$file = $row_tv['file'];
								 					
								 		}
									}
							}

 	





?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>MOZOMO Invoice <?php echo $invoice ?> </title>
	<link rel="stylesheet" href="../../infile/bootstrap/bootstrap4.css">
	<link rel="stylesheet" href="invoice.css">

</head>
<body>
		<!--  -->
	<div class="container" id="in_maincont">
		<div class="row">
			<div class="col-md-12">
				<h1>MOZOMO </h1>
			</div>
				<div class="col-md-12"><p class="d-block"><b>Payment Invoice No: </b> <span><?php echo $invoice ?></span></p></div>

			<div class="hline d-block ml-auto text-white">
				<b><?php echo "Printed On -: " .date("d-m-Y h:i:sa"); ?></b>
			</div>

			<div class="col-3" id="in-add">
				<h4 class="" >Shiped From : </h4><br>
				<p class="leed" >My Company <br>
				   10/45/20-1, New Town, <br>
				   Phase -1, Yalahanka, <br>
				   Banglore - 2300654
				   </p>

			</div>
			<div class="col-3"id="in-add">
				<h4>Shiping To : </h4><br>
				<p class="leed">

				<?php echo $_SESSION['name']?> <br>
				
				<?php echo $add?> <br>
				   
				   </p>

			</div>
			<div class="col-4"id="in-add">
				<h4>Invoice Details : </h4><br>
				<p class="leed">
					<b>Product Name :</b> <?php echo $ml_name ?> <br>
				    <b>Trasaction Id :</b> <?php echo $id ?> <br>
				     <b>Billing Date :</b><?php echo $date ?> <br> 
				     <b>Payment Thru :</b> ROZORPAY<br>
				   </p>

			</div>
			<div class="col-2"id="in-add">
				<?php 
					
					if($pro == 1){

						$img = "../../admin/php/product/php/Mobile-images/{$file}";

					}else{
						$img = "../../admin/php/product/php/tv-images/{$file}";

					}



					?>


				   <img src="<?php echo $img ?>" alt="">

			</div>

		</div>

		
		<div class="row justify-content-center">
			<div class="col-md-10">
				<table class="table table-lg" >
					<thead class="bg-primary text-white">

						<th>Product Name</th>
						<th>Quantity</th>
						<th>Amount</th>
					</thead>
					<tbody>
						<tr>

							<td><?php echo "<b>Product Name : </b>".$ml_name . "<br>". "<b>Product Number : </b>".$ml_no   ?></td>
							<td>1</td>
							<td class="text-right"><?php echo $amt ?> </td>
						</tr>
						
							

						<tr id="in-tot">
							<hr><hr>
							<td><h5><b>TOTAL :</b></h5></td>

							<td colspan="3"><h5 class="text-right"><b><?php echo $amt ?> </b></h5></td>
						</tr>
					</tbody>

				</table>
			</div>
		</div>
		<hr>
		<div class="row justify-content-center">
			<div class="col-md-10">
				<table class="table">
					<tbody>

					</tbody>
				</table>
			</div>
		</div>

		<div class="hline"></div>
		<div class="row">
		<div class="col-md-12" id="list">
			<ul>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit.
			Morbi vitae libero nec mauris laoreet dapibus a varius purus.
			Nunc dignissim lorem a sapien tempor, ut sollicitudin nunc interdum.
			Pellentesque condimentum turpis id lacinia ornare.
			Nullam facilisis ipsum eu ornare rutrum.
			Phasellus eu sapien rutrum, tincidunt magna fringilla, dignissim lorem
			</ul>
		</div>
	</div>
	<hr><hr>	

	<div class="row d-flex">
		<div class="col-md-3  sing ml-auto">
			<img src="../../admin/infile/eauth.jpg" alt="" class="emp-sing ml-auto">
			
		<h4 class=" m-auto">Dept Purchase  Officer </h4>
		</div>
	</div>
	<button class="btn btn-primary m-auto" id="pri_btn" onclick="myfun()">Print</button>
	<button class="btn btn-primary"><a href="http://localhost/mozo/first.php" class="text-reset">Back To Home</a></button>
	</div>
	
</body>

</html>
<script type="">
	function myfun(){
		window.print();
	}
</script>
