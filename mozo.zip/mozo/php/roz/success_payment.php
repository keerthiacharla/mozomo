<?php 

	$sno = $_POST['sno'];
	$pid =$_POST['pid'];

	/*echo $sno . " ". $pid . "PHP" ;   */


	$invoive = "invoice_mob".rand(0000,99999);
	

		include "../../admin/infile/config.php";

		$sql = "UPDATE roz SET pay_id = '{$pid}', status = 'Suceess',invoice = '{$invoive}',ord_status = 'ordered' WHERE ord = '{$sno}'";

				if(mysqli_query($conn,$sql)){
					
					echo 1;
				}else{
					die("query failed");
				}
	


	 ?>