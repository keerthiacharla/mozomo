<?php 


	$id = $_POST['id'];
	$new = md5($_POST['newpass']);
	

include "../../admin/infile/config.php";


	$sql = "UPDATE cos_users SET pass = '{$new}' WHERE sno = $id";

	

	if(mysqli_query($conn,$sql)){
		echo 1;
	}else{
		die("offerheader.php query failed");
	}

		
			



		






 ?>