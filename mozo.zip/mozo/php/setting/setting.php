<div class="row">
			
		<?php 

		echo $id = $_SESSION['id'];

			include "admin/infile/config.php";

			$sql = "SELECT cos_users.*, state.sno AS state_num ,state.state AS state_name,city.state_val AS city_num, city.city AS city_name FROM cos_users
			 LEFT JOIN state ON cos_users.city = state.sno 
			 LEFT JOIN city ON cos_users.dis = city.state_val 
			  WHERE cos_users.sno = $id";

			$res = mysqli_query($conn,$sql) or die(" 2nd conn failed");

			
			if(mysqli_num_rows($res)){
				while($row = mysqli_fetch_assoc($res)){
					
				
		 ?>


			<div class="col-md-12 set-form">
	

					<div class="set-title">
							<h1>Setting</h1>
					</div>
					<div class="img-form form-inline "> 
						<img src="php/setting/photo/<?php echo $row['image']?>" data-toggle="modal" data-target="#update--img-modal-box"class="cos_img " alt=""><span class="ml-3"><h3><?php echo $row['fname']." ". $row['lname']?></h3></span>
						
					</div>
					<hr><hr>

					<table class="table w-100">
						<tr>
							<td><b>Gender</b></td>
							<td><?php echo $row['gen']?></td>
						</tr>
						<tr>
							<td><b>Email</b></td>
							<td><?php echo $row['email']?> </td>
						</tr>
						<tr>
							<td><b>Phone</b></td>
							<td><?php echo $row['phone']?> </td>
						</tr>
						<tr>
							<td><b>Address</b></td>
							<td><?php echo $row['address']." ,".$row['city_name'] ." ,".$row['state_name']." -".$row['zip']  ?>		 </td>
						</tr>
						<tr>
							<td colspan="2"> <button class="btn btn-success " id="update-set" 
								data-id="<?php echo $_SESSION['id']  ?>" 
								data-fname="<?php echo $row['fname']  ?>" 
								data-lname="<?php echo $row['lname']  ?>" 
								data-gen="<?php echo $row['gen']  ?>" 
								data-email="<?php echo $row['email']  ?>" 
								data-phone="<?php echo $row['phone']  ?>" 
								data-add="<?php echo $row['address']  ?>" 
								data-cityname="<?php echo $row['city_name']  ?>" 
								data-statename="<?php echo $row['state_name']  ?>" 
								data-stateno="<?php echo $row['state_num']  ?>" 
								data-cityno="<?php echo $row['city_num']  ?>" 
								data-zip="<?php echo $row['zip']  ?>" 




								data-toggle="modal" data-target="#update-modal-box">Update</button></td>
						</tr>

						
					</table>
					<?php 

					
				}
			}



		 ?>
				

				<?php include "modal/up-set.php" ?>
			</div>
			<hr><hr>


			<div class="col-md-12 set-form">
				


					<table class="table w-100">
						
						<tr>
							<td><b>Reset Password </b></td>
							<td>*********************		 </td>
						</tr>
						<tr>
							<td colspan="2"> <button class="btn btn-success " data-toggle="modal" data-target="#uppass-modal-box"id="update-pass-set">Update Password </button></td>
						</tr>

						
					</table>
				
			</div>

			
		</div>