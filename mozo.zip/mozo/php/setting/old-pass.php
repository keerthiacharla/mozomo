<?php 


	 $id = $_POST['id'];
	 $old = md5($_POST['oldpass']);

include "../../admin/infile/config.php";


	$sql = "SELECT * FROM cos_users WHERE sno = $id";

	$res = mysqli_query($conn,$sql) or die("offerheader.php query failed");



		while($row = mysqli_fetch_assoc($res)){

			 if($row['pass'] == $old){
			 	echo 1;
			 }else{
			 	echo 0;
			 }
			



		}
	






 ?>