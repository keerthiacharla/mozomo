	<?php




		 $cos_img = $_FILES['uplode-uplog_img']['name'];
	$cos_id = $_POST['uplog_imgid'];
		
		

	

if($cos_img != ""){

		

		$file_temp = $_FILES['uplode-uplog_img']['tmp_name'];

		$extension = pathinfo($cos_img,PATHINFO_EXTENSION);

		$valid_extension = array("jpg","jpeg");
		
		
		if(in_array($extension,$valid_extension) === false){
		
			echo 2;
			
		}else{
			$new_name =  $cos_id.".jpg";
			$target = "photo/". $new_name;
			$image_name = $new_name;
			
			
			
			if(move_uploaded_file($file_temp,$target)){
				
				include "../../admin/infile/config.php";

				$sql = "UPDATE cos_users SET image = '{$new_name}' WHERE sno = {$cos_id}";
						if(mysqli_query($conn,$sql) == true){
							echo 1;
						}else{
							echo 0;
						}
			}else{
				echo 0;
				
			}
		}
		
		
		

				
		
		
	}else{
		echo "Please upload image of product";
	}
	



			?>
