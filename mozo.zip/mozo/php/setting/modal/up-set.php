<div class="modal fade " id="update-modal-box" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header modal-header p-0 ">
				<h5 class="text-white p-2"> Details Update   </h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action=""  class="form p-1" id="cos-det-form">

								<div class="form-gouup">
									
									<input type="text" class="form-control" name="uplog_id" id="uplog_id" hidden>
								</div>
								<div class="form-gouup">
									<label for="">First Name </label>
									<input type="text" class="form-control" name="uplog_fname" id="uplog_fname" placeholder="Enter Your First Name ">
								</div>
								<div class="form-gouup">
									<label for="">Last Name </label>
									<input type="text" class="form-control" name="uplog_lname" id="uplog_lname" placeholder="Enter Your Last Name ">
								</div>

									
									<div class="form-group">
											<div class="form-group form-inline p-2">
												<label for="" class="d-flex">Gender <span id="" class="gen_na_error color_fild">*</span> </label>
												<input type="radio" class="form-control m-2 uplog_gender" id="male" name="uplog_gender" value="Male">
												<label for="male">Male </label>
												
												<input type="radio" class="form-control m-2 uplog_gender" id="female" name="uplog_gender" value="Female">
												<label for="female">Female </label>
											</div>
										</div>
								
								<div class="form-gouup">
									<label for="">Email Name </label>
									<input type="text" class="form-control" name="uplog_email" id="uplog_email" placeholder="Enter Your Email ID ">
								</div>
								<div class="form-gouup">
									<label for="">Phone </label>
									<input type="text" class="form-control" name="uplog_phone" id="uplog_phone" placeholder="Enter Your Phone Number" maxlength="10">
								</div>
								<div class="form-gouup">
									<label for="">Address </label>
									<textarea name="uplog_add" class="form-control"  id="uplog_add"  cols="30" rows="10" placeholder="Enter Your address  "></textarea>
								</div>
								<div class="form-gouup">
									<label for="">State </label>
									<select name="uplog_state" class="form-control custom-select" id="uplog_state" >				
										
									</select>
								</div>
								<div class="form-gouup ">
									<label for="">City </label>
									<select name="uplog_city" class="form-control custom-select" id="uplog_city">
									</select>
								</div>
								<div class="form-gouup">
									<label for="">Zip Code  </label>
									<input type="text" class="form-control" name="uplog_zip" id="uplog_zip" placeholder="Enter Your Pin Code ">
								</div>
								
							
								<button class="btn btn-primary mt-2 " id="cos-det-btn"> Update Details </button>



							</form>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
			</div>

		</div>
	</div>
</div>


<div class="modal fade " id="update--img-modal-box" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header modal-header  p-0 ">
				<h5 class="text-white p-2">Uploade image   </h5>
				<span class="error text-white bg-danger m-1 p-2">
					
				</span>
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="cos-form">
								<div class="form-group">
									<input type="text" class="form-control" name="uplog_imgid" id="uplog_imgid" value="<?php echo $id ?>" hidden>
									<label for="">Upload Image </label>
									<input type="file" class="form-control" id="uplode-uplog_img" name="uplode-uplog_img">
									<button class="btn btn-primary " id="cos-upload">Upload</button>
								</div>
							</form>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
			</div>

		</div>
	</div>
</div>



<div class="modal fade " id="uppass-modal-box" data-backdrop="static">
	<div class="modal-dialog  modal-dialog-scrollable">
		<div class="modal-content">
			<div class="modal-header modal-header  p-0 ">
				<h5 class="text-white p-2">Reset Password  </h5>
				<span class="error text-white bg-danger m-1 p-2">
					
				</span>
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<form action="" id="repass-form">
								<div class="form-group mt-3">

									<input type="text" class="form-control" id="re_passid" name="re_passid" placeholder="" value="<?php echo $id ?>"hidden>
									<label for="">Old PASSWORD</label>
							
								<div class="input-group">
									<div class="input-group-prend">
										<span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
									</div>
									<input type="password" class="form-control" id="re_oldpass" name="re_oldpass" placeholder="Enter Your password ">
									<div class="input-group-append">
										<span id="re_oldicon" class="input-group-text"><i class="fa-solid fa-eye" id="re_show_oldicon"></i></span>
									</div>
								</div>
							
							</div>
								<div class="pass-form">

								<div class="form-group mt-3">
									<label for="">New PASSWORD</label>
							
								<div class="input-group">
									<div class="input-group-prend">
										<span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
									</div>
									<input type="password" class="form-control" id="re_pass" name="re_pass" placeholder="Enter Your password ">
									<div class="input-group-append">
										<span id="re_icon" class="input-group-text"><i class="fa-solid fa-eye" id="re_show_icon"></i></span>
									</div>
								</div>
							
							</div>
							<div class="form-group mt-3">
								<label for=""> Retype New PASSWORD</label>
							
								<div class="input-group">
									<div class="input-group-prend">
										<span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
									</div>
									<input type="password" class="form-control" id="re_cpass" name="re_cpass" placeholder="Enter Your password ">
									<div class="input-group-append">
										<span id="re_cicon" class="input-group-text"><i class="fa-solid fa-eye" id="re_show_cicon"></i></span>
									</div>
								</div>
							
						</div>
								</div>

									<button class="btn btn-primary " id="cos-upload">Upload</button>
							</form>
						</div>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
			</div>

		</div>
	</div>
</div>