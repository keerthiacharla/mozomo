<?php 
						 			include "admin/infile/config.php";

											
											
											$sql = "SELECT * FROM specival WHERE under = 19";
											$res = mysqli_query($conn,$sql) or die(" query failed");

											if(mysqli_num_rows($res) > 0){

												
												while($row = mysqli_fetch_assoc($res)){

						 			 ?>

									 			<li class="ml-3">
									 				<input type="checkbox" class="tv_dis_selector tv_dis_val" id="<?php echo $row['sno'] ?>" value="<?php echo $row['s_val'] ?>" >
									 				<label for="<?php echo $row['sno'] ?>"><?php echo $row['s_val'] ?></label>

									 			</li>

									 			<?php 
									 		}
									 	}


						 			 ?>