<?php 
						 			include "admin/infile/config.php";

											
											
											$sql = "SELECT * FROM pro WHERE cid = 1";
											$res = mysqli_query($conn,$sql) or die(" query failed");

											if(mysqli_num_rows($res) > 0){

												
												while($row = mysqli_fetch_assoc($res)){

						 			 ?>

									 			<li class="ml-3">
									 				<input type="checkbox" class="pro_selector mob_pro" id="<?php echo $row['sno'] ?>" value="<?php echo $row['sno'] ?>" >
									 				<label for="<?php echo $row['sno'] ?>"><?php echo $row['pname'] ?></label>

									 			</li>

									 			<?php 
									 		}
									 	}


						 			 ?>