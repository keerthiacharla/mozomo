<?php 

	


	include "../../admin/infile/config.php";

	if(!isset($_POST['ram'])){
		echo 0;
	}else{



		$id = implode("','",$_POST['ram']);

		/*print_r($id);*/
				
				/*$cid = $_POST['cid'];*/
				
			 $sql = "SELECT * FROM mobile WHERE ram IN ('$id')";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res)){
					
					
					while($row = mysqli_fetch_assoc($res)){

						if($row['off_rate'] != "No Offer" ){
											$off_div = "<div class='off-tag'>
													<h5 class='text-white text-center' id='offtag-text'>{$row['off_per']}%</h5>
												</div>";

											$off_price = "<div id='flex-off-rate'>
																<h3><i class='fa-sharp fa-solid fa-indian-rupee-sign mr-2'></i>{$row['off_rate']}</h3>
																<div class='d-flex p-3'>
																	<h5 class='font-weight-lighter '><i class='fa-sharp fa-solid fa-indian-rupee-sign mr-2 '></i>{$row['amt']}</h5><span class='bg-success text-white font-weight-bold  ml-3 p-2'>{$row['off_per']} % Off</span>
																	</div>							
															</div>";
										}else{
											$off_div = "";
											$off_price ="<div id='Flex-amount ' class=' d-flex mt-auto'>
														<h3><i class='fa-sharp fa-solid fa-indian-rupee-sign mt-2'></i>{$row['amt']}</h3>
													</div>";
										}



										echo "<div class='col-md-3 m-4 d-flex flex-column' id='flex-item' > 
													{$off_div}
												
													<div id='flex-img'>
														<img src='admin/php/product/php/Mobile-images/{$row['file']}' alt=''>
													</div>
													<div id='flex-header p-2'>
														<h3><center>{$row['ml_name']}<lcenter></h3>
													</div>
													{$off_price}
													
													<a href='details.php?pid={$row['sno']}&id={$row['pro_name']}' class='btn btn-primary mt-auto mr-auto'>Buy Now</a>

												</div>";
					
					}

					
				}else{
					echo 0;
				}
	}
 ?>
	