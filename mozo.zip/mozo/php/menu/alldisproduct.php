
<?php 

		include "../../admin/infile/config.php";
		
				/*$cid = $_POST['cid'];*/
				
			 $sql = "SELECT * FROM category" ;

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res)){

					
					while($row = mysqli_fetch_assoc($res)){

						if($row['sno'] == 1 ){

							$sqlmob = "SELECT * FROM mobile" ;
							$resmob = mysqli_query($conn,$sqlmob) or die(" query failed");

							if(mysqli_num_rows($resmob)){

								while($rowmob = mysqli_fetch_assoc($resmob)){

										if($rowmob['off_rate'] != "No Offer" ){
											$off_div = "<div class='off-tag'>
													<h5 class='text-white text-center' id='offtag-text'>{$rowmob['off_per']}%</h5>
												</div>";

											$off_price = "<div id='flex-off-rate'>
																<h3><i class='fa-sharp fa-solid fa-indian-rupee-sign mr-2'></i>{$rowmob['off_rate']}</h3>
																<div class='d-flex p-3'>
																	<h5 class='font-weight-lighter '><i class='fa-sharp fa-solid fa-indian-rupee-sign mr-2 '></i>{$rowmob['amt']}</h5><span class='bg-success text-white font-weight-bold  ml-3 p-2'>{$rowmob['off_per']} % Off</span>
																	</div>							
															</div>";
										}else{
											$off_div = "";
											$off_price ="<div id='Flex-amount ' class=' d-flex mt-auto'>
														<h3><i class='fa-sharp fa-solid fa-indian-rupee-sign mt-2'></i>{$rowmob['amt']}</h3>
													</div>";
										}



										echo "<div class='col-md-3 m-4 d-flex flex-column' id='flex-item' > 
													{$off_div}
													
													<div id='flex-img'>
														<img src='admin/php/product/php/Mobile-images/{$rowmob['file']}' alt=''>
													</div>
													<div id='flex-header p-2'>
														<h3><center>{$rowmob['ml_name']}<lcenter></h3>
													</div>

													{$off_price}
													
													<a href='details.php?pid={$rowmob['sno']}&id={$rowmob['pro_name']}' class='btn btn-primary mt-auto mr-auto'>Buy Now</a>

												</div>";

								}

							}


						}else if($row['sno'] == 2 ){


							$sqltv = "SELECT * FROM television" ;
							$restv = mysqli_query($conn,$sqltv) or die(" query failed");

							if(mysqli_num_rows($restv)){

								while($rowtv = mysqli_fetch_assoc($restv)){

									if($rowtv['off_rate'] != "No Offer" ){

											$tvoff_div = "<div class='off-tag'>
													<h5 class='text-white text-center' id='offtag-text'>{$rowtv['off_per']}%</h5>
												</div>";

											$tvoff_price = "<div id='flex-off-rate'>
																<h3><i class='fa-sharp fa-solid fa-indian-rupee-sign mr-2'></i>{$rowtv['off_rate']}</h3>
																<div class='d-flex p-3'>
																	<h5 class='font-weight-lighter '><i class='fa-sharp fa-solid fa-indian-rupee-sign mr-2 '></i>{$rowtv['amt']}</h5><span class='bg-success text-white font-weight-bold  ml-3 p-2'>{$rowtv['off_per']} % Off</span>
																	</div>							
															</div>";
										}else{
											$tvoff_div = "";
											$tvoff_price ="<div id='Flex-amount' class=' d-flex mt-auto'>
														<h3><i class='fa-sharp fa-solid fa-indian-rupee-sign mt-2'></i>{$rowtv['amt']}</h3>
													
													</div>";
										}



										echo "<div class='col-md-3 m-4 d-flex flex-column' id='flex-item' > 
													{$tvoff_div}
													
													<div id='flex-img'>
														<img src='admin/php/product/php/tv-images/{$rowtv['file']}' alt=''>
													</div>
													<div id='flex-header p-2 mt-4'>
														<h3><center>{$rowtv['ml_name']}</center></h3>
													</div>
													{$tvoff_price}
													
													<a href='tvdetails.php?pid={$rowtv['sno']}&id={$rowtv['pro_name']}' class='btn btn-primary  mt-auto  mr-auto'>Buy Now</a>

												</div>";


								}

							}
						}


						
					
					}

					
				}else{
					echo "No data Found ";
				}
				

				




 ?>


 