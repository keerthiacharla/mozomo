<div class="col-md-12 m-0" id="caro-slide">
				<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
				  <ol class="carousel-indicators">
				    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
				    <?php
						
						

						include "admin/infile/config.php";

						$sql = "SELECT * FROM carosol";

						$res = mysqli_query($conn,$sql) or die("loadbtn.php query failed");

						
						if(mysqli_num_rows($res) > 0){
							while($row = mysqli_fetch_assoc($res)){
								?>
						<li data-target="#mycarousel" data-slide-to="<?php echo $row['sno']?>"></li>
							<?php
						}
					}
								?>
				  </ol>
				  <div class="carousel-inner" data-interval="1000">
				  	<?php
						
						

								include "admin/infile/config.php";

								$sql = "SELECT * FROM carosol WHERE sno = 1";

								$res = mysqli_query($conn,$sql) or die("loadbtn.php query failed");
								if(mysqli_num_rows($res) > 0){
							while($row = mysqli_fetch_assoc($res)){
						?>
				    <div class="carousel-item active">
				     	<div class="itm d-flex"  style="background: url(admin/php/carosol/php/corosol-images/<?php echo $row['img']?>); background-size: 100% 100%;background-repeat: no-repeat; background-position: center;">
				     		 <!-- <img class="d-block w-100" src="images/1.jpg" alt="First slide"> -->
				     		<div class="col-md-6 justify-ontent-center m-auto d-block align-self-center ">
				     			<h3><b><?php echo $row['title']?></b></h3>
				     			<p> <?php echo $row['dis']?></p>
				     		</div>
				     	</div>
				    </div>
				    		<?php 
								}
							}
						?>
							<?php
						
						

								include "admin/infile/config.php";

								$sql = "SELECT * FROM carosol ";

								$res = mysqli_query($conn,$sql) or die("loadbtn.php query failed");
								if(mysqli_num_rows($res) > 0){
							while($row = mysqli_fetch_assoc($res)){
						?>
				    <div class="carousel-item">
				     	<div class="itm d-flex"  style="background: url(admin/php/carosol/php/corosol-images/<?php echo $row['img']?>); background-size: 100% 100%;background-repeat: no-repeat; background-position: center;">
				     		 <!-- <img class="d-block w-100" src="images/1.jpg" alt="First slide"> -->
				     		<div class="col-md-6 justify-ontent-center m-auto d-block align-self-center ">
				     			<h3><b><?php echo $row['title']?></b></h3>
				     			<p> <?php echo $row['dis']?></p>
				     		</div>
				     	</div>
				    </div>
				    		<?php 
								}
							}
						?>
				   				    </div>
				  </div>
				  
				  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
				    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
				    <span class="sr-only">Previous</span>
				  </a>
				  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
				    <span class="carousel-control-next-icon" aria-hidden="true"></span>
				    <span class="sr-only">Next</span>
				  </a>
				</div>
			</div>