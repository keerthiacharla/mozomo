<?php 


	date_default_timezone_set("Asia/Kolkata");
	

		include "admin/infile/config.php";

				
				
				
			 $sql = "SELECT * FROM roz WHERE sno = 10"; 

				$res = mysqli_query($conn,$sql) or die(" query failed first");

				if(mysqli_num_rows($res)){

					
					while($row = mysqli_fetch_assoc($res)){

						$today = date("d-m-Y");
						
						$date = date_create($today);
						echo  "<br>";

					echo	$delivary = $row['deli_date'];
						$del_date = date_create($delivary);
					     
					    $ret_differ = date_diff($date,$del_date);

						echo "<pre>";
						print_r($ret_differ);
						echo "</pre>";
					     
					echo	$inter = $row['deli_ret'];
						echo  $no_days = $ret_differ->days;

						echo 	 $day_left =  date("d-m-Y", strtotime($delivary."+".$inter." days"));
					echo  "<br>";


					if($inter <= $no_days){
						echo "big number";

					}else{
						echo "<p><b>Return is applicable to  From Delivary Date Upto  :-</b> 
									<span><button class='btn btn-primary' id='return-pro' data-ret=''> Return </button></span> 
								</p>";
					}

						

					}
				}

						
 ?>