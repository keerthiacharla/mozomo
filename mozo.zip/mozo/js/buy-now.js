$(document).ready(function(){
	/*alert("Buy aaaa");*/


	var updatetime = function(){
					$.ajax({
						url:"php/roz/failure.php",
						type:"POST",						
						success:function(data){
							/*alert(data);*/
						
								

							
						}
					})

			}
			setTimeout(updatetime,60000);

	$("#mob-rzp-button1").click(function(){
		/*alert("mob-buynow");*/

		var mob_sno = $("#mob_id").val();
		var mob_pro= $("#mobpr_id").val();
		var mob_ord = $("#mob_or_id").val();
		var mob_pid = $("#mob_p_id").val();
		var mob_name = $("#mob_name").val();
		var mob_email = $("#mob_email").val();
		var mob_amt = $("#mob_amt").val();
		var mob_phone = $("#mob_phone").val();


		
			

		$.ajax({
			url:"php/roz/payment.php",
			type: "POST",
			data: {sno:mob_sno,pro_id:mob_pro, ord:mob_ord, pid:mob_pid,name:mob_name,email:mob_email,phone:mob_phone,amt:mob_amt},
			success:function(data){
				console.log(data);
				if(data == 1){
				var options = {
					    "key": "rzp_test_DE0rYfQsMKN5Ha", // Enter the Key ID generated from the Dashboard
					    "amount": mob_amt * 100,
					    "currency": "INR",
					    "name": mob_name,
					    "description": mob_name,
					    "image": "https://s3.amazonaws.com/rzp-mobile/images/rzp.jpg",
					    "prefill":
					    {
					      "email": mob_email,
					      "contact": mob_phone,
					    },
					    config: {
					      display: {
					        blocks: {
					          utib: { //name for Axis block
					            name: "Pay using Axis Bank",
					            instruments: [
					                {
						              method: 'upi'
						            },
						            {
						              method: 'card'
						            },
						            {
						                method: 'wallet'
						            },
						            {
						                method: 'netbanking'
						            }
						          ],
						        },
						      },
					        sequence: ["block.utib", "block.other"],
					        preferences: {
					          show_default_blocks: false // Should Checkout show its default blocks?
					        }
					      }
					    },
					    "handler": function (response) {
					   /*   alert( mob_sno + " "+response.razorpay_payment_id);*/

					      $.ajax({
								url:"php/roz/success_payment.php",
								type: "POST",
								data: {sno:mob_ord,pid:response.razorpay_payment_id},
								success:function(data){

								if(data == 1){
										window.location.href= "php/roz/recipt.php?id="+response.razorpay_payment_id;


									}else{
										console.log(data);
										setTimeout(updatetime,60000);
									}
								}
							});
					    },
					    "modal": {
					      "ondismiss": function () {
					        if (confirm("Are you sure, you want to close the form?")) {
					          txt = "You pressed OK!";
					          console.log("Checkout form closed by the user");
					        } else {
					          txt = "You pressed Cancel!";
					          console.log("Complete the Payment")
					        }
					      }
					    }
					  };
					  var rzp1 = new Razorpay(options);
					
					    rzp1.open();
						}else{
							console.log(data);
						}
					}
					})

		/**/
		  
	})


	$("#tv-rzp-button1").click(function(){
		/*alert("tv-buynow")*/
		var tv_sno = $("#tv_id").val();
		var tv_pro= $("#tvpr_id").val();
		var tv_ord = $("#tv_or_id").val();
		var tv_pid = $("#tv_p_id").val();
		var tv_name = $("#tv_name").val();
		var tv_email = $("#tv_email").val();
		var tv_amt = $("#tv_amt").val();
		var tv_phone = $("#tv_phone").val();

			

		$.ajax({
			url:"php/roz/payment.php",
			type: "POST",
			data: {sno:tv_sno,pro_id:tv_pro, ord:tv_ord, pid:tv_pid,name:tv_name,email:tv_email,phone:tv_phone,amt:tv_amt},
			success:function(data){
				console.log(data);
				if(data == 1){
				var options = {
					    "key": "rzp_test_DE0rYfQsMKN5Ha", // Enter the Key ID generated from the Dashboard
					    "amount": tv_amt * 100,
					    "currency": "INR",
					    "name": tv_name,
					    "description": tv_name,
					    "image": "https://s3.amazonaws.com/rzp-mobile/images/rzp.jpg",
					    "prefill":
					    {
					      "email": tv_email,
					      "contact": tv_phone,
					    },
					    config: {
					      display: {
					        blocks: {
					          utib: { //name for Axis block
					            name: "Pay using Axis Bank",
					            instruments: [
					              {
					                method: "card",
					                issuers: ["UTIB"]
					              },
					              {
					                method: "netbanking",
					                banks: ["UTIB"]
					              },
					            ]
					          },
					          other: { //  name for other block
					            name: "Other Payment modes",
					            instruments: [
					              {
					                method: "card",
					                issuers: ["ICIC"]
					              },
					              {
					                method: 'netbanking',
					              }
					            ]
					          }
					        },
					        hide: [
					          {
					          method: "upi"
					          }
					        ],
					        sequence: ["block.utib", "block.other"],
					        preferences: {
					          show_default_blocks: false // Should Checkout show its default blocks?
					        }
					      }
					    },
					    "handler": function (response) {
					     /* alert( tv_sno + " "+response.razorpay_payment_id);*/

					      $.ajax({
								url:"php/roz/success_payment.php",
								type: "POST",
								data: {sno:tv_ord,pid:response.razorpay_payment_id},
								success:function(data){

								if(data == 1){
										window.location.href= "php/roz/recipt.php?id="+response.razorpay_payment_id;

									}else{
										console.log(data);
										setTimeout(updatetime,60000);
									}
								}
							});
					    },
					    "modal": {
					      "ondismiss": function () {
					        if (confirm("Are you sure, you want to close the form?")) {
					          txt = "You pressed OK!";
					          console.log("Checkout form closed by the user");
					        } else {
					          txt = "You pressed Cancel!";
					          console.log("Complete the Payment")
					        }
					      }
					    }
					  };
					  var rzp1 = new Razorpay(options);
					
					    rzp1.open();
						}else{
							console.log(data);
						}
					}
					})

		/**/
		  
	})
})