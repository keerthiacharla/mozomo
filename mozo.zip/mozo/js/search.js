$(document).ready(function(){
	alert("ci9sz");

	$("#item-seaarch").keyup(function(){
		var val = $(this).val();
		/*alert(val);*/

			function searchproduct(){
								$.ajax({
								url:"php/menu/searchdisproduct.php",
								type:"POST",
								data:{id:val},
								
								success:function(data){
									/*console.log(data);*/
									$("#home_sec").html(data);
								}
							})
				

					}
					searchproduct();
	})
})