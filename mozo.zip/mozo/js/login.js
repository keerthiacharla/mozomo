$(document).ready(function(){
	/*alert("login.js");*/

	$("#luser_icon").click(function(){


                $("#luser_show_icon").toggleClass("fa-eye-slash");


                $("#luser_show_icon").css("color","black")


                $(".fa-eye-slash").css("color","red");


      var pass_input= $("#user_pass");
                    
            if(pass_input.attr("type")==="password"){
    
                pass_input.attr("type","text");
            
            }else{
                pass_input.attr("type","password");
            }

			})

	$("#login-form").submit(function(h){
		h.preventDefault();

		var usid = $("#user_name").val();
		var uspass = $("#user_pass").val();
		var uscapahid = $("#user_capa_hidd").val();
		var uscapa = $("#user_capa").val();
		

		if(usid == ""){
			$(".signup_error").css("display","block");
                            $(".error-box").fadeIn();
                            $(".signup_error").html("Please Enter User Name");
                            setTimeout(function(){
                                $(".signup_error").fadeOut();
                                $(".signup_error").css("display","none");
                                $(".signup_error").html("");

                            },5000);
                        return false;
		}else if(uspass == ""){
			$(".signup_error").css("display","block");
                            $(".error-box").fadeIn();
                            $(".signup_error").html("Please Enter User password");
                            setTimeout(function(){
                                $(".signup_error").fadeOut();
                                $(".signup_error").css("display","none");
                                $(".signup_error").html("");

                            },5000);
                        return false;
		}else if(uscapa == ""){
			$(".signup_error").css("display","block");
                            $(".error-box").fadeIn();
                            $(".signup_error").html("Please Enter Capache");
                            setTimeout(function(){
                                $(".signup_error").fadeOut();
                                $(".signup_error").css("display","none");
                                $(".signup_error").html("");

                            },5000);
                        return false;
		}else if(uscapa!== uscapahid){
                             $(".capa-err").css("display","block");
                             $(".signup_error").css("display","block");
                                $(".error-box").fadeIn();
                                $(".signup_error").html("Capache is not matching ");
                                setTimeout(function(){
                                    $(".signup_error").fadeOut();
                                    $(".signup_error").css("display","none");
                                    $(".signup_error").html("");

                                },5000);
                                return false;
                        }
                       /* alert(usid + " "+ uspass);*/


                 $.ajax({
                        url: "php/signup/login.php",
                        type:"POST",
                        data: {usname:usid,uspass:uspass},
                        success:function(data){
                            if(data == "yes login"){
                                 window.location.href ='http://localhost/mozo/first.php';
                            }else{
                                $(".signup_error").css("display","block");
                                $(".error-box").fadeIn();
                                $(".signup_error").html("Incorrect Credientials  ");
                                setTimeout(function(){
                                    $(".signup_error").fadeOut();
                                    $(".signup_error").css("display","none");
                                    $(".signup_error").html("");

                                },5000);
                                return false;
                                console.log(data);

                            }
                        }
                    })  
	})
})