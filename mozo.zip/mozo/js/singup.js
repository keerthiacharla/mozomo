$(document).ready(function(){
	/*alert("singup.js");*/

	$(document).on("click","#join",function(a){
		a.preventDefault();

		$("#login-form").css("display","none");
		$("#singup-form").css("display","block");
		/*alert("join");*/
	})

	$(document).on("click","#back-to",function(b){
		b.preventDefault();

		$("#singup-form").css("display","none");
		$("#login-form").css("display","block");
		/*alert("join");*/
	})

	function sucapa(){
					var sutext = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
					var sucapch = "";

					for(var i=1;i<6;i++){
						sucapch = sucapch + sutext.charAt(Math.floor(Math.random()*63));
					}
					$(".sucapa-img").html(sucapch);
					$("#sucapa-hidden").val(sucapch);
					}
			sucapa();


			$("#sure").click(function(){
				sucapa();

			})

		$("#sicon").click(function(){


                $("#puser_show_icon").toggleClass("fa-eye-slash");


                $("#puser_show_icon").css("color","black")


                $(".fa-eye-slash").css("color","red");


      var pass_input= $("#pass");
                    
            if(pass_input.attr("type")==="password"){
    
                pass_input.attr("type","text");
            
            }else{
                pass_input.attr("type","password");
            }

			})


     $("#scicon").click(function(){


                $("#cpuser_show_icon").toggleClass("fa-eye-slash");


                $("#cpuser_show_icon").css("color","black")


                $(".fa-eye-slash").css("color","red");


      var cpass_input= $("#cpass");
                    
            if(cpass_input.attr("type")==="password"){
    
                cpass_input.attr("type","text");
            
            }else{
                cpass_input.attr("type","password");
            }

            })

    
     $("#f_name,#l_name").keypress(function(evt){
            var ch = String.fromCharCode(evt.which);
                if((/[0-9/!/@/#/$/%/^/&/*/(/)/_/-/+/=/{/[/?/}/:/;/""/''/</,/>/./// ]/.test(ch))){
                    evt.preventDefault();
                    }
            });
      $("#us_phone").keypress(function(evt){
            var ch = String.fromCharCode(evt.which);
                if((/[a-zA-Z/!/@/#/$/%/^/&/*/(/)/_/-/+/=/{/[/?/}/:/;/""/''/</,/>/./// ]/.test(ch))){
                    evt.preventDefault();
                    }
            });


       function loadstatedatasel(type,id){
                $.ajax({
                        url:"php/signup/loadstatedatasel.php",
                        type:"POST",
                        data:{type:type,id:id},
                        success:function(data){
                            if(type == "statedata"){
                                $("#dis").html(data);
                                
                            }else{
                                $("#state").html(data);
                            }
                        
                        
                                

                            
                        }
                    })
    }
    loadstatedatasel();





    $("#state").change(function(){
        var idval = $("#state").val();
      /*  alert(idval);*/
        loadstatedatasel("statedata",idval);
    })

     $("#inner_singup").submit(function(e){
        e.preventDefault();
       /* alert("signup-sub")*/


        var fname = $("#f_name").val();
        var lname = $("#l_name").val();
        var pass = $("#pass").val();
        var cpass = $("#cpass").val();
        var gender = $(".gender");
        var email = $("#email").val();
        var phone = $("#phone").val();
        var add = $("#add").val();
        var state = $("#state").val();
        var dis = $("#dis").val();
        var zip = $("#zip").val();
        var capa_hid = $("#sucapa-hidden").val();
        var cpa_text = $("#usup_capa").val();
        var correct_pass = /^[a-z]{4,7}[0-1]{1}@$/;
        var correct_email = /^[a-z]{3,}@[a-z]{3,}.[a-z]{2,}.([a-z]{2})?$/;



       


                    if(fname == ""){
                        $(".fn-err").css("display","block");
                        $(".signup_error").css("display","block");
                            $(".error-box").fadeIn();
                            $(".signup_error").html("Please Enter First Name");
                            setTimeout(function(){
                                $(".signup_error").fadeOut();
                                $(".signup_error").css("display","none");
                                $(".signup_error").html("");

                            },5000);
                        return false;

                    }else if(lname == ""){
                        $(".ln-err").css("display","block");
                        $(".signup_error").css("display","block");
                            $(".error-box").fadeIn();
                            $(".signup_error").html("Please Enter Last Name");
                            setTimeout(function(){
                                $(".signup_error").fadeOut();
                                $(".signup_error").css("display","none");
                                $(".signup_error").html("");

                            },5000);
                            return false;

                    }else if(pass == ""){
                         $(".pass-err").css("display","block");
                        $(".signup_error").css("display","block");
                            $(".error-box").fadeIn();
                            $(".signup_error").html("Please Enter Password");
                            setTimeout(function(){
                                $(".signup_error").fadeOut();
                                $(".signup_error").css("display","none");
                                $(".signup_error").html("");

                            },5000);
                            return false;

                    }else if(!correct_pass.test(pass)){
                           $(".pass-err").css("display","block");
                           $(".signup_error").css("display","block");
                            $(".error-box").fadeIn();
                            $(".signup_error").html("Password is Invalid read the criterea ");
                            setTimeout(function(){
                                $(".signup_error").fadeOut();
                                $(".signup_error").css("display","none");
                                $(".signup_error").html("");
                            },5000);
                            return false;
                        }else if(cpass == ""){
                        	 $(".cpass-err").css("display","block");
                        	 $(".signup_error").css("display","block");
                            $(".error-box").fadeIn();
                            $(".signup_error").html("Please Enter Confirm Password");
                            setTimeout(function(){
                                $(".signup_error").fadeOut();
                                $(".signup_error").css("display","none");
                                $(".signup_error").html("");

                            },5000);
                            return false;
                        }else if(cpass!== pass){
                             $(".cpass-err").css("display","block");
                             $(".signup_error").css("display","block");
                                $(".error-box").fadeIn();
                                $(".signup_error").html("Passwords are not matching ");
                                setTimeout(function(){
                                    $(".signup_error").fadeOut();
                                    $(".signup_error").css("display","none");
                                    $(".signup_error").html("");

                                },5000);
                                return false;
                        }else if(email == ""){
                                $(".email-err").css("display","block");
                                $(".signup_error").css("display","block");
                                    $(".error-box").fadeIn();
                                    $(".signup_error").html("Please Enter Email ID");
                                    setTimeout(function(){
                                        $(".signup_error").fadeOut();
                                        $(".signup_error").css("display","none");
                                        $(".signup_error").html("");

                                    },5000);
                                    return false;

                    }else if(!correct_email.test(email)){
                           $(".email-err").css("display","block");
                           $(".signup_error").css("display","block");
                            $(".error-box").fadeIn();
                            $(".signup_error").html("Email ID is Invalid ");
                            setTimeout(function(){
                                $(".signup_error").fadeOut();
                                $(".signup_error").css("display","none");
                                $(".signup_error").html("");

                            },5000);
                            return false;

                        }else if((gender).filter(":checked").length < 1){
                             $(".gen-err").css("display","block");
                             $(".signup_error").css("display","block");
                                $(".error-box").fadeIn();
                                $(".signup_error").html("Please Select gender ");
                                setTimeout(function(){
                                    $(".signup_error").fadeOut();
                                    $(".signup_error").css("display","none");
                                    $(".signup_error").html("");

                                },5000);
                                return false;
                        }else if(phone == ""){
                                 $(".ph-err").css("display","block");
                                $(".signup_error").css("display","block");
                                    $(".error-box").fadeIn();
                                    $(".signup_error").html("Please Enter Phone Number");
                                    setTimeout(function(){
                                        $(".signup_error").fadeOut();
                                        $(".signup_error").css("display","none");
                                        $(".signup_error").html("");

                                    },5000);
                                    return false;

                    }else if(phone.length < 9 || phone.length > 10 ){
                                 $(".ph-err").css("display","block");
                                $(".signup_error").css("display","block");
                                    $(".error-box").fadeIn();
                                    $(".signup_error").html("Please Enter Valid Phone Number");
                                    setTimeout(function(){
                                        $(".signup_error").fadeOut();
                                        $(".s.gnup_error").css("display","none");
                                        $(".signup_error").html("");

                                    },5000);
                                    return false;

                    }else if(add == ""){
                                 $(".ad-err").css("display","block");
                                $(".signup_error").css("display","block");
                                    $(".error-box").fadeIn();
                                    $(".signup_error").html("Please Enter Current Address");
                                    setTimeout(function(){
                                        $(".signup_error").fadeOut();
                                        $(".signup_error").css("display","none");
                                        $(".signup_error").html("");

                                    },5000);
                                    return false;

                    }else if(state == "select"){
                                 $(".state-err ").css("display","block");
                                $(".signup_error").css("display","block");
                                    $(".error-box").fadeIn();
                                    $(".signup_error").html("Please Select Current State");
                                    setTimeout(function(){
                                        $(".signup_error").fadeOut();
                                        $(".signup_error").css("display","none");
                                        $(".signup_error").html("");

                                    },5000);
                                    return false;

                    }else if(dis == "select"){
                                 $(".dis-err ").css("display","block");
                                $(".signup_error").css("display","block");
                                    $(".error-box").fadeIn();
                                    $(".signup_error").html("Please Select Current District");
                                    setTimeout(function(){
                                        $(".signup_error").fadeOut();
                                        $(".signup_error").css("display","none");
                                        $(".signup_error").html("");

                                    },5000);
                                    return false;

                    }else if(zip == ""){
                                 $(".zip-err").css("display","block");
                                $(".signup_error").css("display","block");
                                    $(".error-box").fadeIn();
                                    $(".signup_error").html("Please Enter Current Address Zip Code");
                                    setTimeout(function(){
                                        $(".signup_error").fadeOut();
                                        $(".signup_error").css("display","none");
                                        $(".signup_error").html("");

                                    },5000);
                                    return false;

                    }else if(cpa_text == ""){
                             $(".capa-err").css("display","block");
                             $(".signup_error").css("display","block");
                                $(".error-box").fadeIn();
                                $(".signup_error").html("Enter Capache");
                                setTimeout(function(){
                                    $(".signup_error").fadeOut();
                                    $(".signup_error").css("display","none");
                                    $(".signup_error").html("");

                                },5000);
                                return false;
                        }else if(cpa_text!== capa_hid){
                             $(".capa-err").css("display","block");
                             $(".signup_error").css("display","block");
                                $(".error-box").fadeIn();
                                $(".signup_error").html("Capache is not matching ");
                                setTimeout(function(){
                                    $(".signup_error").fadeOut();
                                    $(".signup_error").css("display","none");
                                    $(".signup_error").html("");

                                },5000);
                                return false;
                        }

                  /*  var signup_data = ;*/

                    $.ajax({
                    	url: "php/signup/add-user.php",
                    	type:"POST",
                    	data: $("#inner_singup").serialize(),
                    	success:function(data){
                    		console.log(data);
                    		if(data == 1){

                    			$("#inner_singup").trigger("reset");

                    		}else if(data == 2){
                             $(".signup_error").css("display","block");
                                $(".error-box").fadeIn();
                                $(".signup_error").html("This User is already Exisisted  ");
                                setTimeout(function(){
                                    $(".signup_error").fadeOut();
                                    $(".signup_error").css("display","none");
                                    $(".signup_error").html("");

                                },5000);
                                return false;


                    		}
                    	}
                    })    
                        

     })
	 


})