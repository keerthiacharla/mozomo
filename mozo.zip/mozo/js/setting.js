$(document).ready(function(){
 
/*	alert("seting");*/



	 $("#re_oldicon,#re_icon,#re_cicon").click(function(){


                $("#re_show_oldicon,#re_show_icon,#re_show_cicon").toggleClass("fa-eye-slash");


                $("#re_show_oldicon,#re_show_icon,#re_show_cicon").css("color","black")


                $(".fa-eye-slash").css("color","red");


      var input= $("#re_oldpass,#re_pass,#re_cpass");
                    
            if(input.attr("type")==="password"){
    
                input.attr("type","text");
            
            }else{
                input.attr("type","password");
            }

			})
	$(document).on("click","#set-opp",function(a){
		a.preventDefault();

	/*	alert("set-opp");*/

		$("#act_container").css("display","none");
		$(".order_container").css("display","none");
		$(".setting_container").css("display","block");
	});




	$(document).on("click","#update-set",function(c){
		c.preventDefault();

		var id = $(this).data("id");
		var fname = $(this).data("fname");
		var lname = $(this).data("lname");
		var gen = $(this).data("gen");
		var email = $(this).data("email");
		var phone = $(this).data("phone");
		var add = $(this).data("add");
		var cityno = $(this).data("cityno");
		var cityname = $(this).data("cityname");
		var stateno = $(this).data("stateno");
		var statename = $(this).data("statename");
		var zip = $(this).data("zip");

		/*alert(id + " "+ fname+ " "+ lname+ " "+ gen+ " "+ email+ " "+ phone+ " "+ cityno+ " "+cityname+ " "+stateno+ " "+ statename);

*/
		$("#uplog_id").val(id);
		$("#uplog_fname").val(fname);
		$("#uplog_lname").val(lname);
		$("#uplog_email").val(email);
		$("#uplog_phone").val(phone);
		$("#uplog_add").val(add);
		$("#uplog_zip").val(zip);

		$("#uplog_city").html("<option value='"+cityno+"'>"+cityname+"</option>");


		function loadstatedatasel(type,id){
				$.ajax({
						url:"php/setting/loadstatedatasel.php",
						type:"POST",
						data:{type:type,id:id,stateno:stateno,statename:statename},
						success:function(data){
							if(type == "statedata"){
								$("#uplog_city").html(data);
								
							}else{
								$("#uplog_state").html(data);
							}
						
						
								

							
						}
					})
	}
	loadstatedatasel();





	$("#uplog_state").change(function(){
		var idval = $("#uplog_state").val();
		/*alert(idval);*/
		loadstatedatasel("statedata",idval);
	})



			if(gen == "Male"){
				$("input:radio[id='male']").attr("checked",true);
				$("input:radio[id='female']").attr("checked",false);

				
			}else if(gen == "Female"){
				$("input:radio[id='female']").attr("checked",true)
				$("input:radio[id='male']").attr("checked",false);
			}
		
	})





	$(document).on("submit","#cos-det-form",function(b){
		b.preventDefault();

		var form = $(this).serialize();

					$.ajax({
						url:"php/setting/updateuser.php",
						type:"POST",
						data:$("#cos-det-form").serialize(),
						success:function(data){
							if(data == 1){
								$("#update-modal-box").modal("hide");
								
								
							}else{
								console.log(data);
							}
						
						
								

							
						}
					})




	})
	
	$(document).on("submit","#cos-form",function(b){
		b.preventDefault();

	

					var cos_ph = new FormData(this);

					/*console.log(main_logo);*/

							$.ajax({
										url:"php/setting/cos-photo.php",
										type:"POST",
										data : cos_ph ,
										contentType:false,
										processData:false,
										success : function(data){
											if(data == 1){
												$("#update--img-modal-box").modal("hide");
											}else if(data == 2){
												$(".error").css("display","block");
												$(".error").fadeIn();
												$(".error").html("Uploade Only JPG Images  ");
												setTimeout(function(){
													$(".error").fadeOut();
													$(".error").css("display","none");
													$(".error").html("");
													},5000);
												return false;
											}else{
												console.log(data);
											}
											
									

											
										}
									})




	})


	$(document).on("submit","#repass-form",function(b){
		b.preventDefault();


			 var repassid = $("#re_passid").val();
			 var oldpass = $("#re_oldpass").val();
			 var re_pass = $("#re_pass").val();
			 var re_cpass = $("#re_cpass").val();
			 var correct_repass = /^[a-z]{4,7}[0-1]{1}@$/;

			 if(oldpass == ""){
			 	$(".error").css("display","block");
				$(".error").fadeIn();
				$(".error").html("Enter Old Password ");
					setTimeout(function(){
						$(".error").fadeOut();
						$(".error").css("display","none");
						$(".error").html("");
						},5000);
				return false;
			}
					/*var repass = $(this).serialize();

					alert(repass);*/

							$.ajax({
										url:"php/setting/old-pass.php",
										type:"POST",
										data : {id:repassid,oldpass:oldpass},									
										success : function(data){
											if(data == 1){
												if(re_pass == ""){
												 	$(".error").css("display","block");
													$(".error").fadeIn();
													$(".error").html("Enter New Password ");
														setTimeout(function(){
															$(".error").fadeOut();
															$(".error").css("display","none");
															$(".error").html("");
															},5000);
													return false;
												}else if(!correct_repass.test(re_pass)){
								                         $(".error").css("display","block");
													$(".error").fadeIn();
													$(".error").html(" Password is Invalid read the criterea ");
														setTimeout(function(){
															$(".error").fadeOut();
															$(".error").css("display","none");
															$(".error").html("");
															},5000);
								                            return false;
								                        }else if(re_cpass == ""){
															 	$(".error").css("display","block");
																$(".error").fadeIn();
																$(".error").html("Enter New Confirm Password ");
																	setTimeout(function(){
																		$(".error").fadeOut();
																		$(".error").css("display","none");
																		$(".error").html("");
																		},5000);
																return false;
															}else if(re_cpass!== re_pass){
																	 	$(".error").css("display","block");
																		$(".error").fadeIn();
																		$(".error").html(" Password are not Maching  ");
																			setTimeout(function(){
																				$(".error").fadeOut();
																				$(".error").css("display","none");
																				$(".error").html("");
																				},5000);
																		return false;
																	}else{
																			$.ajax({
																				url:"php/setting/new-pass.php",
																				type:"POST",
																				data : {id:repassid,newpass:re_pass,newcpass:re_cpass},									
																				success : function(data){
																					if(data == 1){
																						$("#uppass-modal-box").modal("hide");
																						$("#repass-form").trigger("reset");

																					}else{
																						console.log(data);
																					}

																					
																				}

																			});

																	}
											}else{
												$(".error").css("display","block");
													$(".error").fadeIn();
													$(".error").html(" Enter Correct Password");
														setTimeout(function(){
															$(".error").fadeOut();
															$(".error").css("display","none");
															$(".error").html("");
															},5000);
													return false;
												console.log(data);
											}
									

											
										}
									})




	})




})