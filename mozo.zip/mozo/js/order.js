$(document).ready(function(){
	alert("order_container11111  ");


	$(document).on("click","#ord-opp",function(a){
		a.preventDefault();

	/*	alert("set-opp");*/

		$("#act_container").css("display","none");
		$(".setting_container").css("display","none");
		$(".order_container").css("display","block");
		$("#status-container").css("display","none");
	});


	$(document).on("click","#status-btn",function(a){
		a.preventDefault();

		var sta = $(this).data("sta");

		alert(sta);

		$("#act_container").css("display","none");
		$(".setting_container").css("display","none");
		$(".order_container").css("display","none");
		$("#status-container").css("display","block");


		function status_ord(){
					$.ajax({
								url:"php/order/status_order.php",
								type:"POST",
								data: {id:sta},
								success:function(data){
									console.log(data);
									$("#first-status-bar").html(data)
								}
							})
						}
						status_ord();

				function status_pro(){
					$.ajax({
								url:"php/order/status_pro.php",
								type:"POST",
								data: {id:sta},
								success:function(data){
									console.log(data);
									$("#sec-status-bar").html(data)
										/*$("#sec-status").css("background","rad");*/
									
								}
							})
						}
						status_pro();


				function status_sus(){
					$.ajax({
								url:"php/order/status_sus.php",
								type:"POST",
								data: {id:sta},
								success:function(data){
									console.log(data);
									$("#thi-status-bar").html(data)
										/*$("#sec-status").css("background","rad");*/
									
								}
							})
						}
						status_sus();

			function pay_del(){
					$.ajax({
								url:"php/order/pay_del.php",
								type:"POST",
								data: {id:sta},
								success:function(data){
									console.log(data);
									$("#pay_del_table").html(data)
										
									
								}
							})
						}
						pay_del();
			


			function or_ret(){
					$.ajax({
								url:"php/order/or_ret.php",
								type:"POST",
								data: {id:sta},
								success:function(data){
									console.log(data);
									$("#return").html(data)
										
									
								}
							})
						}
						or_ret();
				});

	


	
})

