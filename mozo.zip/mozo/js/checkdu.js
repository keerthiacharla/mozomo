$(document).ready(function(){
	alert("checkdu.js aaaaaaaaaaa");


	function alldisproduct(){
								$.ajax({
								url:"php/menu/alldisproduct.php",
								
								success:function(data){
									/*console.log(data);*/
									$("#home_sec").html(data);
								}
							})
				

					}
					alldisproduct();

		$(document).on("click","#all-pro",function(){
			alldisproduct();
			$("input[type='checkbox'] ").prop("checked",false);
		})

		$(document).on("click","#reloade",function(){
			 window.location.href ='http://localhost/mozo/first.php';
		})

 

function filter_mobpro(){

		var brname =get_filter("mob_pro");

		$.ajax({
			url:"php/menu/disproduct.php",
			method:"POST",
			data :{brname :brname},
			success:function(data){
				if(data != 0){
					$("#home_sec").html(data);
				}else{
					alldisproduct();
				}
			}
		})
	}

	$(".pro_selector").click(function(){
		/*alert($(this).val());*/
		filter_mobpro();
	})
		function filter_mobsto(){

				var mob_sto =get_filter("mob-sto");

				$.ajax({
					url:"php/menu/mob-sto.php",
					method:"POST",
					data :{mob_sto :mob_sto},
					success:function(data){
						if(data != 0){
							$("#home_sec").html(data);
						}else{
							alldisproduct();
						}
					}
				})
			}

			$(".mob-stro_selector").click(function(){
				/*alert($(this).val());*/
				filter_mobsto();
			})

	

	





	function filter_data(){
		var ram =get_filter("ram");

		$.ajax({
			url:"php/menu/ramdisplay.php",
			method:"POST",
			data :{ram :ram},
			success:function(data){
				if(data != 0){
					$("#home_sec").html(data);
				}else{
					alldisproduct();
				}
			}
		})
	}

	$(".common_selector").click(function(){
		filter_data();
	})


/*television*/

	function filter_protv(){

		var brtvname =get_filter("tv_pro");

		$.ajax({
			url:"php/menu/tvdisproduct.php",
			method:"POST",
			data :{brtvname :brtvname},
			success:function(data){
				if(data != 0){
					$("#home_sec").html(data);
				}else{
					alldisproduct();
				}
			}
		})
	}

	

	$(".tv_pro_selector").click(function(){
		/*alert("tv_selector");*/
		filter_protv();
	})


	function filter_distv(){

		var brtvdis =get_filter("tv_dis_val");

		$.ajax({
			url:"php/menu/tvdis-val.php",
			method:"POST",
			data :{brtvdis :brtvdis},
			success:function(data){
				if(data != 0){
					$("#home_sec").html(data);
				}else{
					alldisproduct();
				}
			}
		})
	}

	

	$(".tv_dis_selector").click(function(){
		/*alert("tv_selector");*/
		filter_distv()
	})

	
	function filter_restv(){

		var brtvres =get_filter("tv_res_val");

		$.ajax({
			url:"php/menu/tvres-val.php",
			method:"POST",
			data :{brtvres :brtvres},
			success:function(data){
				if(data != 0){
					$("#home_sec").html(data);
				}else{
					alldisproduct();
				}
			}
		})
	}

	

	$(".tv_res_selector").click(function(){
		/*alert("tv_selector");*/
		filter_restv()
	})

	function get_filter(class_name){

		var filter = [];

		$("."+class_name+":checked").each(function(){
			filter.push($(this).val());

		})
		return filter;
	}





	


})