$(document).ready(function(){
	/*alert("menu-opp.js");*/

	$(document).on("click","#sign-out",function(r){
		r.preventDefault();

		/*alert("sign-out");*/


		$.ajax({
                        url: "php/signup/sign-out.php",
                        success:function(data){
                            if(data == 1){
                                 window.location.href ='http://localhost/mozo/';
                            }
                        }
                    }) 
	})
})