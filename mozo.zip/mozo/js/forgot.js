$(document).ready(function(){
	/*alert("for-pass AAAA");*/

	$(document).on("click","#for-pass",function(a){
		a.preventDefault();

		$("#login-form").css("display","none");
		$("#forgot-form").css("display","block");
		/*alert("join");*/
	})

	$(document).on("click","#for-back-to",function(b){
		b.preventDefault();

		$("#forgot-form").css("display","none");
		$("#reset-pass-form").css("display","none");
		$("#login-form").css("display","block");
		/*alert("join");*/
	})
	$("#f_con").click(function(){


                $("#f_show_icon").toggleClass("fa-eye-slash");


                $("#f_show_icon").css("color","black")


                $(".fa-eye-slash").css("color","red");


      var pass_input= $("#f_pass");
                    
            if(pass_input.attr("type")==="password"){
    
                pass_input.attr("type","text");
            
            }else{
                pass_input.attr("type","password");
            }

			})


     $("#cficon").click(function(){


                $("#cf_show_icon").toggleClass("fa-eye-slash");


                $("#cf_show_icon").css("color","black")


                $(".fa-eye-slash").css("color","red");


      var cpass_input= $("#cf_pass");
                    
            if(cpass_input.attr("type")==="password"){
    
                cpass_input.attr("type","text");
            
            }else{
                cpass_input.attr("type","password");
            }

            })




		$(document).on("click","#for-sub",function(d){
			d.preventDefault();

			

			var val = $("#otp-email").val();

	/*		alert(val)*/

			$.ajax({
                    	url: "php/signup/emailcheck.php",
                    	type:"POST",
                    	data: {val:val},
                    	success:function(data){

                    		if(data != 0 && data != 2){
                    			$("#otp-box").html(data);
                    			$("#cf_pass_hidd").val(val);
                    			clearInterval(updatetime);
                    		}else if(data == 2){
                    				$(".signup_error").css("display","block");
		                            $(".error-box").fadeIn();
		                            $(".signup_error").html("User not Found");
		                            setTimeout(function(){
		                                $(".signup_error").fadeOut();
		                                $(".signup_error").css("display","none");
		                                $(".signup_error").html("");

		                            },5000);
                        				return false;
                    		}else{
                    			alert(data)
                    		}
                    		
                    	}
                    })

			var updatetime = function(){
					$.ajax({
						url:"php/signup/updattime.php",
						type:"POST",
						data:{id:val},
						success:function(data){
							if(data == 1){
									$(".signup_error").css("display","block");
		                   			  $(".error-box").fadeIn();
		                    	    $(".signup_error").html("OTP is Expired");
		                            setTimeout(function(){
		                                $(".signup_error").fadeOut();
		                                $(".signup_error").css("display","none");
		                                $(".signup_error").html("");

		                            },5000);
                        				

                        				


							}else{
								console.log(data);
							}
						
						
								

							
						}
					})

			}
			setInterval(updatetime,60000);


			
			
			
		

		
		
		
		

		$(document).on("click","#sub-otp",function(d){
			d.preventDefault();

   			var id = $(this).data("sotp");
   			var thi = $(this);
   			clearInterval(updatetime);
			/*alert(id);*/



				$.ajax({
					url:"php/signup/updateche.php",
					type:"POST",
					data:$("#otp-box").serialize(),
					success:function(data){
					
						if(data == 11){
						/*	alert("fech success");*/
							$("#forgot-form").css("display","none");
							$("#reset-pass-form").css("display","block");
						}else{
							$(".signup_error").css("display","block");
		                     $(".error-box").fadeIn();
		                        $(".signup_error").html("OTP is invalid");
		                            setTimeout(function(){
		                                $(".signup_error").fadeOut();
		                                $(".signup_error").css("display","none");
		                                $(".signup_error").html("");

		                            },5000);
                        				return false;
							console.log(data);

						}
					}
				})



})
				
			
		});


		$("#reset-pass-form").submit(function(g){
			g.preventDefault();

		

			


				var password = $("#f_pass").val();
				var cpassword = $("#cf_pass").val();
				var correct_fpass = /^[a-z]{4,7}[0-1]{1}@$/;

				if(password == ""){
					$(".for_signup_error").css("display","block");
		                     $(".error-box").fadeIn();
		                        $(".for_signup_error").html("Enter Password");
		                            setTimeout(function(){
		                                $(".for_signup_error").fadeOut();
		                                $(".for_signup_error").css("display","none");
		                                $(".for_signup_error").html("");

		                            },5000);
                        				return false;

				}else if(!correct_fpass.test(password)){
					$(".for_signup_error").css("display","block");
		                     $(".error-box").fadeIn();
		                        $(".for_signup_error").html("Password is Invalid read the criterea");
		                            setTimeout(function(){
		                                $(".for_signup_error").fadeOut();
		                                $(".for_signup_error").css("display","none");
		                                $(".for_signup_error").html("");

		                            },5000);
                        				return false;

				}else if(cpassword == ""){
					$(".for_signup_error").css("display","block");
		                     $(".error-box").fadeIn();
		                        $(".for_signup_error").html("Enter Confirm Password");
		                            setTimeout(function(){
		                                $(".for_signup_error").fadeOut();
		                                $(".for_signup_errorr").css("display","none");
		                                $(".for_signup_error").html("");

		                            },5000);
                        				return false;

				}else if(cpassword!== password){
					$(".for_signup_errorr").css("display","block");
		                     $(".error-box").fadeIn();
		                        $(".signup_error").html("Both Password Should be Match");
		                            setTimeout(function(){
		                                $(".for_signup_error").fadeOut();
		                                $(".for_signup_error").css("display","none");
		                                $(".for_signup_error").html("");

		                            },5000);
                        				return false;

				}
				

				$.ajax({
					url:"php/signup/updatepass.php",
					type:"POST",
					data:$("#reset-pass-form").serialize(),
					success:function(data){
						if(data == 1){
								window.location ="http://localhost/mozo/login.php";
						}else{
							console.log(data);
						}
					
						
							
					}
				})

			

		})
			
				var update = function(){
				$("#sec").each(function(){
					var count = parseInt($(this).html());
					if(count !== 0){
						$("#otp-box").css("display","block");

						$(this).html(count - 1);
					}else{
						$("#otp-submit").css("display","none");
						
						$("#refor-sub").css("display","block");
						$("#otp-box").css("display","none");
						$("#otp_enter").val();



						
					}
				});
				}
				setInterval(update,1000);
				
		
			
})