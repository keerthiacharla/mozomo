$(document).ready(function(){
	alert("return.js")
	$(document).on("click","#return-pro",function(e){
		e.preventDefault()

		var data_id = $(this).data("ret");
		var data_ord = $(this).data("ord");

		alert(data_id + " "+ data_ord)


		$("#cos_id").val(data_id);
		$("#cos_ord").val(data_ord);

	})
var a = $(".cos_mass");
	$(a).click(function(){
			var val = $(this).val();

		$("#cos_opp_ord").val(val);

		})
			

	$(document).on("click","#cos-opp-sub ",function(e){
		e.preventDefault();

		var id = $("#cos_id").val();
		var ord = $("#cos_ord").val();
		var opp = $("#cos_opp_ord").val();
		var mass = $("#cos_ret_comm").val();

		if(opp == ""){
					$("#ad-erro").css("display","block");
					$("#ad-erro").fadeIn();
					$("#ad-erro").html("Please select any one Resoan ");
					setTimeout(function(){
						$("#ad-erro").fadeOut();
						$("#ad-erro").css("display","none");
						$("#ad-erro").html("");
						},5000);
					return false;
							
											}

		alert(id +" "+ ord +" "+  opp +" "+mass);

		swal({
						  title: "Are you sure You Want to Return this item ?",
						  text: "Are you Sure ..Weather You Want to Return this item  !",
						  icon: "warning",
						  buttons: true,
						  dangerMode: true,
						})
						.then((willDelete) => {

							$.ajax({
								url:"php/order/ret_massage.php",
								type:"POST",
								data: {id:id,opp:opp,ord:ord,mass:mass},
								success:function(data){
									if(data == 1){
											$("#ret-opp").modal("hide");
									}else if(data == 2){
										$("#ad-erro").css("display","block");
											$("#ad-erro").fadeIn();
											$("#ad-erro").html("Return was Sent Alredy ");
											setTimeout(function(){
												$("#ad-erro").fadeOut();
												$("#ad-erro").css("display","none");
												$("#ad-erro").html("");
												},5000);
											return false;
									}else{
										console.log(data);
									}
									
									
								}
							})
							
							
						  if (willDelete) {
						    swal("Poof! You Return order is Booked  ", {
						      icon: "success",
						    });

						     
						    	
						  } else {
						    swal("You Return order is cancelled !");
						  }
						});

						

		
	})
})