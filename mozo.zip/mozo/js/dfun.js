$(document).ready(function(){
	/*	alert("azzzzzzzz");*/


		$(".small-img").hover(function(){
			/*alert("hover")*/
			$("#big-img").attr("src",$(this).attr("src"));

		})

		$("#big-img").imagezoomsl({
			zoomrange:[3, 3]
		})

		$("#read-more").click(function(){
			/*alert("read-more");*/

			$("#sh-note").css("display","none");
			$("#log-sh").css("display","block");
		})
		$("#reduce").click(function(){
			/*alert("read-more");*/

			$("#sh-note").css("display","block");
			$("#log-sh").css("display","none");
		})
	})