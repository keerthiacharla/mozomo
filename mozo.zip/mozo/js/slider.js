$(document).ready(function(){
	/*alert("yy");*/

	var v1 = 15;
	var v2 = 100000;

	 $( "#slider-range" ).slider({
		      range: true,
		      min: 15,
		      max: 100000,
		      values: [ v1, v2 ],
		      slide: function( event, ui ) {
		        $( "#amt" ).html( "RS"+":"+ ui.values[ 0 ] + " - " + "RS" + ":" + ui.values[ 1 ] );

		        v1 = ui.values[ 0 ];
		        v2 = ui.values[ 1 ];
		      
		        loadTable(v1,v2);
		      }
		    });
		    $( "#amt" ).html( $( "#slider-range" ).slider("values", 0 ) +
		      " - " + $( "#slider-range" ).slider( "values", 1 ) );

		  
				function loadTable(range1, range2){
					$.ajax({
								url:"php/menu/range.php",
								type:"POST",
								data: {range1:range1,range2:range2},
								success:function(data){
									console.log(data);
									$("#home_sec").html(data);
								}
							})
						}
						loadTable(v1,v2);
			
})

			