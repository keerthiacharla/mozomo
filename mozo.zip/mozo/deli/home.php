<?php
	session_start();
	if(!isset($_SESSION["deli_name"])){
		header ("Location:http://localhost/mozo/deli/");
		
	}

?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>MOZOMO-delivary</title>
	<link rel="stylesheet" href="../infile/bootstrap/bootstrap4.css">
	 <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
	 <meta name="viewport" content="width=device-width, initial-scale=1" />
	
	<script src="../js/jquery.js?v=2"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>  
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="home1.css">
	
 

</head>
<body>
	<div class="container-fluid">
		<div class="row justify-content-center">
			<div class="col-12 col-xs-12 col-md-12 col-sm-12 col-xl-3" id="menu">
				<div class="col-12 " id="emp-header-img">
					<img src="../infile/logo.gif" alt="" class="mt-3 img-fluid ">
				</div>
				<button class="btn d-lg-none d-md-block d-sm-block d-block " id="show"><i class="fa-solid fa-bars"></i></button>

				<div class="emp-del d-lg-block " id="menu-bar">
					<div class="col-12 col-lg-12 d-flex flex-sm-row flex-md-row flex-lg-column overflow-auto" >
					<div class="col-12 col-sm-2  col-md-12 col-lg-12  "id='emp-img'>
						<img src="../infile/pics.jpg" alt="" id="" class="img-rounded img-fluid ">
					</div>
					<div class="col-12 col-sm-9 col-md-9 ">
						<h3 class=""><?php echo $_SESSION['deli_name'] ?></h3>
						<h6 class=""><?php echo $_SESSION['deli_id']?><</h6>
						<button class="btn btn-primary" id="deli_log">Logout</button>
					</div>
					</div>
				</div>
				
				</div>
			<div class="col-9 col-sm-12 col-lg-9">
				<?php include "php/payment/pay_container.php" ?>
				
			</div>
		</div>
	</div>		
	
	
</body>
<script type="text/javascript"src="js/home.js"></script>
<script type="text/javascript"src="js/pay.js"></script>
<script>

</script>
</html>