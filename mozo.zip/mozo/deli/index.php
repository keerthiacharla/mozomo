<?php 
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Mozomo-Login Page</title>
	<link rel="stylesheet" href="../infile/bootstrap/bootstrap4.css">
	<script src="../js/jquery.js"></script>
	<link rel="stylesheet" href="css/index.css?v=11">
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

	
</head>
<body>
	<div class="container-fluid">
		<div class="row align-content-center"  id="deli-form_con">
			<form action="" class="form m-auto col-md-4 " id="deli_form_fields" >
				
					<div class="header">
						<h1 class="text-sm-center"><img src="../infile/logo.gif" alt=""></h1>
					</div>
					
						<center class="m-3">Agent LOGIN</center>
							<span class="text-red m-2" id="log_error"> Lorem, ipsum.</span>

							<div class="form-group ">
									<label for="">USERNAME</label>
										<div class="input-group">
											<div class="input-group-prepend">
												<span class="input-group-text"><i class="fa-solid fa-users"></i></span>
											</div>
											<input type="text" class="form-control" id="deli_usname" name="deli_usname" placeholder="Enter Id ">
											<div class="input-group-append">
												<button class="btn btn-primary"id="fetc-id">Go</button>
											</div>
										</div>
								</div>
									

							<div id="deli_pass_div">
								
							
								<div class="form-group mt-3">
									<label for="">PASSWORD</label>
									
										<div class="input-group">
											<div class="input-group-prend">
												<span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
											</div>
											<input type="password" class="form-control" id="pass" name="pass" placeholder="Enter Your password ">
											<div class="input-group-append">
												<span id="deli_icon" class="input-group-text"><i class="fa-solid fa-eye" id="deli_show_icon"></i></span>
											</div>
										</div>
									
								</div>
								<button class="btn btn-primary m-3"id="deli_sign-in" name="deli_sign-in">LOG IN</button>


					
						</div>

						

				</form>
				<?php include "php/modal/pass-modal.php" ?>


			</div>
		</div>
	
	<script src="js/index.js"></script>
</body>
</html>