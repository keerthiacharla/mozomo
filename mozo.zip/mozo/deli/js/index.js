$(document).ready(function(){
	/*alert("index.js 11111111");*/


	$("#deli_icon,#set_icon,#set_reset_icon").click(function(){


                $("#deli_show_icon,#set_show_icon,#set_com_show_icon").toggleClass("fa-eye-slash");


                $("#deli_show_icon,#set_show_icon,#set_com_show_icon").css("color","black")


                $(".fa-eye-slash").css("color","red");


      var input= $("#pass,#set_us_pass,#set_retus_pass");
                    
            if(input.attr("type")==="password"){
    
                input.attr("type","text");
            
            }else{
                input.attr("type","password");
            }

			})


	$(document).on("click","#fetc-id",function(e){
		e.preventDefault();

		var text = $("#deli_usname").val();
		$.ajax({
			url:"php/fetchindexid.php",
			type:"POST",
			data:{text:text},

			success:function(data){
				if(data == "Create a password"){
					alert("Create a password");
					$("#pass_reset").modal("show");
				}else if(data == 1){
					$("#deli_pass_div").css("display","block");
				}else{
					   $("#log_error").css("display","block");
					    $("#log_error").html("This ID is Invalid.... Can you type your Agent ID ");
                           setTimeout(function(){
                               $("#log_error").fadeOut();
                              
                               $("#log_error").html("");
                               
                        },5000);
                    return false;
					console.log(data);
				}
			}
		})
			$("#set-id").val(text);
	})

	$(document).on("submit","#set_add",function(a){
		a.preventDefault();

		/*alert();*/

		  var reset_pass = $("#set_us_pass").val();
            var reset_cpass = $("#set_retus_pass").val();
             var correct_pass = /^[a-z]{4,7}[0-1]{1}@$/;

             if(reset_pass == ""){
                $("#ad-reset-erro").css("display","block");                                      
                                           
                           $("#ad-reset-erro p").html("Please Enter Password");
                           setTimeout(function(){
                               $("#ad-reset-erro ").fadeOut();
                               $("#ad-reset-erro p").html("");
                        },5000);
                    return false;

            }else if(!correct_pass.test(reset_pass)){
                $("#ad-reset-erro").css("display","block");                                      
                                           
                           $("#ad-reset-erro P").html("Please Enter Valid Password");
                           setTimeout(function(){
                               $("#ad-reset-erro").fadeOut();
                              
                               $("#ad-reset-erro p").html("");
                        },5000);
                    return false;

                }else if(reset_cpass == ""){
                $("#ad-reset-erro").css("display","block");                                      
                                           
                           $("#ad-reset-erro P").html("Please Enter Confirm Password");
                           setTimeout(function(){
                               $("#ad-reset-erro").fadeOut();
                              
                               $("#ad-reset-erro p").html("");
                        },5000);
                    return false;
                }else if(reset_cpass!== reset_pass){
                $("#ad-reset-erro").css("display","block");                                      
                                           
                           $("#ad-reset-erro P").html("Please Enter Password are not matched ");
                           setTimeout(function(){
                               $("#ad-reset-erro").fadeOut();
                              
                               $("#ad-reset-erro p").html("");
                        },5000);
                    return false;
                }

		$.ajax({
			url:"php/passcreate.php",
			type:"POST",
			data:$("#set_add").serialize(),

			success:function(data){
				if(data == 1){
					$("#pass_reset").modal("hide");
				}else{
					    $("#ad-reset-erro P").html("Something went wrong");
                           setTimeout(function(){
                               $("#ad-reset-erro").fadeOut();
                              
                               $("#ad-reset-erro p").html("");
                        },5000);
                    return false;
					console.log(data);
				}
			}
		})

	})

	$(document).on("click","#deli_sign-in",function(w){
		w.preventDefault(); 

		var usname = $("#deli_usname").val();
		var pass = $("#pass").val();

		


		$.ajax({
			url:"php/login.php",
			type:"POST",
			data:{usname:usname,pass:pass},

			success:function(data){
				
				 if(data == "yes login"){
					window.location.href = "http://localhost/mozo/deli/home.php";
				}else{

					    $("#log_error").css("display","block");
					    $("#log_error").html("Crediatials are not matched ");
                           setTimeout(function(){
                               $("#log_error").fadeOut();
                              
                               $("#log_error").html("");

                        },5000);
                    return false;
					console.log(data);
				}
			}
		})
	})


})