	$(document).ready(function(){
		/*alert("home.js");*/
		$(document).on("click","#show",function(){
			/*alert("aa");*/
			$("#menu-bar").toggle("slow")
		})
			$(document).on("click","#deli_log",function(w){
				w.preventDefault();

				/*alert("logout")*/


				$.ajax({
					url:"php/logout.php",
					

					success:function(data){
						console.log(data);
						 if(data == 1){
							window.location.href = "http://localhost/mozo/deli/";
						}else{
							  
		                    
							console.log(data);
						}
					}
				})
			})


	})