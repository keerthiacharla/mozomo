$(document).ready(function(){
	alert("pay.js  ");

	  $("#entercotp,#enterdotp").keypress(function(evt){
            var ch = String.fromCharCode(evt.which);
                if((/[a-zA-Z/!/@/#/$/%/^/&/*/(/)/_/-/+/=/{/[/?/}/:/;/""/''/</,/>/./// ]/.test(ch))){
                    evt.preventDefault();
                    }
            });

	function pay_btn(){
		$.ajax({
						url:"php/payment/php/paybyn.php",
						
						success:function(data){
							/*console.log(data);*/
							$("#cos-det-btn").html(data);
						
						
						
								

							
						}
					})
	}
	pay_btn();


	$(document).on("click","#cos-del-brn",function(){

		var id = $(this).data("payid");

		alert(id);

					$("#enterotp-id").val(id);
	

					$.ajax({
						url:"php/payment/php/paytable.php",
						type:"POST",
						data: {id:id},
						
						success:function(data){
						/*	console.log(data);*/
							$("#cos-det-table").html(data);
						
						
						
								

							
						}
						})



	})

	$(document).on("click","#deli-id",function(e){
		e.preventDefault();

		alert("a");
		var id = $("#enterotp-id").val();
		var deli_otp = $("#enterdotp").val();

			$.ajax({
						url:"php/payment/php/deliotp.php",
						type:"POST",
						data: {id:id,deli_otp:deli_otp},
						
						success:function(data){
							
							if(data == 1){
								$("#cos-otp-div").css("display","block");

							}else{
								$(".mob-error").css("display","block");
								$(".mob-error").fadeIn();
								$(".mob-error").html("Delivary OTP is Invalid ");
								setTimeout(function(){
									$(".mob-error").fadeOut();
									$(".mob-error").css("display","none");
									$(".mob-error").html("");
									},5000);
								console.log(data);
							}
						
						
						
								

							
						}
						})
	})


	$(document).on("click","#enter-otp-cos",function(e){
		e.preventDefault();

		alert("a");
		var id = $("#enterotp-id").val();
		var cos_otp = $("#entercotp").val();

			$.ajax({
						url:"php/payment/php/otp-status.php",
						type:"POST",
						data: {id:id,val:cos_otp},
						
						success:function(data){
							
							
							if(data == 1){
								$("#insert_otp").modal("hide");

							}else{
								$(".mob-error").css("display","block");
								$(".mob-error").fadeIn();
								$(".mob-error").html("Costomer OTP is Invalid ");
								setTimeout(function(){
									$(".mob-error").fadeOut();
									$(".mob-error").css("display","none");
									$(".mob-error").html("");
									},5000);
								console.log(data);
							}
						
						
						
								

							
						}
						})
	})
			


function allpay_btn(){
		$.ajax({
						url:"php/payment/php/allpaybyn.php",
						
						success:function(data){
							/*console.log(data);*/
							$("#allcos-det-btn").html(data);
						
						
						
								

							
						}
					})
	}
	allpay_btn();

	$(document).on("click","#allcos-del-brn",function(){

		var allid = $(this).data("allpayid");

		alert(allid);



					$.ajax({
						url:"php/payment/php/allpaytable.php",
						type:"POST",
						data: {id:allid},
						
						success:function(data){
							/*console.log(data);*/
							$("#allcos-det-table").html(data);
						
						
						
								

							
						}
						})



	})

})