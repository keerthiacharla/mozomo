<?php 
		include "../../admin/infile/config.php";

	$usid = $_POST['set-id'];
	$pass = md5($_POST['set_us_pass']);



				
		$sql = "UPDATE deli_agent SET pass ='{$pass}' WHERE deli_id = '{$usid}'";

				if(mysqli_query($conn,$sql)){
					echo 1;
				}else{
					die("Query Failed ");
				}
				




 ?>