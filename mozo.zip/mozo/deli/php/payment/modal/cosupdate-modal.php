


<div class="modal fade " id="insert_otp" data-backdrop="static">
	<div class="modal-dialog e">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 d-flex">
				<h5 class="text-white p-2">Enter Costomer OTP </h5>
				<span class="mob-error ">
					<p class="text-white bg-danger m-1 p-2"></p>
				</span>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
						<form class="form" id="enter-otp-form">
								<input type="text" class="form-control" id="enterotp-id" name="enterotp-id" hidden >
							<div class="form-group">
			       				<label for="">Enter Delivary OTP </label>
			       				<div class="input-group">
				       				<input type="text" class="form-control" id="enterdotp" name="enterdotp" placeholder="Enter Id ">
												<div class="input-group-append">
													<button class="btn btn-primary"id="deli-id">Send</button>
												</div>
									</div>
			       			</div>
			       			<div class="form-group" id="cos-otp-div">
			       				<label for="">Enter Costomers OTP </label>
			       				<input type="text" class="form-control" id="entercotp" name="entecrotp">
			       				
			       				<button class="btn btn-primary " id='enter-otp-cos'>Send OTP</button>
			       			</div>
									
							
						</form>
					</div>
				</div>

			</div>
			<div class="modal-footer">
				
				
			</div>
			

		</div>
	</div>
</div>
</div>


