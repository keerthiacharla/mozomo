
<div class="payment_items_container d-block p-3">
	<h1 class="bg-primary d-block text-white" id="title">Costomer Modification</h1><span>
		
	</span>

<div class="product-items-container">
	
		
		
	<button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#cos_set_data">Recent Delivary Allotted </button>

	<div class="product_data collapse p-3" id="cos_set_data">
				
			<div class="form-group d-flex ml-auto m-3" >
							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="cos-det-val-search-box" name="cos-det-val-search-box" placeholder="SEARCH">
							</div>
							
						</div>

			        

			       <div class="col-md-12 productdata-container d-lg-flex">

			       	 <div class="col-md-6" id="cos-det-btn">
			       	 
			       	 </div>
			       	 <div class="col-md-6" id="cos-det-con">
			       	 	<table class="table" id="cos-det-table">
			       	 		
						</table>
			       	 
			       	 <?php include "modal/cosupdate-modal.php "?>
			       	 </div>
			       	 
			       </div>
			    </div>


<button class="bg-primary d-block text-white p-1 m-1 dropdown-toggle w-100" data-toggle="collapse" data-target="#cos_st_set_data">All My Delivary  </button>

	<div class="product_data collapse p-3" id="cos_st_set_data">
				
			<div class="form-group d-flex ml-auto m-3" >

							<div class="form-group m-2 serch-item d-block ml-auto">
								<input type="text" class="form-control d-block ml-auto " id="cos-st-det-val-search-box" name="cos-st-det-val-search-box" placeholder="SEARCH">
							</div>
						</div>

			        

			     

			        

			       <div class="col-md-12 productdata-container d-lg-flex">

			       	 <div class="col-md-6" id="allcos-det-btn">
			       	 
			       	 </div>
			       	 <div class="col-md-6" id="allcos-det-con">
			       	 	<table class="table" id="allcos-det-table">
			       	 		
						</table>
			       	 
			       
			       	 </div>
			       	 
			       </div>
			    </div>
			    </div>
	
			


			    
			    
		</div>

	   
		</div>
<


