
	<?php

include "../../../../admin/infile/config.php";
	$id = $_POST['id'];
				
			$sql = "SELECT roz.*,cos_users.fname,cos_users.lname,cos_users.user_id FROM roz  
					LEFT JOIN cos_users ON roz.cos_no = cos_users.sno
					LEFT JOIN category ON roz.p_id = category.sno
					 WHERE roz.sno =$id ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						if($row['ord_status'] == "Payment Sattled Successfully"){
							$status_ord = "<tr>
								<td><b>Delivary Type </b></td>
								<td>Returned Order 	</td>
							</tr>";
						}else if($row['ord_status'] == "Delivared Sucessfully"){
							$status_ord = "<tr>
								<td><b>Delivary Type </b></td>
								<td>Delivary Order 	</td>
							</tr>";
						}else{
							$status_ord = "";
						}


						
						if($row['deli_name'] == "" && $row['deli_ph'] == ""){
							$boy = "";
						}else{
							$boy = "<tr>
								<td><b>Delivary Agent Details </b></td>
								<td><b>Name : </b> {$row['deli_name']} <b>Phone Number  : </b> {$row['deli_ph']}  
								</td>
							</tr>";

						}
					
						echo "
							<tr>
								<td><b>Category</b></td>
								<td><b>details</b></td>
							</tr>
							{$status_ord}
							<tr>
								<td><b>Costomer Name </b></td>
								<td>{$row['user_id']}</td>
							</tr>
							<tr>
								<td><b>Costomer Name </b></td>
								<td>{$row['fname']} {$row['lname']}</td>
							</tr>
							<tr>
								<td><b>Delivary Address </b></td>
								<td>{$row['address']}</td>
							</tr>
						
							<tr>
								<td><b>Ammount ID </b></td>
								<td>{$row['amt']}</td>
							</tr>
							
							{$boy}
							
							
							<tr>
								<td><b>Delivaryed On </b></td>
								<td>{$row['deli_date']}</td>
							</tr>
							

							";

						
					
					}

					
				}else{ 
					echo "No login";
				}
			?>