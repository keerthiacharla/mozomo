
	<?php

include "../../../../admin/infile/config.php";

	$id = $_POST['id'];
				
			$sql = "SELECT roz.*,cos_users.fname,cos_users.lname,cos_users.user_id FROM roz  
					LEFT JOIN cos_users ON roz.cos_no = cos_users.sno
					LEFT JOIN category ON roz.p_id = category.sno
					 WHERE roz.sno =$id ";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

												
						if($row['deli_otp'] == 0){
							$otpf = "";
						}else{
							$otpf = "<tr>
								<td><b>Delivary Status</b></td>
								<td><button class='btn btn-primary mb-1'  data-toggle='modal' data-target='#insert_otp' data-intotp='{$row['sno']}' id='ins-otp'>Enter OTP </button>
								</td>
							</tr>";

						}
					
						echo "<tr>
								<td><b>Category</b></td>
								<td><b>details</b></td>
							</tr>
							
							<tr>
								<td><b>Costomer Name </b></td>
								<td>{$row['fname']} {$row['lname']}</td>
							</tr>
							<tr>
								<td><b>Delivary Address </b></td>
								<td>{$row['address']}</td>
							</tr>
							
							
							<tr>
								<td><b>Ammount ID </b></td>
								<td>{$row['amt']}</td>
							</tr>
							
							{$otpf}
							<tr>
								<td><b>Delivaryed On </b></td>
								<td>{$row['deli_date']}</td>
							</tr>

							";

						
					
					}

					
				}else{ 
					echo "No login";
				}
			?>