<?php session_start();

 
	include "../../../../admin/infile/config.php";

	 $id = $_POST['id'];
	 $deli_otp = $_POST['deli_otp'];
	
				
			$sql = "SELECT * FROM roz WHERE SNO  = {$id}";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
						
					
						if($row['deli_otp'] == $deli_otp){
							echo 1;
						}else{
							echo "otp not match";
						}

						
					
					}

					
				}else{ 
					echo "<h1> No Recent Order By Costomer </h1>";
				}

 ?>
