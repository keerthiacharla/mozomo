<?php 
session_start();


	$usname = $_POST['usname'];
	 $pass = md5($_POST['pass']);

include "../../admin/infile/config.php";

				
			$sql = "SELECT * FROM deli_agent WHERE deli_id = '{$usname}' AND pass ='{$pass}'";

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){

						$_SESSION['deli_id'] = $row['deli_id'];
						$_SESSION['deli_name'] = $row['fname'] . " " .$row['lname']  ;
					
						$_SESSION['deli_ph'] = $row['phone'];
						$_SESSION['deli_email'] = $row['email'];
						
						$_SESSION['deli_img'] = $row['image'];
												
						echo "yes login";

						
					
					}

					
				}else{ 
					echo "No login";
				}

 ?>