<div class="modal fade " id="pass_reset" data-backdrop="static">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header bg-primary p-0 ">
				<h5 class="text-white p-2">Set Password <div id="loreset-heder"></div> <span id="ad-reset-erro"> <p></p></span></h5>
				
				<button class="btn btn-danger m-2" data-dismiss="modal">&times;</button>
				
			</div>
			<div class="modal-body">
				<div class="container-fluid ">
					<div class="row" >
						<div class="col-md-12">
							<form action="" id="set_add">
									<input type="text" id="set-id" name="set-id" value="" >
									
								<div class="form-group input-group">
										<input type="password" class="form-control" id="set_us_pass" name="set_us_pass" placeholder="Enter Your password " >
										<div class="input-group-append">
											<span id="set_icon" class="input-group-text"><i class="fa-solid fa-eye" id="set_show_icon"></i></span>
										</div>
									</div>
									<div class="form-group input-group">
										<input type="password" class="form-control" id="set_retus_pass" name="set_retus_pass" placeholder="Enter Your password ">
										<div class="input-group-append">
											<span id="set_reset_icon" class="input-group-text"><i class="fa-solid fa-eye" id="set_com_show_icon"></i></span>
										</div>
									</div>
								<button class="btn btn-primary " id="set-sub"> Submit</button>
								
							</form>			
						</div>		
					</div>
				
				</div>

			</div>
		</div>
	</div>
</div>