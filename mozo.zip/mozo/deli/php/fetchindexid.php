<?php 


	include "../../admin/infile/config.php";

$pass= $_POST['text'];
				
		$sql = "SELECT * FROM deli_agent WHERE deli_id = '{$pass}'";

				$res = mysqli_query($conn,$sql) or die(" query failed");
				if(mysqli_num_rows($res) > 0){
					
					while($row = mysqli_fetch_assoc($res)){

						
						
						if(empty($row['pass'])){

							echo "Create a password";


						}else{
							
									/*$_SESSION['emp_id'] = $row['emp_no'];
									$_SESSION['name'] = $row['name'];
									
									$_SESSION['pass'] = $row['pass'];
									$_SESSION['email'] = $row['email'];
									$_SESSION['role'] = $row['role'];
									$_SESSION['img'] = $row['image'];*/
						
								echo 1;
						}
		
					
					}

					
				}else{ 
					echo 0;
				}


 ?>