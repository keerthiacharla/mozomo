<?php 
	session_start();
	if(!isset($_SESSION["name"])){
		header ("Location:http://localhost/mozo/login.php");
		
	}
	?>
	<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="infile/bootstrap/bootstrap4.css">
	
	<script src="js/jquery.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="css/detail.css?v=13">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

</head>
<body>
	<?php 

		$id = $_GET['id'];
		 $sno = $_GET['pid'];

			include "admin/infile/config.php";

				
				
				
			 $sql = "SELECT * FROM television WHERE sno = $sno AND pro_name = $id"; 

				$res = mysqli_query($conn,$sql) or die(" query failed");

				if(mysqli_num_rows($res)){

					
					while($row = mysqli_fetch_assoc($res)){

						if($row['off_rate'] != "No Offer" ){
							$tv_off_div = "<div class='off-tag'>
									<h5 class='text-white text-center' id='offtag-text'>{$row['off_per']}%</h5>
								</div>";

							$tv_off_price = "<div id='flex-off-rate'>
												<h3><i class='fa-sharp fa-solid fa-indian-rupee-sign mr-2'></i>{$row['off_rate']}</h3>
												<div class='d-flex p-3 mt-4 mb-4 ml-0>
													<h5 class='font-weight-lighter '><i class='fa-sharp fa-solid fa-indian-rupee-sign mr-2 '></i>{$row['amt']}</h5><span class='bg-success text-white font-weight-bold ml-2 p-2'>{$row['off_per']} % Off</span>
													</div>							
											</div>";
						}else{
							$tv_off_div = "";
							$tv_off_price ="<div id='ec-amt' class='m-3'>
													<h4><span ><i class='fa-sharp fa-solid fa-indian-rupee-sign mr-2'></i></span>{$row['amt']}</h4>
												</div>";
						}



					}

					
				}else{
					echo "No data Found ";
				}
	 ?>

		<div class="container">
			<div class="row justify-content-center " id="image_container">
				<div class="col-12 w-100 d-flex flex-row flex-sm-row flex-lg-column col-md-12  col-lg-2" id="all-img">

					<?php 

						echo $tv_off_div;

						include "admin/infile/config.php";

					$sql = "SELECT * FROM images WHERE img_id = $sno AND pro_no = $id";

					$res = mysqli_query($conn,$sql) or die("loadbtn.php query failed");

					if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
				 ?>
					<img src="admin/php/product/php/tv-images/<?php echo $row['img_name'] ?>" alt="" class="small-img">
					
						<?php 

					}
				}

				 ?>
				</div>
				<div class="col-12 col-md-12 col-lg-5 " id="view_container">
					<?php 

						include "admin/infile/config.php";

				$sql = "SELECT * FROM television WHERE sno = $sno AND pro_name = $id";

					$res = mysqli_query($conn,$sql) or die("loadbtn.php query failed");

					if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
				 ?>
					<img src="admin/php/product/php/tv-images/<?php echo $row['file'] ?>" alt="" class="m-auto" id="big-img">

						<?php 

					}
				}

				 ?>
				</div>
				<?php 

						include "admin/infile/config.php";

				$sql = "SELECT television.*,pro.pname FROM television LEFT JOIN pro ON television.br_name = pro.sno  WHERE television.sno = $sno AND television.pro_name = $id";

					$res = mysqli_query($conn,$sql) or die("loadbtn.php query failed");

					if(mysqli_num_rows($res) > 0){

					
					while($row = mysqli_fetch_assoc($res)){
				 ?>
				<div class="col-12 col-md-12 col-lg-5">
					<div id="sec-header" class="m-3">
					<h3><?php echo $row['ml_name'] ?> </h3>
				</div>
				<div id="sec-disc" class="m-3">
					<div id="sh-note">
						<?php echo substr($row['disc'],0,130)."..."; ?>
						 
						<a href="#" class="btn" id="read-more">Read More </a>
					</div>
					<div id="log-sh">
						<?php echo $row['disc'] ?>

						<a href="#" class="btn" id="reduce">Reduce</a>
					</div>

				</div>
				<?php echo $tv_off_price  ?>
				<div id="sec-button">
				<a class="btn btn-primary text-white mb-4 " href="buy-now.php?pid=<?php echo $id ?>&id=<?php echo $sno ?> ">Buy Now </a>
					
				</div>
				</div>
				
			</div>
			<div class="row">
			<table class="table" border="1">
				<thead class="bg-primary text-white">
					
						<tr>
							<th>Name</th>
							<th>Discription</th>
						</tr>
					
				</thead>
				<tbody>
					<tr>
						<td><b>Brand Name</b></td>
						<td><?php echo $row['pname'] ?></td>
					</tr>
					<tr>
						<td><b>Brand Number</b></td>
						<td><?php echo $row['ml_no'] ?></td>
					</tr>
					
					<tr>
						<td><b>Color</b></td>
						<td><?php echo $row['color'] ?></td>
					</tr>
					<tr>
						<td><b>Inches</b></td>
						<td><?php echo $row['inch'] ?></td>
					</tr>
					<tr>
						<td><b>Display Type</b></td>
						<td><?php echo $row['dis'] ?></td>
					</tr>
					<tr>
						<td><b>Resolution</b></td>
						<td><?php echo $row['resol'] ?></td>
					</tr>
					
					<tr>
						<td><b>Feautures</b></td>
						<td><?php echo $row['fea'] ?></td>
					</tr>
					<tr>
						<td><b>HDMI ports</b></td>
						<td><?php echo $row['hdmi']." ". "Ports" ?></td>
					</tr>
					<tr>
						<td><b>USB ports</b></td>
						<td><?php echo $row['usb']." ". "Ports" ?></td>
					</tr>
					<tr>
						<td><b>Manufacture</b></td>
						<td><?php echo $row['pname'] ?></td>
					</tr>
					
					<tr>
						<td><b>Made IN</b></td>
						<td><?php echo $row['made'] ?></td>
					</tr>



					
				</tbody>
			</table>
			<?php 

					}
				}

			 ?>
		</div>


		</div>
	
	
	
</body>
<script src="js/jquery.js"></script>
<script src="js/zoomsl.js"></script>
<script src="js/dfun.js"></script>
	<script src="https://checkout.razorpay.com/v1/checkout.js"></script>

<script src="js/buy-now.js"></script>
</html>