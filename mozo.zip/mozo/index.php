<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Mozomo</title>
	<link rel="stylesheet" href="infile/bootstrap/bootstrap4.css">
	<link rel="stylesheet" href="infile/bootstrap/owl.carousel.css">
	<link rel="stylesheet" href="infile/bootstrap/owl.theme.green.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
		
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
		 <!-- <script src="https://code.jquery.com/jquery-3.6.0.js"></script> -->
  		<script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
   		<link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
   		
   		<link rel="stylesheet" href="css/index.css?v=122222">
	
</head>
<body>
	<div class="container-fluid ">
		<div class="row justify-content-center  " id="menu-bar">
			
					<div class="col-12 d-flex flex-md-row flex-sm-column flex-wrap">
						<div class="col-sm-12 col-lg-10 col-md-12 ">
							<h1 class="text-sm-center text-xm-center text-md-left"><img src="admin/infile/logo.gif" alt=""></h1>
						</div>
						
						<div class="col-sm-12 col-12 col-lg-2 col-md-12 justify-content-center p-3 d-block m-auto d-flex" >
							<button class="btn btn-primary" id="join-log"> Join Now </button>
						</div>
					</div>
			
			</div>
		</div>


		<!-- carosol -->
<div class="container-fluid">
		<div class="row m-0">
			<?php include "php/carosol/caro-view.php" ?>
		</div>
		
	
	</div>


	<div class="container-fluid" id="caro_slide_con">
		<div class="row" id="">


			<div class="col-md-12"id="owl-con">
					<h3>Mobile/Television</h3>
				<?php include "php/owl.php" ?>
		</div>
		</div>
		
		</div>

		<div class="container-fluid  mt-3">
		<div class="row" id="">

			<div class="col-md-12 d-flex "id="owl-con">
				<h3>Brands</h3>
				<marquee behavior="" direction="" class="mt-5">
					<?php
						include "admin/infile/config.php";

						$sql = "SELECT * FROM pro_logo";

						$res = mysqli_query($conn,$sql) or die("loadbtn.php query failed");

						
						if(mysqli_num_rows($res) > 0){
							while($row = mysqli_fetch_assoc($res)){
								?>
					
					<img src="admin/php/setting/php/logo-Pro/<?php echo $row['logo'] ?>" class="ml-3"alt='' height='100px' width='150px'>
					<?php
					}
				}
								?>
				</marquee>
				
			</div>


		</div>
		
		</div>



		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6">
					<img src="images/12.jpg" alt="" id="f_pics">
				</div>
				<div class="col-md-6">
					<img src="images/11.jpg" alt="" id="f_pics">
					
				</div>
			</div>


		</div>



	<script src="js/index.js?1111"></script>
</body>
</html>