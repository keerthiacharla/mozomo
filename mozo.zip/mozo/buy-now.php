<?php 
	session_start();
	if(!isset($_SESSION["name"])){
		header ("Location:http://localhost/mozo/login.php");
		
	}

?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="infile/bootstrap/bootstrap4.css">
	<script src="js/jquery.min.js"></script>
	<link rel="stylesheet" href="css/buy.css?v=11111">
</head>
<body>
	<div class="container">
		<div class="row con align-content-center">
			<div class="col-md-6 m-auto ">
				<?php 

					$pid = $_GET['pid'];
					$sno = $_GET['id'];

					/*echo $pid." ". $sno;*/
					$ord = "mob".rand(00000,999999);
					$tvord = "tv".rand(00000,999999);
					include "admin/infile/config.php";

					if($pid == 1){

						

						$sql = "SELECT * FROM mobile WHERE sno = $sno";

						$res = mysqli_query($conn,$sql) or die("Query failed");

						if(mysqli_num_rows($res) > 0){
							while($row = mysqli_fetch_assoc($res)){

								if($row['off_rate'] == "No Offer"){
									$mob_off = $row['amt'];
								}else{
									$mob_off = $row['off_rate'];
								}


				 ?>
				<div class="form">
			         <table class="table">
			         
			         	<tbody>
			         		<tr>
			         			
			         			<td  colspan="2" class=""><center><img src="admin/php/product/php/Mobile-images/<?php echo $row['file'] ?>" alt=""></center></td>
			         		</tr>
			         		<tr>
			         			<td><b>Order Id</b></td>
			         			<td><input type="text" class="form-control" id="mob_id"  value="<?php echo $sno ?>"hidden > 
			         				<input type="text" class="form-control" id="mobpr_id"  value="<?php echo $pid ?>" hidden>
			         				<input type="text" class="form-control" id="mob_or_id"  value="<?php echo $ord?>" readonly>
			         			
			         			</td>
			         		</tr>
			         		<tr>
			         			<td><b>Product</b></td>
			         			<td><input type="text" class="form-control" id="mob_p_id" value="<?php echo $row['ml_name'] ?>" readonly></td>
			         		</tr>
			         		<tr>
			         			<td><b>Name</b></td>
			         			<td><input type="text" class="form-control" id="mob_name" value="<?php echo $_SESSION['name'] ?>" readonly></td>
			         		</tr>
			         		<tr>
			         			<td><b>Email Id</b></td>
			         			<td><input type="text" class="form-control" id="mob_email" value="<?php echo $_SESSION['email'] ?>" readonly></td>
			         		</tr>
			         		<tr>
			         			<td><b>Phone</b></td>
			         			<td><input type="text" class="form-control" id="mob_phone" value="<?php echo $_SESSION['phone'] ?>" readonly></td>
			         		</tr>
			         		<tr>
			         			<td><b>Ammout</b></td>
			         			<td><input type="text" class="form-control" id="mob_amt"value="<?php echo $mob_off ?>" readonly></td>
			         		</tr>
			         		<tr >
			         			<td colspan='2'><input type="submit"id="mob-rzp-button1" class="btn btn-primary d-block w-100" value="Pay"></td>
			         		</tr>
			         	</tbody>
			         </table>
			</div>
					
		<?php

			}
						}
			 }else if($pid == 2){

			 	$sql1 = "SELECT * FROM television WHERE sno = $sno";

						$res1 = mysqli_query($conn,$sql1) or die("Query failed");

						if(mysqli_num_rows($res1) > 0){
							while($row1 = mysqli_fetch_assoc($res1)){

								if($row1['off_rate'] == "No Offer"){
									$tv_off = $row1['amt'];
								}else{
									$tv_off = $row1['off_rate'];
								}
		?>


			<div class="form">
			         <table class="table">
			         
			         	<tbody>
			         		<tr>
			         			
			         			<td  colspan="2" class=""><center><img src="admin/php/product/php/tv-images/<?php echo $row1['file'] ?>" alt=""></center></td>
			         		</tr>
			         		<tr>
			         			<td><b>Order Id</b></td>
			         			<td><input type="text" class="form-control" id="tv_id"  value="<?php echo $sno ?>" hidden> 
			         				<input type="text" class="form-control" id="tvpr_id"  value="<?php echo $pid ?>" hidden>
			         				<input type="text" class="form-control" id="tv_or_id"  value="<?php echo $tvord?>" readonly>
			         			
			         			</td>
			         		</tr>
			         		<tr>
			         			<td><b>Product</b></td>
			         			<td><input type="text" class="form-control" id="tv_p_id" value="<?php echo $row1['ml_name'] ?>" readonly></td>
			         		</tr>
			         		<tr>
			         			<td><b>Name</b></td>
			         			<td><input type="text" class="form-control" id="tv_name" value="<?php echo $_SESSION['name'] ?>" readonly></td>
			         		</tr>
			         		<tr>
			         			<td><b>Email Id</b></td>
			         			<td><input type="text" class="form-control" id="tv_email" value="<?php echo $_SESSION['email'] ?>" readonly></td>
			         		</tr>
			         		<tr>
			         			<td><b>Phone</b></td>
			         			<td><input type="text" class="form-control" id="tv_phone" value="<?php echo $_SESSION['phone'] ?>" readonly></td>
			         		</tr>
			         		<tr>
			         			<td><b>Ammout</b></td>
			         			<td><input type="text" class="form-control" id="tv_amt" value="<?php echo $tv_off ?>" readonly></td>
			         		</tr>
			         		<tr >
			         			<td colspan='2'><input type="submit"id="tv-rzp-button1" class="btn btn-primary d-block w-100" value="Pay"></td>
			         		</tr>
			         	</tbody>
			         </table>
			</div>
	<?php
		

		}
		}
		}
		?>


		</div>
	</div>


	<script src="js/buy-now.js"></script>
	<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
</body>
</html>